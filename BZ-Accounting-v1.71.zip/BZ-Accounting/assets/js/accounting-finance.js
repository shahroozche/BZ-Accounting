jQuery(function ($) {
    'use strict';

    if (typeof $.fn.pDatepicker !== 'function') {
        return;
    }

    $('.bzc-finance-persian-date').each(function () {
        var $field = $(this);

        if ($field.data('pwt-datepicker')) {
            return;
        }

        $field.pDatepicker({
            format: 'YYYY-MM-DD',
            autoClose: true,
            initialValue: false,
            observer: true,
            calendarType: 'persian',
            toolbox: {
                calendarSwitch: { enabled: false },
                todayButton: { enabled: true }
            }
        });
    });
});
