<?php
/**
 * BZ-Accounting - Financial Management Module
 * Adds a separate business-finance layer without changing the legacy reporting code.
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!defined('BZC_FINANCE_VERSION')) {
    define('BZC_FINANCE_VERSION', '1.1.0');
}

function bzc_finance_table($name) {
    global $wpdb;
    return $wpdb->prefix . 'bzc_finance_' . $name;
}

function bzc_finance_install() {
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    $charset = $wpdb->get_charset_collate();
    $accounts = bzc_finance_table('accounts');
    $parties = bzc_finance_table('parties');
    $categories = bzc_finance_table('categories');
    $transactions = bzc_finance_table('transactions');
    $checks = bzc_finance_table('checks');

    dbDelta("CREATE TABLE {$accounts} (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        name varchar(190) NOT NULL,
        type varchar(30) NOT NULL DEFAULT 'bank',
        gateway_id varchar(190) NOT NULL DEFAULT '',
        linked_bank_account_id bigint(20) unsigned NOT NULL DEFAULT 0,
        opening_balance decimal(20,2) NOT NULL DEFAULT 0,
        opening_date date DEFAULT NULL,
        is_active tinyint(1) NOT NULL DEFAULT 1,
        notes text NULL,
        created_at datetime NOT NULL,
        updated_at datetime NOT NULL,
        PRIMARY KEY (id),
        KEY type (type),
        KEY gateway_id (gateway_id),
        KEY linked_bank_account_id (linked_bank_account_id),
        KEY is_active (is_active)
    ) {$charset};");

    dbDelta("CREATE TABLE {$parties} (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        name varchar(190) NOT NULL,
        type varchar(30) NOT NULL DEFAULT 'other',
        phone varchar(60) NOT NULL DEFAULT '',
        email varchar(190) NOT NULL DEFAULT '',
        notes text NULL,
        is_active tinyint(1) NOT NULL DEFAULT 1,
        created_at datetime NOT NULL,
        updated_at datetime NOT NULL,
        PRIMARY KEY (id),
        KEY type (type),
        KEY is_active (is_active)
    ) {$charset};");

    dbDelta("CREATE TABLE {$categories} (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        name varchar(190) NOT NULL,
        type varchar(30) NOT NULL DEFAULT 'expense',
        is_active tinyint(1) NOT NULL DEFAULT 1,
        created_at datetime NOT NULL,
        PRIMARY KEY (id),
        KEY type (type)
    ) {$charset};");

    dbDelta("CREATE TABLE {$transactions} (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        transaction_date date NOT NULL,
        type varchar(30) NOT NULL,
        amount decimal(20,2) NOT NULL DEFAULT 0,
        account_id bigint(20) unsigned NOT NULL DEFAULT 0,
        destination_account_id bigint(20) unsigned NOT NULL DEFAULT 0,
        party_id bigint(20) unsigned NOT NULL DEFAULT 0,
        category_id bigint(20) unsigned NOT NULL DEFAULT 0,
        description text NULL,
        reference varchar(190) NOT NULL DEFAULT '',
        source_type varchar(60) NOT NULL DEFAULT 'manual',
        source_id varchar(190) NOT NULL DEFAULT '',
        status varchar(30) NOT NULL DEFAULT 'posted',
        created_by bigint(20) unsigned NOT NULL DEFAULT 0,
        created_at datetime NOT NULL,
        updated_at datetime NOT NULL,
        PRIMARY KEY (id),
        KEY transaction_date (transaction_date),
        KEY type (type),
        KEY account_id (account_id),
        KEY destination_account_id (destination_account_id),
        KEY party_id (party_id),
        KEY category_id (category_id),
        KEY source (source_type, source_id),
        KEY status (status)
    ) {$charset};");

    dbDelta("CREATE TABLE {$checks} (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        check_type varchar(20) NOT NULL DEFAULT 'received',
        party_id bigint(20) unsigned NOT NULL DEFAULT 0,
        account_id bigint(20) unsigned NOT NULL DEFAULT 0,
        amount decimal(20,2) NOT NULL DEFAULT 0,
        check_number varchar(100) NOT NULL DEFAULT '',
        bank_name varchar(190) NOT NULL DEFAULT '',
        due_date date DEFAULT NULL,
        status varchar(30) NOT NULL DEFAULT 'pending',
        description text NULL,
        transaction_id bigint(20) unsigned NOT NULL DEFAULT 0,
        created_at datetime NOT NULL,
        updated_at datetime NOT NULL,
        PRIMARY KEY (id),
        KEY check_type (check_type),
        KEY party_id (party_id),
        KEY due_date (due_date),
        KEY status (status)
    ) {$charset};");

    bzc_finance_seed_categories();
    // Older versions stored WooCommerce gateway sales as income. They are now receivables from the gateway.
    $wpdb->query("UPDATE {$transactions} SET type='gateway_receivable' WHERE source_type='woocommerce_order' AND type='income'");
    update_option('bzc_finance_db_version', BZC_FINANCE_VERSION);
}

register_activation_hook(__FILE__, 'bzc_finance_install');
add_action('plugins_loaded', 'bzc_finance_maybe_install');
function bzc_finance_maybe_install() {
    if (get_option('bzc_finance_db_version') !== BZC_FINANCE_VERSION) {
        bzc_finance_install();
    }
}

function bzc_finance_seed_categories() {
    global $wpdb;
    $table = bzc_finance_table('categories');
    $defaults = [
        ['فروش کالا', 'income'], ['سایر درآمدها', 'income'],
        ['خرید کالا', 'expense'], ['تبلیغات', 'expense'], ['حقوق', 'expense'],
        ['اجاره', 'expense'], ['حمل و نقل', 'expense'], ['هاست و سرور', 'expense'],
        ['مالیات', 'expense'], ['کارمزد درگاه', 'expense'], ['قبض و خدمات', 'expense'],
        ['سایر هزینه‌ها', 'expense'],
    ];
    foreach ($defaults as $row) {
        $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE name=%s LIMIT 1", $row[0]));
        if (!$exists) {
            $now = current_time('mysql');
            $wpdb->insert($table, ['name' => $row[0], 'type' => $row[1], 'created_at' => $now]);
        }
    }
}

add_action('admin_menu', 'bzc_finance_admin_menu', 20);
function bzc_finance_admin_menu() {
    add_submenu_page('bz-accounting', 'حسابداری', '💰 حسابداری', 'manage_options', 'bz-accounting-finance', 'bzc_finance_render');
}

add_action('admin_enqueue_scripts', 'bzc_finance_assets');
function bzc_finance_assets($hook) {
    if (strpos($hook, 'bz-accounting-finance') === false) return;
    wp_enqueue_style('bzc-finance', BZC_PLUGIN_URL . 'accounting.css', [], BZC_FINANCE_VERSION);
    // Use the same bundled Persian datepicker assets as the legacy plugin.
    wp_enqueue_script('bzc-finance-date-fields', BZC_PLUGIN_URL . 'assets/js/accounting-finance.js', ['jquery', 'persian-date', 'persian-datepicker'], BZC_FINANCE_VERSION, true);
}

function bzc_finance_money($amount) {
    return number_format_i18n((float) $amount, 0) . ' تومان';
}

function bzc_finance_date($date = null) {
    $date = $date ?: current_time('Y-m-d');
    if (function_exists('bzc_convert_gregorian_to_persian_simple')) {
        return bzc_convert_gregorian_to_persian_simple($date);
    }
    return $date;
}

function bzc_finance_persian_to_gregorian_safe($date) {
    if (function_exists('bzc_persian_to_gregorian')) {
        return bzc_persian_to_gregorian($date);
    }
    return $date;
}

/**
 * Normalize dates entered in the accounting UI.
 * Storage remains Gregorian (YYYY-MM-DD), while the UI is always Persian.
 */
function bzc_finance_normalize_date_input($date, $allow_empty = false) {
    $date = sanitize_text_field(wp_unslash((string) $date));
    if ($date === '') {
        return $allow_empty ? null : '';
    }

    $date = strtr($date, [
        '۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9',
        '٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9',
    ]);
    $date = str_replace('/', '-', $date);

    if (!preg_match('/^(\d{4})-(\d{1,2})-(\d{1,2})$/', $date, $m)) {
        return $allow_empty ? null : '';
    }

    $year = (int) $m[1];
    $month = (int) $m[2];
    $day = (int) $m[3];
    $normalized = sprintf('%04d-%02d-%02d', $year, $month, $day);

    // Persian/Jalali year entered by the user.
    if ($year >= 1200 && $year <= 1600) {
        $gregorian = bzc_finance_persian_to_gregorian_safe($normalized);
        return $gregorian ?: ($allow_empty ? null : '');
    }

    // Keep Gregorian values for backward compatibility/imports.
    if ($year >= 1900 && $year <= 2200 && checkdate($month, $day, $year)) {
        return $normalized;
    }

    return $allow_empty ? null : '';
}

function bzc_finance_display_input_date($date = null) {
    $date = $date ?: current_time('Y-m-d');
    return bzc_finance_date($date);
}

function bzc_finance_get_accounts($active_only = false) {
    global $wpdb;
    $table = bzc_finance_table('accounts');
    $where = $active_only ? 'WHERE is_active=1' : '';
    return $wpdb->get_results("SELECT * FROM {$table} {$where} ORDER BY type, name", ARRAY_A);
}

function bzc_finance_get_parties($active_only = false) {
    global $wpdb;
    $table = bzc_finance_table('parties');
    $where = $active_only ? 'WHERE is_active=1' : '';
    return $wpdb->get_results("SELECT * FROM {$table} {$where} ORDER BY name", ARRAY_A);
}

function bzc_finance_get_categories($type = '') {
    global $wpdb;
    $table = bzc_finance_table('categories');
    if ($type) return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table} WHERE type=%s AND is_active=1 ORDER BY name", $type), ARRAY_A);
    return $wpdb->get_results("SELECT * FROM {$table} WHERE is_active=1 ORDER BY type, name", ARRAY_A);
}

function bzc_finance_account_balance($account_id) {
    global $wpdb;
    $t = bzc_finance_table('transactions');
    $a = bzc_finance_table('accounts');
    $account = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$a} WHERE id=%d", $account_id), ARRAY_A);
    if (!$account) return 0;
    $opening = (float) ($account['opening_balance'] ?? 0);
    if (($account['type'] ?? '') === 'gateway') {
        // A gateway is NOT a bank/cash account. Its balance represents money still receivable from the gateway.
        $receivable = (float) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM {$t} WHERE account_id=%d AND type='gateway_receivable' AND status='posted'", $account_id));
        $settled = (float) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM {$t} WHERE account_id=%d AND type='transfer_out' AND source_type='gateway_settlement' AND status='posted'", $account_id));
        return $opening + $receivable - $settled;
    }
    $in = (float) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM {$t} WHERE account_id=%d AND type IN ('income','payment_in','transfer_in') AND status='posted'", $account_id));
    $out = (float) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM {$t} WHERE account_id=%d AND type IN ('expense','transfer_out') AND status='posted'", $account_id));
    return $opening + $in - $out;
}

function bzc_finance_account_balance_rows() {
    $accounts = bzc_finance_get_accounts(true);
    foreach ($accounts as &$account) $account['balance'] = bzc_finance_account_balance((int) $account['id']);
    return $accounts;
}

function bzc_finance_totals() {
    global $wpdb;
    $t = bzc_finance_table('transactions');
    $income = (float) $wpdb->get_var("SELECT COALESCE(SUM(amount),0) FROM {$t} WHERE type='income' AND status='posted'");
    $expense = (float) $wpdb->get_var("SELECT COALESCE(SUM(amount),0) FROM {$t} WHERE type='expense' AND status='posted'");
    return ['income' => $income, 'expense' => $expense, 'net' => $income - $expense];
}

function bzc_finance_party_balances() {
    global $wpdb;
    $p = bzc_finance_table('parties');
    $t = bzc_finance_table('transactions');
    $parties = $wpdb->get_results("SELECT * FROM {$p} WHERE is_active=1 ORDER BY name", ARRAY_A);
    foreach ($parties as &$party) {
        $has_effect = (bool) $wpdb->get_var("SHOW COLUMNS FROM {$t} LIKE 'party_effect'");
        if ($has_effect) {
            $party['net'] = (float) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(party_effect),0) FROM {$t} WHERE party_id=%d AND status='posted'", $party['id']));
        } else {
            $income = (float) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM {$t} WHERE party_id=%d AND type='income' AND status='posted'", $party['id']));
            $expense = (float) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM {$t} WHERE party_id=%d AND type='expense' AND status='posted'", $party['id']));
            $party['net'] = $income - $expense;
        }
        $party['label'] = $party['net'] >= 0 ? 'خالص دریافتی' : 'خالص پرداختی';
    }
    return $parties;
}

function bzc_finance_handle_actions() {
    if (!current_user_can('manage_options')) return;
    if (empty($_POST['bzc_finance_action'])) return;
    check_admin_referer('bzc_finance_action', 'bzc_finance_nonce');
    global $wpdb;

    $action = sanitize_key($_POST['bzc_finance_action']);
    $now = current_time('mysql');
    $transaction_date = bzc_finance_normalize_date_input($_POST['transaction_date'] ?? '', false);
    $due_date = bzc_finance_normalize_date_input($_POST['due_date'] ?? '', true);

    if ($action === 'save_account') {
        $id = absint($_POST['id'] ?? 0);
        $type = sanitize_key($_POST['type'] ?? 'bank');
        $gateway_id = sanitize_text_field(wp_unslash($_POST['gateway_id'] ?? ''));
        $linked_bank_account_id = absint($_POST['linked_bank_account_id'] ?? 0);
        $name = sanitize_text_field(wp_unslash($_POST['name'] ?? ''));

        // Gateway accounts must be linked to a real WooCommerce gateway ID.
        // Never trust a manually typed/guessed ID because it can break sync with orders.
        if ($type === 'gateway') {
            $gateway_map = [];
            foreach (bzc_get_all_payment_gateways() as $gateway) {
                $gateway_map[$gateway['id']] = $gateway;
            }
            if ($gateway_id === '' || !isset($gateway_map[$gateway_id])) {
                return 'برای حساب درگاه، یک درگاه معتبر از لیست انتخاب کنید.';
            }
            // Keep the account name aligned with the actual WooCommerce gateway title.
            $name = $gateway_map[$gateway_id]['title'];
        } else {
            $gateway_id = '';
            $linked_bank_account_id = 0;
        }
        if ($type === 'gateway' && $linked_bank_account_id) {
            $linked_type = $wpdb->get_var($wpdb->prepare("SELECT type FROM " . bzc_finance_table('accounts') . " WHERE id=%d", $linked_bank_account_id));
            if ($linked_type !== 'bank') return 'حساب مقصد درگاه باید از نوع بانک باشد.';
        }

        $data = [
            'name' => $name,
            'type' => $type,
            'gateway_id' => $gateway_id,
            'linked_bank_account_id' => $linked_bank_account_id,
            'opening_balance' => (float) ($_POST['opening_balance'] ?? 0),
            'opening_date' => bzc_finance_normalize_date_input($_POST['opening_date'] ?? '', true),
            'notes' => sanitize_textarea_field(wp_unslash($_POST['notes'] ?? '')),
            'updated_at' => $now,
        ];
        if ($id) $wpdb->update(bzc_finance_table('accounts'), $data, ['id' => $id]);
        else { $data['created_at'] = $now; $wpdb->insert(bzc_finance_table('accounts'), $data); }
        return 'حساب مالی ذخیره شد.';
    }

    if ($action === 'save_party') {
        $id = absint($_POST['id'] ?? 0);
        $data = [
            'name' => sanitize_text_field(wp_unslash($_POST['name'] ?? '')),
            'type' => sanitize_key($_POST['type'] ?? 'other'),
            'phone' => sanitize_text_field(wp_unslash($_POST['phone'] ?? '')),
            'email' => sanitize_email($_POST['email'] ?? ''),
            'notes' => sanitize_textarea_field(wp_unslash($_POST['notes'] ?? '')),
            'updated_at' => $now,
        ];
        if ($id) $wpdb->update(bzc_finance_table('parties'), $data, ['id' => $id]);
        else { $data['created_at'] = $now; $wpdb->insert(bzc_finance_table('parties'), $data); }
        return 'طرف حساب ذخیره شد.';
    }

    if ($action === 'save_transaction') {
        $type = sanitize_key($_POST['type'] ?? 'expense');
        $amount = abs((float) ($_POST['amount'] ?? 0));
        $account_id = absint($_POST['account_id'] ?? 0);
        $dest = absint($_POST['destination_account_id'] ?? 0);
        if ($amount <= 0 || !$account_id) return 'مبلغ و حساب مبدا الزامی است.';
        if ($transaction_date === '') return 'تاریخ تراکنش معتبر نیست. تاریخ را به صورت شمسی وارد کنید.';
        if ($type === 'transfer' && (!$dest || $dest === $account_id)) return 'برای انتقال، حساب مقصد معتبر انتخاب کنید.';
        if ($type === 'transfer') {
            $transfer_group = 'manual_transfer_' . wp_generate_uuid4();
            $common = [
                'transaction_date' => $transaction_date,
                'amount' => $amount,
                'party_id' => absint($_POST['party_id'] ?? 0),
                'description' => sanitize_textarea_field(wp_unslash($_POST['description'] ?? '')),
                'reference' => sanitize_text_field(wp_unslash($_POST['reference'] ?? '')),
                'source_type' => 'manual_transfer', 'source_id' => $transfer_group, 'status' => 'posted',
                'created_by' => get_current_user_id(), 'created_at' => $now, 'updated_at' => $now,
            ];
            $wpdb->insert(bzc_finance_table('transactions'), array_merge($common, [
                'type' => 'transfer_out', 'account_id' => $account_id, 'destination_account_id' => $dest,
            ]));
            $wpdb->insert(bzc_finance_table('transactions'), array_merge($common, [
                'type' => 'transfer_in', 'account_id' => $dest, 'destination_account_id' => $account_id,
            ]));
        } else {
            $wpdb->insert(bzc_finance_table('transactions'), [
                'transaction_date' => $transaction_date,
                'type' => in_array($type, ['income','expense'], true) ? $type : 'expense',
                'amount' => $amount, 'account_id' => $account_id,
                'party_id' => absint($_POST['party_id'] ?? 0), 'category_id' => absint($_POST['category_id'] ?? 0),
                'description' => sanitize_textarea_field(wp_unslash($_POST['description'] ?? '')),
                'reference' => sanitize_text_field(wp_unslash($_POST['reference'] ?? '')),
                'source_type' => 'manual', 'source_id' => '', 'status' => 'posted',
                'created_by' => get_current_user_id(), 'created_at' => $now, 'updated_at' => $now,
            ]);
        }
        return 'تراکنش با موفقیت ثبت شد.';
    }

    if ($action === 'save_check') {
        $wpdb->insert(bzc_finance_table('checks'), [
            'check_type' => sanitize_key($_POST['check_type'] ?? 'received'),
            'party_id' => absint($_POST['party_id'] ?? 0), 'account_id' => absint($_POST['account_id'] ?? 0),
            'amount' => abs((float) ($_POST['amount'] ?? 0)),
            'check_number' => sanitize_text_field(wp_unslash($_POST['check_number'] ?? '')),
            'bank_name' => sanitize_text_field(wp_unslash($_POST['bank_name'] ?? '')),
            'due_date' => $due_date,
            'status' => sanitize_key($_POST['status'] ?? 'pending'),
            'description' => sanitize_textarea_field(wp_unslash($_POST['description'] ?? '')),
            'created_at' => $now, 'updated_at' => $now,
        ]);
        return 'چک ثبت شد.';
    }

    if ($action === 'edit_transaction') {
        $id = absint($_POST['id'] ?? 0);
        $row = $id ? $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . bzc_finance_table('transactions') . ' WHERE id=%d', $id), ARRAY_A) : null;
        if (!$row) return 'تراکنش پیدا نشد.';
        if (($row['source_type'] ?? '') !== 'manual' && ($row['source_type'] ?? '') !== 'manual_transfer') {
            return 'این تراکنش از منبع دیگری وارد شده و از اینجا قابل ویرایش نیست.';
        }
        $type = sanitize_key($_POST['type'] ?? $row['type']);
        $amount = abs((float) ($_POST['amount'] ?? 0));
        $account_id = absint($_POST['account_id'] ?? 0);
        $dest = absint($_POST['destination_account_id'] ?? 0);
        if ($amount <= 0 || !$account_id || $transaction_date === '') return 'مبلغ، حساب و تاریخ معتبر الزامی است.';
        $party_id = absint($_POST['party_id'] ?? 0);
        $category_id = absint($_POST['category_id'] ?? 0);
        $description = sanitize_textarea_field(wp_unslash($_POST['description'] ?? ''));
        $reference = sanitize_text_field(wp_unslash($_POST['reference'] ?? ''));
        $table = bzc_finance_table('transactions');

        if ($type === 'transfer') {
            if (!$dest || $dest === $account_id) return 'برای انتقال، حساب مقصد معتبر انتخاب کنید.';
            $group = (string) ($row['source_id'] ?? '');
            if ($group === '') $group = 'manual_transfer_' . wp_generate_uuid4();
            $wpdb->update($table, [
                'transaction_date' => $transaction_date, 'type' => 'transfer_out', 'amount' => $amount,
                'account_id' => $account_id, 'destination_account_id' => $dest, 'party_id' => $party_id,
                'category_id' => 0, 'description' => $description, 'reference' => $reference,
                'source_type' => 'manual_transfer', 'source_id' => $group, 'updated_at' => $now,
            ], ['id' => $id]);
            $pair = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE source_id=%s AND id<>%d AND type IN ('transfer_in','transfer_out') ORDER BY id LIMIT 1", $group, $id), ARRAY_A);
            $pair_data = [
                'transaction_date' => $transaction_date, 'type' => 'transfer_in', 'amount' => $amount,
                'account_id' => $dest, 'destination_account_id' => $account_id, 'party_id' => $party_id,
                'category_id' => 0, 'description' => $description, 'reference' => $reference,
                'source_type' => 'manual_transfer', 'source_id' => $group, 'updated_at' => $now,
            ];
            if ($pair) $wpdb->update($table, $pair_data, ['id' => $pair['id']]);
            else { $pair_data['created_by'] = get_current_user_id(); $pair_data['created_at'] = $now; $wpdb->insert($table, $pair_data); }
        } else {
            $normal_type = in_array($type, ['income','expense'], true) ? $type : 'expense';
            // If editing one side of a transfer, remove its paired row because it is no longer a transfer.
            if (($row['source_type'] ?? '') === 'manual_transfer' && !empty($row['source_id'])) {
                $wpdb->query($wpdb->prepare("DELETE FROM {$table} WHERE source_id=%s AND id<>%d", $row['source_id'], $id));
            }
            $wpdb->update($table, [
                'transaction_date' => $transaction_date, 'type' => $normal_type, 'amount' => $amount,
                'account_id' => $account_id, 'destination_account_id' => 0, 'party_id' => $party_id,
                'category_id' => $category_id, 'description' => $description, 'reference' => $reference,
                'source_type' => 'manual', 'source_id' => '', 'updated_at' => $now,
            ], ['id' => $id]);
        }
        return 'تراکنش ویرایش شد.';
    }

    if ($action === 'delete_transaction') {
        $id = absint($_POST['id'] ?? 0);
        $row = $id ? $wpdb->get_row($wpdb->prepare('SELECT * FROM ' . bzc_finance_table('transactions') . ' WHERE id=%d', $id), ARRAY_A) : null;
        if (!$row) return 'تراکنش پیدا نشد.';
        if (($row['source_type'] ?? '') !== 'manual' && ($row['source_type'] ?? '') !== 'manual_transfer') {
            return 'این تراکنش از منبع دیگری وارد شده و قابل حذف نیست.';
        }
        if (($row['source_type'] ?? '') === 'manual_transfer' && !empty($row['source_id'])) {
            $wpdb->query($wpdb->prepare('DELETE FROM ' . bzc_finance_table('transactions') . ' WHERE source_id=%s', $row['source_id']));
            return 'انتقال و هر دو تراکنش مرتبط با آن حذف شد.';
        }
        $wpdb->delete(bzc_finance_table('transactions'), ['id' => $id]);
        return 'تراکنش حذف شد.';
    }

    if ($action === 'delete_account') {
        $id = absint($_POST['id'] ?? 0);
        if (!$id) return 'حساب نامعتبر است.';
        $used_tx = (int) $wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM ' . bzc_finance_table('transactions') . ' WHERE account_id=%d OR destination_account_id=%d', $id, $id));
        $used_check = (int) $wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM ' . bzc_finance_table('checks') . ' WHERE account_id=%d', $id));
        if ($used_tx || $used_check) {
            $wpdb->update(bzc_finance_table('accounts'), ['is_active' => 0, 'updated_at' => $now], ['id' => $id]);
            return 'این حساب سابقه مالی دارد و برای حفظ سوابق حذف فیزیکی نشد؛ حساب غیرفعال شد.';
        }
        $wpdb->delete(bzc_finance_table('accounts'), ['id' => $id]);
        return 'حساب حذف شد.';
    }

    if ($action === 'delete_party') {
        $id = absint($_POST['id'] ?? 0);
        if (!$id) return 'طرف حساب نامعتبر است.';
        $used_tx = (int) $wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM ' . bzc_finance_table('transactions') . ' WHERE party_id=%d', $id));
        $used_check = (int) $wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM ' . bzc_finance_table('checks') . ' WHERE party_id=%d', $id));
        if ($used_tx || $used_check) {
            $wpdb->update(bzc_finance_table('parties'), ['is_active' => 0, 'updated_at' => $now], ['id' => $id]);
            return 'این طرف حساب سابقه مالی دارد و برای حفظ سوابق حذف فیزیکی نشد؛ غیرفعال شد.';
        }
        $wpdb->delete(bzc_finance_table('parties'), ['id' => $id]);
        return 'طرف حساب حذف شد.';
    }

    if ($action === 'sync_gateways') {
        return bzc_finance_sync_gateways();
    }

    return '';
}

function bzc_finance_sync_gateways() {
    global $wpdb;
    if (!class_exists('WooCommerce')) return 'WooCommerce فعال نیست.';
    $accounts_table = bzc_finance_table('accounts');
    $tx_table = bzc_finance_table('transactions');
    $payments = get_option('bzc_gateway_payments', []);
    $fees = get_option('bzc_gateways_fee', []);
    $created = 0;
    $gateways = bzc_get_all_payment_gateways();

    // Repair legacy/manual gateway accounts that were created before the gateway
    // selector existed. Matching is done by the real WooCommerce gateway title,
    // so the existing account is linked instead of creating a duplicate.
    $legacy_gateway_accounts = $wpdb->get_results("SELECT id, name FROM {$accounts_table} WHERE type='gateway' AND (gateway_id='' OR gateway_id IS NULL)", ARRAY_A);
    foreach ($legacy_gateway_accounts as $account) {
        foreach ($gateways as $gateway) {
            if (trim((string) $account['name']) === trim((string) $gateway['title'])) {
                $wpdb->update($accounts_table, ['gateway_id' => $gateway['id'], 'updated_at' => current_time('mysql')], ['id' => (int) $account['id']]);
                break;
            }
        }
    }

    foreach ($gateways as $gateway) {
        $existing = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$accounts_table} WHERE type='gateway' AND gateway_id=%s LIMIT 1", $gateway['id']));
        if (!$existing) {
            $now = current_time('mysql');
            $wpdb->insert($accounts_table, ['name' => $gateway['title'], 'type' => 'gateway', 'gateway_id' => $gateway['id'], 'created_at' => $now, 'updated_at' => $now]);
        }
    }

    $orders = wc_get_orders(['limit' => -1, 'return' => 'objects', 'status' => ['wc-processing','wc-sent','wc-completed'], 'type' => 'shop_order']);
    foreach ($orders as $order) {
        $gateway_id = method_exists($order, 'get_payment_method') ? $order->get_payment_method() : '';
        if (!$gateway_id) continue;
        $account_id = (int) $wpdb->get_var($wpdb->prepare("SELECT id FROM {$accounts_table} WHERE type='gateway' AND gateway_id=%s LIMIT 1", $gateway_id));
        if (!$account_id) continue;
        $order_id = (string) $order->get_id();
        $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$tx_table} WHERE source_type='woocommerce_order' AND source_id=%s LIMIT 1", $order_id));
        if ($exists) continue;
        $amount = (float) $order->get_total();
        if ($amount <= 0) continue;
        $created_date = $order->get_date_created();
        $date = $created_date ? $created_date->date('Y-m-d') : current_time('Y-m-d');
        $party_id = 0;
        $customer_id = (int) $order->get_customer_id();
        $customer_name = trim((string) $order->get_formatted_billing_full_name());
        if ($customer_name) {
            $party_id = (int) $wpdb->get_var($wpdb->prepare("SELECT id FROM " . bzc_finance_table('parties') . " WHERE name=%s LIMIT 1", $customer_name));
            if (!$party_id) {
                $now = current_time('mysql');
                $wpdb->insert(bzc_finance_table('parties'), ['name' => $customer_name, 'type' => 'customer', 'phone' => (string) $order->get_billing_phone(), 'email' => (string) $order->get_billing_email(), 'created_at' => $now, 'updated_at' => $now]);
                $party_id = (int) $wpdb->insert_id;
            }
        }
        $now = current_time('mysql');
        $wpdb->insert($tx_table, [
            'transaction_date' => $date, 'type' => 'gateway_receivable', 'amount' => $amount, 'account_id' => $account_id,
            'party_id' => $party_id, 'description' => 'فروش سفارش #' . $order_id, 'reference' => $order_id,
            'source_type' => 'woocommerce_order', 'source_id' => $order_id, 'status' => 'posted',
            'created_by' => get_current_user_id(), 'created_at' => $now, 'updated_at' => $now,
        ]);
        $created++;
    }

    // Legacy settlement records are no longer auto-imported because a gateway is not a bank account.
    // New settlements are recorded through the dedicated settlement flow.
    $bank_id = (int) $wpdb->get_var("SELECT id FROM {$accounts_table} WHERE type='bank' AND is_active=1 ORDER BY id LIMIT 1");
    if (false && $bank_id) {
        foreach ($payments as $payment) {
            if (($payment['type'] ?? 'payment') === 'fee_adjustment') continue;
            $gateway_id = sanitize_text_field($payment['gateway_id'] ?? '');
            $amount = abs((float) ($payment['amount'] ?? 0));
            $date_p = sanitize_text_field($payment['date'] ?? '');
            if (!$gateway_id || $amount <= 0 || !$date_p) continue;
            $gateway_account = (int) $wpdb->get_var($wpdb->prepare("SELECT id FROM {$accounts_table} WHERE type='gateway' AND gateway_id=%s LIMIT 1", $gateway_id));
            if (!$gateway_account) continue;
            $source_id = 'legacy_gateway_payment_' . sanitize_text_field($payment['id'] ?? md5($gateway_id . $date_p . $amount));
            $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$tx_table} WHERE source_type='legacy_gateway_payment' AND source_id=%s LIMIT 1", $source_id));
            if ($exists) continue;
            $date_g = bzc_finance_persian_to_gregorian_safe($date_p);
            $now = current_time('mysql');
            $description = 'تسویه درگاه' . (!empty($payment['note']) ? ' - ' . sanitize_text_field($payment['note']) : '');
            $wpdb->insert($tx_table, ['transaction_date' => $date_g, 'type' => 'transfer_out', 'amount' => $amount, 'account_id' => $gateway_account, 'destination_account_id' => $bank_id, 'description' => $description, 'reference' => $source_id, 'source_type' => 'legacy_gateway_payment', 'source_id' => $source_id, 'status' => 'posted', 'created_by' => get_current_user_id(), 'created_at' => $now, 'updated_at' => $now]);
            $wpdb->insert($tx_table, ['transaction_date' => $date_g, 'type' => 'transfer_in', 'amount' => $amount, 'account_id' => $bank_id, 'destination_account_id' => $gateway_account, 'description' => $description, 'reference' => $source_id, 'source_type' => 'legacy_gateway_payment', 'source_id' => $source_id, 'status' => 'posted', 'created_by' => get_current_user_id(), 'created_at' => $now, 'updated_at' => $now]);
            $created++;
        }
    }
    return "همگام‌سازی انجام شد؛ {$created} مورد جدید اضافه شد.";
}

function bzc_finance_render() {
    if (!current_user_can('manage_options')) wp_die('دسترسی غیرمجاز');
    $message = bzc_finance_handle_actions();
    $tab = sanitize_key($_GET['tab'] ?? 'dashboard');
    $tabs = [
        'dashboard' => '📊 داشبورد', 'accounts' => '🏦 حساب‌ها', 'parties' => '👥 طرف حساب‌ها',
        'transactions' => '🧾 تراکنش‌ها', 'checks' => '📄 چک‌ها', 'reports' => '📈 گزارش‌ها',
    ];
    if (!isset($tabs[$tab])) $tab = 'dashboard';
    ?>
    <div class="wrap bzc-finance-wrap" dir="rtl">
        <div class="bzc-finance-head"><div><h1>💰 حسابداری</h1><p>مدیریت پول، درآمد، هزینه، حساب‌ها، طرف حساب‌ها و درگاه‌ها</p></div><div class="bzc-finance-actions"><form method="post"><?php wp_nonce_field('bzc_finance_action','bzc_finance_nonce'); ?><input type="hidden" name="bzc_finance_action" value="sync_gateways"><button class="button button-primary">🔄 همگام‌سازی درگاه‌ها</button></form></div></div>
        <?php if ($message): ?><div class="notice notice-success is-dismissible"><p>✅ <?php echo esc_html($message); ?></p></div><?php endif; ?>
        <nav class="bzc-finance-tabs"><?php foreach ($tabs as $key=>$label): ?><a class="<?php echo $tab === $key ? 'active' : ''; ?>" href="<?php echo esc_url(add_query_arg(['page'=>'bz-accounting-finance','tab'=>$key], admin_url('admin.php'))); ?>"><?php echo esc_html($label); ?></a><?php endforeach; ?></nav>
        <?php call_user_func('bzc_finance_tab_' . $tab); ?>
    </div>
    <?php
}

function bzc_finance_tab_dashboard() {
    $totals = bzc_finance_totals(); $accounts = bzc_finance_account_balance_rows(); $parties = bzc_finance_party_balances();
    $cash = 0; $gateway_claims = 0;
    foreach ($accounts as $a) {
        if (in_array(($a['type'] ?? ''), ['bank','cash','other'], true)) $cash += (float)$a['balance'];
        if (($a['type'] ?? '') === 'gateway') $gateway_claims += max(0, (float)$a['balance']);
    }
    $claims = $gateway_claims; $debts = 0; foreach ($parties as $p) { if ($p['net'] > 0) $claims += $p['net']; else $debts += abs($p['net']); }
    ?>
    <div class="bzc-finance-cards">
        <div class="bzc-finance-card"><span>💵 موجودی واقعی بانک/صندوق</span><strong><?php echo bzc_finance_money($cash); ?></strong></div>
        <div class="bzc-finance-card"><span>📥 مجموع درآمد</span><strong><?php echo bzc_finance_money($totals['income']); ?></strong></div>
        <div class="bzc-finance-card"><span>📤 مجموع هزینه</span><strong><?php echo bzc_finance_money($totals['expense']); ?></strong></div>
        <div class="bzc-finance-card"><span>📈 خالص درآمد</span><strong><?php echo bzc_finance_money($totals['net']); ?></strong></div>
        <div class="bzc-finance-card"><span>🏦 طلب از درگاه‌ها</span><strong><?php echo bzc_finance_money($gateway_claims); ?></strong></div>
        <div class="bzc-finance-card"><span>💰 مجموع طلب‌ها</span><strong><?php echo bzc_finance_money($claims); ?></strong></div>
        <div class="bzc-finance-card"><span>💳 بدهی تقریبی</span><strong><?php echo bzc_finance_money($debts); ?></strong></div>
    </div>
    <div class="bzc-finance-grid">
        <section class="bzc-finance-panel"><h2>🏦 موجودی حساب‌ها</h2><?php if (!$accounts): ?><p class="muted">هنوز حسابی ثبت نشده.</p><?php else: ?><table class="widefat striped"><thead><tr><th>حساب</th><th>نوع</th><th>موجودی</th></tr></thead><tbody><?php foreach($accounts as $a): ?><tr><td><?php echo esc_html($a['name']); ?></td><td><?php echo esc_html(bzc_finance_account_type_label($a['type'])); ?></td><td><strong><?php echo bzc_finance_money($a['balance']); ?></strong></td></tr><?php endforeach; ?></tbody></table><?php endif; ?></section>
        <section class="bzc-finance-panel"><h2>👥 وضعیت طرف حساب‌ها</h2><?php if (!$parties): ?><p class="muted">هنوز طرف حسابی ثبت نشده.</p><?php else: ?><table class="widefat striped"><thead><tr><th>طرف حساب</th><th>وضعیت</th><th>مبلغ</th></tr></thead><tbody><?php foreach(array_slice($parties,0,10) as $p): ?><tr><td><?php echo esc_html($p['name']); ?></td><td><?php echo esc_html($p['label']); ?></td><td><?php echo bzc_finance_money(abs($p['net'])); ?></td></tr><?php endforeach; ?></tbody></table><?php endif; ?></section>
    </div>
    <?php
}

function bzc_finance_account_type_label($type) { return ['bank'=>'بانک','cash'=>'صندوق','gateway'=>'درگاه (طلب)','other'=>'سایر'][$type] ?? $type; }
function bzc_finance_party_type_label($type) { return ['customer'=>'مشتری','supplier'=>'تأمین‌کننده','person'=>'شخص','other'=>'سایر'][$type] ?? $type; }

function bzc_finance_tab_accounts() {
    $accounts = bzc_finance_account_balance_rows(); $edit = absint($_GET['edit'] ?? 0); $editing = null;
    foreach($accounts as $a) if((int)$a['id']===$edit) $editing=$a;
    ?>
    <div class="bzc-finance-grid">
    <?php $gateway_options = class_exists('WooCommerce') ? bzc_get_all_payment_gateways() : []; $bank_options = array_values(array_filter(bzc_finance_get_accounts(true), function($a){ return ($a['type'] ?? '') === 'bank'; })); ?>
    <section class="bzc-finance-panel"><h2><?php echo $editing ? 'ویرایش حساب' : '➕ افزودن حساب'; ?></h2><form method="post" class="bzc-form-grid"><?php wp_nonce_field('bzc_finance_action','bzc_finance_nonce'); ?><input type="hidden" name="bzc_finance_action" value="save_account"><input type="hidden" name="id" value="<?php echo esc_attr($editing['id'] ?? 0); ?>"><label>نام حساب<input required id="bzc-finance-account-name" name="name" value="<?php echo esc_attr($editing['name'] ?? ''); ?>"></label><label>نوع<select name="type" id="bzc-finance-account-type"><option value="bank" <?php selected($editing['type'] ?? '', 'bank'); ?>>بانک</option><option value="cash" <?php selected($editing['type'] ?? '', 'cash'); ?>>صندوق</option><option value="gateway" <?php selected($editing['type'] ?? '', 'gateway'); ?>>درگاه (مطالبه)</option><option value="other" <?php selected($editing['type'] ?? '', 'other'); ?>>سایر</option></select></label><label id="bzc-finance-gateway-field">درگاه ووکامرس<select name="gateway_id" id="bzc-finance-gateway-id"><option value="">انتخاب درگاه</option><?php foreach ($gateway_options as $gateway): ?><option value="<?php echo esc_attr($gateway['id']); ?>" <?php selected($editing['gateway_id'] ?? '', $gateway['id']); ?>><?php echo esc_html($gateway['title']); ?><?php echo empty($gateway['is_active']) ? ' (غیرفعال)' : ''; ?></option><?php endforeach; ?></select><small class="description">درگاه حساب بانکی نیست؛ فقط طلب شما از درگاه را نگه می‌دارد.</small></label><label id="bzc-finance-linked-bank-field">حساب بانکی مقصد<select name="linked_bank_account_id"><option value="0">انتخاب بانک</option><?php foreach ($bank_options as $bank): ?><option value="<?php echo esc_attr($bank['id']); ?>" <?php selected((int)($editing['linked_bank_account_id'] ?? 0), (int)$bank['id']); ?>><?php echo esc_html($bank['name']); ?></option><?php endforeach; ?></select><small class="description">تسویه این درگاه به این حساب بانکی متصل می‌شود.</small></label><label>موجودی اولیه<input type="number" step="0.01" name="opening_balance" value="<?php echo esc_attr($editing['opening_balance'] ?? 0); ?>"></label><label>تاریخ موجودی<input name="opening_date" value="<?php echo esc_attr(!empty($editing['opening_date']) ? bzc_finance_display_input_date($editing['opening_date']) : ''); ?>" placeholder="۱۴۰۵-۰۱-۰۱"></label><label class="full">توضیحات<textarea name="notes"><?php echo esc_textarea($editing['notes'] ?? ''); ?></textarea></label><div class="full"><button class="button button-primary">💾 ذخیره حساب</button></div></form></section>
    <section class="bzc-finance-panel"><h2>حساب‌های ثبت‌شده</h2><table class="widefat striped"><thead><tr><th>نام</th><th>نوع</th><th>حساب مقصد</th><th>موجودی / طلب</th><th>عملیات</th></tr></thead><tbody><?php foreach($accounts as $a): ?><tr><td><?php echo esc_html($a['name']); ?></td><td><?php echo esc_html(bzc_finance_account_type_label($a['type'])); ?></td><td><?php if (($a['type'] ?? '') === 'gateway' && !empty($a['linked_bank_account_id'])) { $linked = $wpdb->get_var($wpdb->prepare("SELECT name FROM " . bzc_finance_table('accounts') . " WHERE id=%d", (int)$a['linked_bank_account_id'])); echo esc_html($linked ?: '-'); } else { echo '-'; } ?></td><td><?php echo bzc_finance_money($a['balance']); ?><?php if (($a['type'] ?? '') === 'gateway') echo ' <small>(طلب از درگاه)</small>'; ?></td><td class="bzc-finance-actions-cell"><a class="button button-small" href="<?php echo esc_url(add_query_arg(['page'=>'bz-accounting-finance','tab'=>'accounts','edit'=>$a['id']], admin_url('admin.php'))); ?>">ویرایش</a> <form method="post" style="display:inline" onsubmit="return confirm('این حساب حذف شود؟ اگر سابقه مالی داشته باشد فقط غیرفعال می‌شود.');"><?php wp_nonce_field('bzc_finance_action','bzc_finance_nonce'); ?><input type="hidden" name="bzc_finance_action" value="delete_account"><input type="hidden" name="id" value="<?php echo esc_attr($a['id']); ?>"><button class="button button-small" type="submit">حذف</button></form></td></tr><?php endforeach; ?></tbody></table></section>
    </div>
    <script>
    jQuery(function($){
        const $type = $('#bzc-finance-account-type');
        const $gateway = $('#bzc-finance-gateway-field');
        const $gatewaySelect = $('#bzc-finance-gateway-id');
        const $name = $('#bzc-finance-account-name');
        function syncGatewayField() {
            const isGateway = $type.val() === 'gateway';
            $gateway.toggle(isGateway);
            $gatewaySelect.prop('required', isGateway);
            if (!isGateway) $gatewaySelect.val('');
        }
        $type.on('change', syncGatewayField);
        $gatewaySelect.on('change', function(){
            const title = $(this).find('option:selected').text().replace(/\s*\(غیرفعال\)\s*$/, '').trim();
            if (this.value && title) $name.val(title);
        });
        syncGatewayField();
        $('#bzc-finance-linked-bank-field').toggle($type.val() === 'gateway');
    });
    </script>
    <?php
}

function bzc_finance_tab_parties() {
    $parties = bzc_finance_party_balances();
    $edit = absint($_GET['edit'] ?? 0); $editing = null;
    foreach ($parties as $p) if ((int)$p['id'] === $edit) { $editing = $p; break; }
    ?>
    <div class="bzc-finance-grid">
        <section class="bzc-finance-panel"><h2><?php echo $editing ? 'ویرایش طرف حساب' : '➕ افزودن طرف حساب'; ?></h2><form method="post" class="bzc-form-grid"><?php wp_nonce_field('bzc_finance_action','bzc_finance_nonce'); ?><input type="hidden" name="bzc_finance_action" value="save_party"><input type="hidden" name="id" value="<?php echo esc_attr($editing['id'] ?? 0); ?>"><label>نام / عنوان<input required name="name" value="<?php echo esc_attr($editing['name'] ?? ''); ?>"></label><label>نوع<select name="type"><option value="customer" <?php selected($editing['type'] ?? '', 'customer'); ?>>مشتری</option><option value="supplier" <?php selected($editing['type'] ?? '', 'supplier'); ?>>تأمین‌کننده</option><option value="person" <?php selected($editing['type'] ?? '', 'person'); ?>>شخص</option><option value="other" <?php selected($editing['type'] ?? '', 'other'); ?>>سایر</option></select></label><label>تلفن<input name="phone" value="<?php echo esc_attr($editing['phone'] ?? ''); ?>"></label><label>ایمیل<input type="email" name="email" value="<?php echo esc_attr($editing['email'] ?? ''); ?>"></label><label class="full">یادداشت<textarea name="notes"><?php echo esc_textarea($editing['notes'] ?? ''); ?></textarea></label><div class="full"><button class="button button-primary">💾 <?php echo $editing ? 'ذخیره تغییرات' : 'ثبت طرف حساب'; ?></button><?php if ($editing): ?> <a class="button" href="<?php echo esc_url(add_query_arg(['page'=>'bz-accounting-finance','tab'=>'parties'], admin_url('admin.php'))); ?>">انصراف</a><?php endif; ?></div></form></section>
        <section class="bzc-finance-panel"><h2>طرف حساب‌ها</h2><table class="widefat striped"><thead><tr><th>نام</th><th>نوع</th><th>وضعیت</th><th>مبلغ</th><th>عملیات</th></tr></thead><tbody><?php foreach($parties as $p): ?><tr><td><?php echo esc_html($p['name']); ?></td><td><?php echo esc_html(bzc_finance_party_type_label($p['type'])); ?></td><td><?php echo esc_html($p['label']); ?></td><td><?php echo bzc_finance_money(abs($p['net'])); ?></td><td class="bzc-finance-actions-cell"><a class="button button-small" href="<?php echo esc_url(add_query_arg(['page'=>'bz-accounting-finance','tab'=>'parties','edit'=>$p['id']], admin_url('admin.php'))); ?>">ویرایش</a> <form method="post" style="display:inline" onsubmit="return confirm('این طرف حساب حذف شود؟ اگر سابقه مالی داشته باشد فقط غیرفعال می‌شود.');"><?php wp_nonce_field('bzc_finance_action','bzc_finance_nonce'); ?><input type="hidden" name="bzc_finance_action" value="delete_party"><input type="hidden" name="id" value="<?php echo esc_attr($p['id']); ?>"><button class="button button-small" type="submit">حذف</button></form></td></tr><?php endforeach; ?></tbody></table></section>
    </div>
    <?php
}

function bzc_finance_tab_transactions() {
    global $wpdb; $accounts=bzc_finance_get_accounts(true); $parties=bzc_finance_get_parties(true); $categories=bzc_finance_get_categories(); $t=bzc_finance_table('transactions');
    $edit = absint($_GET['edit'] ?? 0); $editing = $edit ? $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE id=%d", $edit), ARRAY_A) : null;
    $rows=$wpdb->get_results("SELECT t.*, a.name account_name, p.name party_name, c.name category_name FROM {$t} t LEFT JOIN ".bzc_finance_table('accounts')." a ON a.id=t.account_id LEFT JOIN ".bzc_finance_table('parties')." p ON p.id=t.party_id LEFT JOIN ".bzc_finance_table('categories')." c ON c.id=t.category_id ORDER BY t.transaction_date DESC, t.id DESC LIMIT 100", ARRAY_A);
    $form_type = $editing ? (in_array($editing['type'], ['transfer_in','transfer_out'], true) ? 'transfer' : $editing['type']) : 'income';
    ?>
    <section class="bzc-finance-panel"><h2><?php echo $editing ? '✏️ ویرایش تراکنش' : '➕ ثبت تراکنش'; ?></h2><form method="post" class="bzc-form-grid"><input type="hidden" name="bzc_finance_action" value="<?php echo $editing ? 'edit_transaction' : 'save_transaction'; ?>"><?php wp_nonce_field('bzc_finance_action','bzc_finance_nonce'); ?><?php if($editing): ?><input type="hidden" name="id" value="<?php echo esc_attr($editing['id']); ?>"><?php endif; ?><label>تاریخ<input required type="text" class="bzc-persian-datepicker bzc-finance-persian-date" autocomplete="off" name="transaction_date" value="<?php echo esc_attr($editing ? bzc_finance_display_input_date($editing['transaction_date']) : bzc_finance_display_input_date()); ?>" placeholder="۱۴۰۵-۰۱-۰۱"></label><label>نوع<select name="type" id="bzc-finance-tx-type"><option value="income" <?php selected($form_type,'income'); ?>>درآمد</option><option value="expense" <?php selected($form_type,'expense'); ?>>هزینه</option><option value="transfer" <?php selected($form_type,'transfer'); ?>>انتقال بین حساب‌ها</option></select></label><label>مبلغ<input required type="number" min="1" step="0.01" name="amount" value="<?php echo esc_attr($editing['amount'] ?? ''); ?>"></label><label>حساب مبدا / دریافت‌کننده<select required name="account_id"><option value="">انتخاب کنید</option><?php foreach($accounts as $a): ?><option value="<?php echo $a['id']; ?>" <?php selected($editing['account_id'] ?? 0, $a['id']); ?>><?php echo esc_html($a['name']); ?></option><?php endforeach; ?></select></label><label>حساب مقصد (برای انتقال)<select name="destination_account_id"><option value="">انتخاب کنید</option><?php foreach($accounts as $a): ?><option value="<?php echo $a['id']; ?>" <?php selected($editing['destination_account_id'] ?? 0, $a['id']); ?>><?php echo esc_html($a['name']); ?></option><?php endforeach; ?></select></label><label>طرف حساب<select name="party_id"><option value="0">بدون طرف حساب</option><?php foreach($parties as $p): ?><option value="<?php echo $p['id']; ?>" <?php selected($editing['party_id'] ?? 0, $p['id']); ?>><?php echo esc_html($p['name']); ?></option><?php endforeach; ?></select></label><label>دسته‌بندی<select name="category_id"><option value="0">بدون دسته‌بندی</option><?php foreach($categories as $c): ?><option value="<?php echo $c['id']; ?>" <?php selected($editing['category_id'] ?? 0, $c['id']); ?>><?php echo esc_html($c['name']); ?></option><?php endforeach; ?></select></label><label>مرجع<input name="reference" value="<?php echo esc_attr($editing['reference'] ?? ''); ?>"></label><label class="full">توضیحات<textarea name="description"><?php echo esc_textarea($editing['description'] ?? ''); ?></textarea></label><div class="full"><button class="button button-primary">💾 <?php echo $editing ? 'ذخیره تغییرات' : 'ثبت تراکنش'; ?></button><?php if($editing): ?> <a class="button" href="<?php echo esc_url(add_query_arg(['page'=>'bz-accounting-finance','tab'=>'transactions'], admin_url('admin.php'))); ?>">انصراف</a><?php endif; ?></div></form></section>
    <section class="bzc-finance-panel"><h2>آخرین تراکنش‌ها</h2><table class="widefat striped"><thead><tr><th>تاریخ</th><th>نوع</th><th>حساب</th><th>طرف حساب</th><th>دسته‌بندی</th><th>مبلغ</th><th>شرح</th><th>عملیات</th></tr></thead><tbody><?php foreach($rows as $r): ?><tr><td><?php echo esc_html(bzc_finance_date($r['transaction_date'])); ?></td><td><?php echo esc_html(bzc_finance_tx_label($r['type'])); ?></td><td><?php echo esc_html($r['account_name']); ?></td><td><?php echo esc_html($r['party_name'] ?: '—'); ?></td><td><?php echo esc_html($r['category_name'] ?: '—'); ?></td><td><?php echo bzc_finance_money($r['amount']); ?></td><td><?php echo esc_html($r['description']); ?></td><td class="bzc-finance-actions-cell"><a class="button button-small" href="<?php echo esc_url(add_query_arg(['page'=>'bz-accounting-finance','tab'=>'transactions','edit'=>$r['id']], admin_url('admin.php'))); ?>">ویرایش</a> <form method="post" style="display:inline" onsubmit="return confirm('این تراکنش حذف شود؟ در صورت انتقال، هر دو طرف انتقال حذف می‌شوند.');"><?php wp_nonce_field('bzc_finance_action','bzc_finance_nonce'); ?><input type="hidden" name="bzc_finance_action" value="delete_transaction"><input type="hidden" name="id" value="<?php echo esc_attr($r['id']); ?>"><button class="button button-small" type="submit">حذف</button></form></td></tr><?php endforeach; ?></tbody></table></section>
    <?php
}

function bzc_finance_tx_label($type) { return ['income'=>'📥 درآمد','expense'=>'📤 هزینه','transfer_in'=>'↙️ انتقال ورودی','transfer_out'=>'↗️ انتقال خروجی'][$type] ?? $type; }

function bzc_finance_tab_checks() {
    $parties=bzc_finance_get_parties(true); $accounts=bzc_finance_get_accounts(true); global $wpdb; $c=bzc_finance_table('checks');
    $rows=$wpdb->get_results("SELECT c.*, p.name party_name FROM {$c} c LEFT JOIN ".bzc_finance_table('parties')." p ON p.id=c.party_id ORDER BY c.due_date ASC, c.id DESC LIMIT 100", ARRAY_A);
    ?><div class="bzc-finance-grid"><section class="bzc-finance-panel"><h2>➕ ثبت چک</h2><form method="post" class="bzc-form-grid"><?php wp_nonce_field('bzc_finance_action','bzc_finance_nonce'); ?><input type="hidden" name="bzc_finance_action" value="save_check"><label>نوع<select name="check_type"><option value="received">دریافتی</option><option value="paid">پرداختی</option></select></label><label>طرف حساب<select name="party_id"><option value="0">انتخاب کنید</option><?php foreach($parties as $p): ?><option value="<?php echo $p['id']; ?>"><?php echo esc_html($p['name']); ?></option><?php endforeach; ?></select></label><label>حساب مرتبط<select name="account_id"><option value="0">انتخاب کنید</option><?php foreach($accounts as $a): ?><option value="<?php echo $a['id']; ?>"><?php echo esc_html($a['name']); ?></option><?php endforeach; ?></select></label><label>مبلغ<input required type="number" min="1" name="amount"></label><label>شماره چک<input name="check_number"></label><label>بانک<input name="bank_name"></label><label>سررسید<input type="text" class="bzc-persian-datepicker bzc-finance-persian-date" autocomplete="off" name="due_date" value="<?php echo esc_attr(bzc_finance_display_input_date()); ?>" placeholder="۱۴۰۵-۰۱-۰۱"></label><label>وضعیت<select name="status"><option value="pending">در انتظار</option><option value="cleared">وصول/پرداخت شد</option><option value="returned">برگشت خورد</option><option value="cancelled">لغو شد</option></select></label><label class="full">توضیحات<textarea name="description"></textarea></label><div class="full"><button class="button button-primary">💾 ثبت چک</button></div></form></section><section class="bzc-finance-panel"><h2>چک‌ها</h2><table class="widefat striped"><thead><tr><th>نوع</th><th>طرف حساب</th><th>مبلغ</th><th>شماره</th><th>سررسید</th><th>وضعیت</th></tr></thead><tbody><?php foreach($rows as $r): ?><tr><td><?php echo $r['check_type']==='received'?'دریافتی':'پرداختی'; ?></td><td><?php echo esc_html($r['party_name'] ?: '—'); ?></td><td><?php echo bzc_finance_money($r['amount']); ?></td><td><?php echo esc_html($r['check_number']); ?></td><td><?php echo esc_html(bzc_finance_date($r['due_date'])); ?></td><td><?php echo esc_html(bzc_finance_check_status($r['status'])); ?></td></tr><?php endforeach; ?></tbody></table></section></div><?php
}
function bzc_finance_check_status($s){return ['pending'=>'در انتظار','cleared'=>'تسویه شد','returned'=>'برگشت خورد','cancelled'=>'لغو شد'][$s]??$s;}

function bzc_finance_tab_reports() {
    global $wpdb; $t=bzc_finance_table('transactions');
    $monthly=$wpdb->get_results("SELECT DATE_FORMAT(transaction_date,'%Y-%m') ym, type, SUM(amount) total FROM {$t} WHERE status='posted' AND transaction_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH) AND type IN ('income','expense') GROUP BY ym,type ORDER BY ym DESC", ARRAY_A);
    $rows=[]; foreach($monthly as $r){$rows[$r['ym']][$r['type']]=(float)$r['total'];}
    ?><section class="bzc-finance-panel"><h2>📈 گزارش درآمد و هزینه ۱۲ ماه اخیر</h2><table class="widefat striped"><thead><tr><th>ماه</th><th>درآمد</th><th>هزینه</th><th>خالص</th></tr></thead><tbody><?php foreach($rows as $ym=>$r): $inc=$r['income']??0;$exp=$r['expense']??0; ?><tr><td><?php echo esc_html($ym); ?></td><td><?php echo bzc_finance_money($inc); ?></td><td><?php echo bzc_finance_money($exp); ?></td><td><strong><?php echo bzc_finance_money($inc-$exp); ?></strong></td></tr><?php endforeach; ?></tbody></table></section><?php
}
