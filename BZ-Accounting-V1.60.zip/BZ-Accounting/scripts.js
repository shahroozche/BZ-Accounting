jQuery(document).ready(function($) {
    
    // ========== توابع کمکی ==========
    
    function numberFormat(num) {
        if (num === undefined || num === null) return '0';
        return Math.round(num).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }
    
    function getGatewayName(gatewayId) {
        const gateways = {
            'cod': 'پرداخت در محل',
            'zarinpal': 'زرین پال',
            'payir': 'پی آیر',
            'idpay': 'آیدی پی',
            'nextpay': 'نکست پی',
            'saman': 'سامان',
            'mellat': 'ملت',
            'manual': '📝 ثبت دستی',
            'WC_Gateway_TorobPay': 'ترب پی',
            'WC_Domino_Zibal_Gateway': 'زیبال',
            'wc_zibal': 'زیبال',
            'WCDigiPay': 'دیجی پی'
        };
        return gateways[gatewayId] || gatewayId;
    }
    
    function getStatusText(status) {
        const statusMap = {
            'wc-processing': '🟡 درحال آماده سازی',
            'wc-sent': '📦 ارسال شد',
            'wc-pending': '⏳ در انتظار',
            'wc-completed': '✅ تکمیل شده',
            'wc-on-hold': '🔒 در انتظار بررسی',
            'wc-checkout-draft': '📝 پیش‌نویس'
        };
        return statusMap[status] || status;
    }
    
    // ========== سیستم Toast Notification ==========
    function bzcShowToast(message, type = 'success', duration = 3500) {
        $('.bzc-toast').remove();
        
        let icon = '✅';
        if (type === 'error') icon = '❌';
        else if (type === 'info') icon = 'ℹ️';
        else if (type === 'warning') icon = '⚠️';
        
        let toast = $(`
            <div class="bzc-toast ${type}">
                <span>${icon}</span>
                <span>${message}</span>
                <button class="toast-close">✕</button>
            </div>
        `);
        
        $('body').append(toast);
        
        toast.find('.toast-close').on('click', function() {
            toast.fadeOut(300, function() { $(this).remove(); });
        });
        
        setTimeout(function() {
            toast.fadeOut(300, function() { $(this).remove(); });
        }, duration);
    }
    
    // ========== توابع تاریخ شمسی ==========
    
    function toPersianDate(gregorianDate) {
        if (!gregorianDate) return '';
        try {
            var date = new Date(gregorianDate);
            if (isNaN(date.getTime())) return gregorianDate;
            return date.toLocaleDateString('fa-IR', {
                year: 'numeric',
                month: '2-digit',
                day: '2-digit'
            }).replace(/\//g, '-');
        } catch(e) {
            return gregorianDate;
        }
    }
    
    function getTodayPersianDate() {
        var today = new Date();
        return toPersianDate(today);
    }
    
    function getYesterdayPersianDate() {
        var yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        return toPersianDate(yesterday);
    }
    
    function isValidPersianDate(dateStr) {
        var pattern = /^(\d{4})-(\d{1,2})-(\d{1,2})$/;
        if (!pattern.test(dateStr)) return false;
        var parts = dateStr.split('-');
        var year = parseInt(parts[0]);
        var month = parseInt(parts[1]);
        var day = parseInt(parts[2]);
        
        if (year < 1300 || year > 1500) return false;
        if (month < 1 || month > 12) return false;
        if (day < 1 || day > 31) return false;
        
        if (month <= 6 && day > 31) return false;
        if (month > 6 && day > 30) return false;
        if (month === 12 && day > 29) return false;
        
        return true;
    }
    
    // ========== تبدیل اعداد فارسی به انگلیسی ==========
    function persianToEnglishNumbers(str) {
        if (!str) return str;
        var persianNumbers = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        var englishNumbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
        for (var i = 0; i < persianNumbers.length; i++) {
            str = str.replace(new RegExp(persianNumbers[i], 'g'), englishNumbers[i]);
        }
        return str;
    }
    
    // ========== بروزرسانی کارت‌های آماری ==========
    function updateStatsUI(summary, orderCount) {
        if ($('.bzc-stats-grid').length === 0) {
            let statsHtml = `
                <div class="bzc-stats-grid">
                    <div class="bzc-stat-card stat-sales">
                        <span class="stat-icon">💰</span>
                        <span class="stat-label">جمع فروش</span>
                        <span class="stat-value" id="stat-total-sales">0</span>
                    </div>
                    <div class="bzc-stat-card stat-profit">
                        <span class="stat-icon">📈</span>
                        <span class="stat-label">سود خالص</span>
                        <span class="stat-value" id="stat-net-profit">0</span>
                    </div>
                    <div class="bzc-stat-card stat-orders">
                        <span class="stat-icon">📦</span>
                        <span class="stat-label">تعداد سفارش‌ها</span>
                        <span class="stat-value" id="stat-order-count">0</span>
                    </div>
                    <div class="bzc-stat-card stat-fee">
                        <span class="stat-icon">💳</span>
                        <span class="stat-label">کارمزد درگاه</span>
                        <span class="stat-value" id="stat-total-fee">0</span>
                    </div>
                </div>
            `;
            $('.bzc-wrap .bzc-filters').after(statsHtml);
        }
        
        if (summary) {
            $('#stat-total-sales').text(numberFormat(summary.total_sales || 0));
            $('#stat-net-profit').text(numberFormat(summary.total_net_profit || 0));
            $('#stat-total-fee').text(numberFormat(summary.total_gateway_fee || 0));
        }
        
        if (orderCount !== undefined) {
            $('#stat-order-count').text(numberFormat(orderCount));
        }
    }
    
    // ========== تابع اصلی بارگذاری سفارش‌ها ==========
    
    function loadOrders(startDate, endDate, search = '') {
        $('#bzc-orders-table-container').html(`
            <div class="bzc-loading">
                <div class="spinner"></div>
                <div>در حال بارگذاری سفارش‌ها...</div>
            </div>
        `);
        
        startDate = persianToEnglishNumbers(startDate);
        endDate = persianToEnglishNumbers(endDate);
        search = persianToEnglishNumbers(search);
        
        $.post(bzc_ajax.ajax_url, {
            action: 'bzc_get_orders_data',
            nonce: bzc_ajax.nonce,
            start_date: startDate,
            end_date: endDate,
            search: search
        }, function(res) {
            if (res.error) {
                $('#bzc-orders-table-container').html('<div class="loading" style="color: #ff9800;">⚠️ ' + res.error + '</div>');
                $('#bzc-summary').html('');
                $('#bzc-gateway-summary').html('');
                $('#bzc-partners-share').html('');
                return;
            }
            
            if (!res.orders || res.orders.length === 0) {
                $('#bzc-orders-table-container').html('<div class="loading" style="color: #ff9800;">📭 در بازه تاریخ ' + startDate + ' تا ' + endDate + ' هیچ سفارشی با وضعیت "درحال آماده سازی" یا "ارسال شد" یافت نشد.</div>');
                $('#bzc-summary').html('');
                $('#bzc-gateway-summary').html('');
                $('#bzc-partners-share').html('');
                return;
            }
            
            let html = '<div style="overflow-x: auto;">';
            html += '<table class="bzc-orders-table" style="width: 100%; border-collapse: collapse; direction: rtl;">';
            html += '<thead><tr style="background-color: #2271b1; color: white;">';
            html += '<th style="padding: 12px;">شماره سفارش</th>';
            html += '<th style="padding: 12px;">تاریخ سفارش</th>';
            html += '<th style="padding: 12px;">قلم سفارش</th>';
            html += '<th style="padding: 12px;">تعداد</th>';
            html += '<th style="padding: 12px;">قیمت فروش فی</th>';
            html += '<th style="padding: 12px;">قیمت فروش کل</th>';
            html += '<th style="padding: 12px;">قیمت خرید فی</th>';
            html += '<th style="padding: 12px;">قیمت خرید کل</th>';
            html += '<th style="padding: 12px;">هزینه جانبی فی</th>';
            html += '<th style="padding: 12px;">هزینه جانبی کل</th>';
            html += '<th style="padding: 12px;">قیمت تمام‌شده فی</th>';
            html += '<th style="padding: 12px;">قیمت تمام‌شده کل</th>';
            html += '<th style="padding: 12px;">درگاه پرداخت</th>';
            html += '<th style="padding: 12px;">کارمزد</th>';
            html += '<th style="padding: 12px;">سود خالص</th>';
            html += '<th style="padding: 12px;">وضعیت</th>';
            html += '<th style="padding: 12px;">عملیات</th>';
            html += '</tr></thead><tbody>';
            
            res.orders.forEach((order, index) => {
                let rowClass = index % 2 === 0 ? 'background-color: #f9f9f9;' : '';
                let profitColor = order.net_profit >= 0 ? '#2c7a2c' : '#dc3232';
                
                let statusClass = 'pending';
                if (order.status === 'wc-processing') statusClass = 'processing';
                else if (order.status === 'wc-sent') statusClass = 'sent';
                else if (order.status === 'wc-completed') statusClass = 'completed';
                
                let totalCostPrice = (order.total_buy || 0) + (order.extra_cost || 0);
                let unitCostPrice = order.qty > 0 ? totalCostPrice / order.qty : 0;
                
                html += `<tr data-order-id="${order.order_id}" data-product-name="${order.product}" style="${rowClass}">`;
                html += `<td style="padding: 10px; text-align: center; cursor: pointer;" title="دابل کلیک برای کپی">${order.order_id}</td>`;
                html += `<td style="padding: 10px; text-align: center; direction: ltr;">${order.order_date || '-'}</td>`;
                html += `<td style="padding: 10px; text-align: right;">${order.product}</td>`;
                html += `<td style="padding: 10px; text-align: center;" class="qty-cell">${numberFormat(order.qty)}</td>`;
                html += `<td style="padding: 10px; text-align: left;">${numberFormat(order.unit_sell_price)}</td>`;
                html += `<td style="padding: 10px; text-align: left;" class="total-sell">${numberFormat(order.total_sell)}</td>`;
                html += `<td style="padding: 10px; text-align: center;"><input type="number" class="buy-price-input" value="${order.unit_buy_price || 0}" step="1000" style="width: 90px; padding: 5px;"></td>`;
                html += `<td style="padding: 10px; text-align: left;" class="total-buy-cell">${numberFormat(order.total_buy)}</td>`;
                html += `<td style="padding: 10px; text-align: center;"><input type="number" class="extra-cost-input" value="${order.extra_cost || 0}" step="1000" style="width: 90px; padding: 5px;"></td>`;
                html += `<td style="padding: 10px; text-align: left; color: #e74c3c;" class="total-extra-cell">${numberFormat(order.extra_cost)}</td>`;
                html += `<td style="padding: 10px; text-align: left;">${numberFormat(Math.round(unitCostPrice))}</td>`;
                html += `<td style="padding: 10px; text-align: left; font-weight: bold; color: #e65100;" class="total-cost-cell">${numberFormat(totalCostPrice)}</td>`;
                html += `<td style="padding: 10px; text-align: center;">${getGatewayName(order.gateway)}</td>`;
                html += `<td style="padding: 10px; text-align: left; color: #ff9800;" class="fee-cell">${numberFormat(order.fee_share)}</td>`;
                html += `<td style="padding: 10px; text-align: left; font-weight: bold; color: ${profitColor};" class="net-profit-cell">${numberFormat(order.net_profit)}</td>`;
                html += `<td style="padding: 10px; text-align: center;"><span class="bzc-status-badge ${statusClass}">${getStatusText(order.status)}</span></td>`;
                html += `<td style="padding: 10px; text-align: center;"><button class="save-buy-price" style="background: #46b450; color: white; border: none; padding: 5px 12px; border-radius: 4px; cursor: pointer;">💾 ذخیره</button></td>`;
                html += `</tr>`;
            });
            
            html += '</tbody></table></div>';
            $('#bzc-orders-table-container').html(html);
            
            let orderCount = res.orders.length;
            updateStatsUI(res.summary, orderCount);
            
            let totalFee = 0;
            $('.fee-cell').each(function() {
                let val = parseFloat($(this).text().replace(/,/g, ''));
                if (!isNaN(val)) totalFee += val;
            });
            
            let totalExtraCost = 0;
            $('.total-extra-cell').each(function() {
                let val = parseFloat($(this).text().replace(/,/g, ''));
                if (!isNaN(val)) totalExtraCost += val;
            });
            
            let totalCostPrice = 0;
            $('.total-cost-cell').each(function() {
                let val = parseFloat($(this).text().replace(/,/g, ''));
                if (!isNaN(val)) totalCostPrice += val;
            });
            
            let summaryHtml = `
                <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 12px; margin-top: 20px;">
                    <h3 style="margin-top: 0;">📊 خلاصه بازه (${startDate} تا ${endDate})</h3>
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 15px;">
                        <div style="background: rgba(255,255,255,0.2); padding: 10px; border-radius: 8px;">
                            <strong>فروش کل:</strong><br>${numberFormat(res.summary.total_sales)} تومان
                        </div>
                        <div style="background: rgba(255,255,255,0.2); padding: 10px; border-radius: 8px;">
                            <strong>تعداد اقلام:</strong><br>${numberFormat(res.summary.total_items)}
                        </div>
                        <div style="background: rgba(255,255,255,0.2); padding: 10px; border-radius: 8px;">
                            <strong>قیمت خرید کل:</strong><br>${numberFormat(res.summary.total_cost - totalExtraCost)} تومان
                        </div>
                        <div style="background: rgba(255,255,255,0.2); padding: 10px; border-radius: 8px;">
                            <strong>💰 هزینه‌های جانبی:</strong><br>${numberFormat(totalExtraCost)} تومان
                        </div>
                        <div style="background: rgba(255,255,255,0.2); padding: 10px; border-radius: 8px;">
                            <strong>📦 قیمت تمام‌شده کل:</strong><br>${numberFormat(totalCostPrice)} تومان
                        </div>
                        <div style="background: rgba(255,255,255,0.2); padding: 10px; border-radius: 8px;">
                            <strong>کارمزد درگاه:</strong><br>${numberFormat(totalFee)} تومان
                        </div>
                        <div style="background: rgba(255,255,255,0.2); padding: 10px; border-radius: 8px;">
                            <strong>سود خالص کل:</strong><br>${numberFormat(res.summary.total_net_profit)} تومان
                        </div>
                    </div>
                </div>
            `;
            $('#bzc-summary').html(summaryHtml);
            
            // ========== بخش خلاصه درگاه‌های پرداخت ==========
            let gatewayHtml = `
                <div style="background: white; padding: 20px; border-radius: 12px; margin-top: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                    <h3 style="margin-top: 0; color: #2271b1;">🏦 خلاصه فروش بر اساس درگاه پرداخت</h3>
                    <div style="overflow-x: auto;">
                        <table style="width: 100%; border-collapse: collapse; direction: rtl; margin-top: 10px;">
                            <thead>
                                <tr style="background-color: #f0f8ff; border-bottom: 2px solid #2271b1;">
                                    <th style="padding: 10px; text-align: center;">درگاه پرداخت</th>
                                    <th style="padding: 10px; text-align: center;">تعداد سفارش</th>
                                    <th style="padding: 10px; text-align: center;">تعداد اقلام</th>
                                    <th style="padding: 10px; text-align: center;">جمع فروش</th>
                                    <th style="padding: 10px; text-align: center;">کارمزد</th>
                                    <th style="padding: 10px; text-align: center;">فروش خالص</th>
                                    <th style="padding: 10px; text-align: center;">سود خالص</th>
                                    <th style="padding: 10px; text-align: center;">درصد از کل</th>
                                </tr>
                            </thead>
                            <tbody>
            `;
            
            if (res.gateway_summary && res.gateway_summary.length > 0) {
                let totalSalesAll = res.summary.total_sales || 1;
                res.gateway_summary.forEach((gateway, index) => {
                    let bgColor = index % 2 === 0 ? '#f9f9f9' : 'white';
                    let percent = (gateway.total_sales / totalSalesAll * 100);
                    gatewayHtml += `
                        <tr style="background-color: ${bgColor}; border-bottom: 1px solid #eee;">
                            <td style="padding: 10px; text-align: center; font-weight: bold;">${gateway.gateway_name}</td>
                            <td style="padding: 10px; text-align: center;">${numberFormat(gateway.order_count)}</td>
                            <td style="padding: 10px; text-align: center;">${numberFormat(gateway.items_count)}</td>
                            <td style="padding: 10px; text-align: left; color: #2c7a2c;">${numberFormat(gateway.total_sales)}</td>
                            <td style="padding: 10px; text-align: left; color: #ff9800;">${numberFormat(gateway.total_fee)}</td>
                            <td style="padding: 10px; text-align: left; color: #2271b1; font-weight: bold;">${numberFormat(gateway.net_sales)}</td>
                            <td style="padding: 10px; text-align: left; color: ${gateway.total_net_profit >= 0 ? '#2c7a2c' : '#dc3232'}; font-weight: bold;">${numberFormat(gateway.total_net_profit)}</td>
                            <td style="padding: 10px; text-align: center;">
                                <div style="background: #e8f0fe; border-radius: 10px; height: 20px; width: 100%; max-width: 150px; margin: 0 auto; position: relative;">
                                    <div style="background: linear-gradient(90deg, #667eea, #764ba2); border-radius: 10px; height: 100%; width: ${Math.min(percent, 100)}%;"></div>
                                    <span style="position: absolute; top: 0; left: 0; right: 0; font-size: 10px; line-height: 20px; text-align: center; color: ${percent > 30 ? 'white' : '#333'};">
                                        ${percent.toFixed(1)}%
                                    </span>
                                </div>
                            </td>
                        </tr>
                    `;
                });
            } else {
                gatewayHtml += `
                    <tr>
                        <td colspan="8" style="padding: 15px; text-align: center; color: #666;">هیچ اطلاعاتی برای نمایش وجود ندارد</td>
                    </tr>
                `;
            }
            
            gatewayHtml += `
                            </tbody>
                        </table>
                    </div>
                </div>
            `;
            
            $('#bzc-gateway-summary').html(gatewayHtml);
            
            // ========== بخش شرکا ==========
            let partnersHtml = `<div style="background: white; padding: 20px; border-radius: 12px; margin-top: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <h3 style="margin-top: 0; color: #2271b1;">👥 سهم شرکا در این بازه</h3>
                <div style="background: #e8f0fe; padding: 10px; border-radius: 8px; margin-bottom: 15px;">
                    📌 سود ناخالص کل: ${numberFormat(res.summary.total_gross_profit)} تومان | 💳 کل کارمزد: ${numberFormat(totalFee)} تومان | 💰 سود خالص کل: ${numberFormat(res.summary.total_net_profit)} تومان
                </div>`;
            
            if (res.partners && res.partners.length > 0) {
                res.partners.forEach(p => {
                    let feeText = p.fee_percent ? `${p.fee_percent}%` : 'مساوی';
                    let isRemaining = p.is_remaining === true;
                    let extraClass = isRemaining ? 'remaining' : '';
                    
                    partnersHtml += `
                        <div class="bzc-partner-item ${extraClass}">
                            <div class="partner-name">${p.name}</div>
                            <div class="partner-share">
                                <span class="gross">📊 سهم از سود (${p.percent}%): ${numberFormat(p.gross_share)} تومان</span>
                                <span class="fee">💳 سهم از کارمزد (${feeText}): ${numberFormat(p.fee_share)} تومان</span>
                                <span class="final">💰 سود نهایی: ${numberFormat(p.final_share)} تومان</span>
                            </div>
                            <div style="margin-top: 6px; font-size: 11px; color: #666; background: rgba(0,0,0,0.03); padding: 5px; border-radius: 4px;">
                                محاسبه: (${numberFormat(res.summary.total_gross_profit)} × ${p.percent}%) - (${numberFormat(totalFee)} × ${feeText}) = ${numberFormat(p.final_share)} تومان
                            </div>
                        </div>
                    `;
                });
            } else {
                partnersHtml += '<div style="padding: 12px; color: #666;">هیچ شریکی تعریف نشده است. لطفاً ابتدا در بخش تنظیمات، شرکا را اضافه کنید.</div>';
            }
            
            partnersHtml += `</div>`;
            $('#bzc-partners-share').html(partnersHtml);
        }).fail(function(xhr, status, error) {
            console.error('خطا:', error);
            $('#bzc-orders-table-container').html('<div class="loading" style="color: #dc3232;">❌ خطا در دریافت اطلاعات از سرور. لطفاً دوباره تلاش کنید.</div>');
            $('#bzc-summary').html('');
            $('#bzc-gateway-summary').html('');
            $('#bzc-partners-share').html('');
            bzcShowToast('❌ خطا در ارتباط با سرور: ' + error, 'error', 5000);
        });
    }
    
    // ========== رویداد ذخیره تکی (قیمت خرید + هزینه جانبی) ==========
    $(document).on('click', '.save-buy-price', function() {
        let row = $(this).closest('tr');
        let orderId = row.data('order-id');
        let productName = row.data('product-name');
        let qty = parseFloat(row.find('.qty-cell').text().replace(/,/g, ''));
        let totalSell = parseFloat(row.find('.total-sell').text().replace(/,/g, ''));
        
        let unitBuyPrice = parseFloat(row.find('.buy-price-input').val());
        let extraCost = parseFloat(row.find('.extra-cost-input').val());
        
        if (isNaN(unitBuyPrice) || unitBuyPrice < 0) {
            bzcShowToast('⚠️ لطفاً قیمت خرید معتبر وارد کنید', 'warning');
            return;
        }
        if (isNaN(extraCost) || extraCost < 0) {
            bzcShowToast('⚠️ لطفاً هزینه جانبی معتبر وارد کنید', 'warning');
            return;
        }
        
        let totalBuyPrice = unitBuyPrice * qty;
        let totalExtraCost = extraCost;
        let totalCostPrice = totalBuyPrice + totalExtraCost;
        
        row.find('.total-buy-cell').text(numberFormat(totalBuyPrice));
        row.find('.total-extra-cell').text(numberFormat(totalExtraCost));
        row.find('.total-cost-cell').text(numberFormat(totalCostPrice));
        
        let newNetProfit = totalSell - totalCostPrice - (parseFloat(row.find('.fee-cell').text().replace(/,/g, '')) || 0);
        let profitColor = newNetProfit >= 0 ? '#2c7a2c' : '#dc3232';
        row.find('.net-profit-cell').text(numberFormat(newNetProfit)).css('color', profitColor);
        
        $.post(bzc_ajax.ajax_url, {
            action: 'bzc_save_buy_price',
            nonce: bzc_ajax.nonce,
            order_id: orderId,
            product_name: productName,
            buy_price: totalBuyPrice,
            extra_cost: totalExtraCost
        }, function(response) {
            if (response.success) {
                bzcShowToast('✓ قیمت با موفقیت ذخیره شد', 'success');
                updateTotalSummary();
            } else {
                bzcShowToast('❌ خطا در ذخیره سازی', 'error');
            }
        }).fail(function() {
            bzcShowToast('❌ خطا در ارتباط با سرور', 'error');
        });
    });
    
    // ========== بروزرسانی خلاصه کلی ==========
    function updateTotalSummary() {
        let totalSales = 0;
        let totalCost = 0;
        let totalNetProfit = 0;
        let totalExtra = 0;
        
        $('.bzc-orders-table tbody tr').each(function() {
            let sell = parseFloat($(this).find('.total-sell').text().replace(/,/g, '')) || 0;
            let cost = parseFloat($(this).find('.total-cost-cell').text().replace(/,/g, '')) || 0;
            let extra = parseFloat($(this).find('.total-extra-cell').text().replace(/,/g, '')) || 0;
            let profit = parseFloat($(this).find('.net-profit-cell').text().replace(/,/g, '')) || 0;
            totalSales += sell;
            totalCost += cost;
            totalExtra += extra;
            totalNetProfit += profit;
        });
        
        $('#stat-total-sales').text(numberFormat(totalSales));
        $('#stat-net-profit').text(numberFormat(totalNetProfit));
    }
    
    // ========== رویداد ذخیره همه قیمت‌ها و هزینه‌ها ==========
    $('#bzc-save-all-prices').on('click', function() {
        let allPrices = [];
        let hasError = false;
        
        $('.bzc-orders-table tbody tr').each(function() {
            let row = $(this);
            let qty = parseFloat(row.find('.qty-cell').text().replace(/,/g, ''));
            let unitBuyPrice = parseFloat(row.find('.buy-price-input').val());
            let extraCost = parseFloat(row.find('.extra-cost-input').val());
            
            if (isNaN(unitBuyPrice) || unitBuyPrice < 0) {
                hasError = true;
                row.find('.buy-price-input').css('border', '2px solid red');
                return false;
            }
            if (isNaN(extraCost) || extraCost < 0) {
                hasError = true;
                row.find('.extra-cost-input').css('border', '2px solid red');
                return false;
            }
            row.find('.buy-price-input').css('border', '');
            row.find('.extra-cost-input').css('border', '');
            
            allPrices.push({
                order_id: row.data('order-id'),
                product_name: row.data('product-name'),
                buy_price: unitBuyPrice * qty,
                extra_cost: extraCost
            });
        });
        
        if (hasError) {
            bzcShowToast('⚠️ لطفاً تمام قیمت‌های معتبر را وارد کنید', 'warning');
            return;
        }
        
        if (allPrices.length === 0) {
            bzcShowToast('هیچ قیمتی برای ذخیره وجود ندارد', 'info');
            return;
        }
        
        let savingBtn = $(this);
        let originalText = savingBtn.text();
        savingBtn.text('در حال ذخیره...').prop('disabled', true);
        
        $.post(bzc_ajax.ajax_url, {
            action: 'bzc_save_all_buy_prices',
            nonce: bzc_ajax.nonce,
            prices: allPrices
        }, function(response) {
            if (response.success) {
                bzcShowToast(response.data.message, 'success');
                $('#bzc-refresh').click();
            } else {
                bzcShowToast('❌ خطا در ذخیره سازی', 'error');
            }
        }).fail(function() {
            bzcShowToast('❌ خطا در ارتباط با سرور', 'error');
        }).always(function() {
            savingBtn.text(originalText).prop('disabled', false);
        });
    });
    
    // ========== خروجی CSV ==========
    $('#bzc-export-csv').on('click', function() {
        let csvRows = [];
        
        let headers = [];
        $('.bzc-orders-table th').each(function() {
            headers.push('"' + $(this).text().replace(/"/g, '""') + '"');
        });
        csvRows.push(headers.join(','));
        
        $('.bzc-orders-table tbody tr').each(function() {
            let rowData = [];
            $(this).find('td').each(function(index) {
                let text = $(this).text().trim();
                if (index === 6) {
                    let val = $(this).find('input').val();
                    rowData.push('"' + (val ? val.replace(/"/g, '""') : '') + '"');
                } else if (index === 8) {
                    let val = $(this).find('input').val();
                    rowData.push('"' + (val ? val.replace(/"/g, '""') : '') + '"');
                } else {
                    rowData.push('"' + text.replace(/"/g, '""') + '"');
                }
            });
            csvRows.push(rowData.join(','));
        });
        
        csvRows.push('""');
        csvRows.push('"*** خلاصه بازه ***"');
        let summaryText = $('#bzc-summary').text();
        let summaryLines = summaryText.split('\n');
        summaryLines.forEach(line => {
            if (line.trim()) {
                csvRows.push('"' + line.trim().replace(/"/g, '""') + '"');
            }
        });
        
        csvRows.push('""');
        csvRows.push('"*** خلاصه درگاه‌های پرداخت ***"');
        let gatewayText = $('#bzc-gateway-summary').text();
        let gatewayLines = gatewayText.split('\n');
        gatewayLines.forEach(line => {
            if (line.trim() && !line.includes('خلاصه فروش بر اساس درگاه پرداخت')) {
                csvRows.push('"' + line.trim().replace(/"/g, '""') + '"');
            }
        });
        
        csvRows.push('""');
        csvRows.push('"*** سهم شرکا ***"');
        let partnersText = $('#bzc-partners-share').text();
        let partnersLines = partnersText.split('\n');
        partnersLines.forEach(line => {
            if (line.trim() && !line.includes('سهم شرکا') && !line.includes('اضافه کنید')) {
                csvRows.push('"' + line.trim().replace(/"/g, '""') + '"');
            }
        });
        
        let blob = new Blob(["\uFEFF" + csvRows.join('\n')], {type: 'text/csv;charset=utf-8;'});
        let link = document.createElement('a');
        let url = URL.createObjectURL(blob);
        link.href = url;
        link.download = 'bz_accounting_report_' + new Date().toISOString().slice(0, 19) + '.csv';
        link.click();
        URL.revokeObjectURL(url);
        
        bzcShowToast('📥 خروجی CSV با موفقیت دانلود شد', 'success');
    });
    
    // ========== رویدادهای اصلی ==========
    $('#bzc-refresh').on('click', function() {
        let startDate = $('#bzc-start-date').val();
        let endDate = $('#bzc-end-date').val();
        let search = $('#bzc-search').val();
        
        startDate = persianToEnglishNumbers(startDate);
        endDate = persianToEnglishNumbers(endDate);
        
        if (!startDate || !endDate) {
            bzcShowToast('⚠️ لطفاً هر دو تاریخ شروع و پایان را وارد کنید', 'warning');
            return;
        }
        
        if (!isValidPersianDate(startDate) || !isValidPersianDate(endDate)) {
            bzcShowToast('⚠️ فرمت تاریخ باید YYYY-MM-DD باشد (مثال: 1404-01-01)', 'warning');
            return;
        }
        
        loadOrders(startDate, endDate, search);
    });
    
    // ========== جستجوی زنده ==========
    function quickSearchInTable(searchText) {
        searchText = searchText.toLowerCase().trim();
        if (!searchText) {
            $('.bzc-orders-table tbody tr').show();
            return;
        }
        
        $('.bzc-orders-table tbody tr').each(function() {
            let text = $(this).text().toLowerCase();
            if (text.includes(searchText)) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    }
    
    $('#bzc-search').on('input', function() {
        let val = $(this).val();
        if (val.length >= 2) {
            quickSearchInTable(val);
        } else if (val.length === 0) {
            $('.bzc-orders-table tbody tr').show();
        }
    });
    
    $('#bzc-search').on('keypress', function(e) {
        if (e.which === 13) $('#bzc-refresh').click();
    });
    
    // ========== کپی شماره سفارش با دابل کلیک ==========
    $(document).on('dblclick', '.bzc-orders-table tbody tr td:first-child', function() {
        let orderId = $(this).text().trim();
        if (orderId) {
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(orderId).then(() => {
                    bzcShowToast('📋 شماره سفارش ' + orderId + ' کپی شد', 'info', 1500);
                }).catch(() => fallbackCopy(orderId));
            } else {
                fallbackCopy(orderId);
            }
        }
    });
    
    function fallbackCopy(text) {
        let textArea = document.createElement('textarea');
        textArea.value = text;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
        bzcShowToast('📋 شماره سفارش ' + text + ' کپی شد', 'info', 1500);
    }
    
    // ========== میانبرهای صفحه کلید ==========
    $(document).on('keydown', function(e) {
        if (e.ctrlKey && e.key === 'Enter') {
            e.preventDefault();
            $('#bzc-refresh').click();
        }
        
        if (e.key === 'Escape') {
            $('#bzc-search').val('').trigger('input');
        }
    });
    
    // ========== بارگذاری اولیه ==========
    let today = getTodayPersianDate();
    let yesterday = getYesterdayPersianDate();
    $('#bzc-start-date').val(yesterday);
    $('#bzc-end-date').val(today);
    loadOrders(yesterday, today, '');
    
    // ========== بخش تنظیمات - شرکا ==========
    $('#add-partner').on('click', function() {
        let template = $('.partner-row.template').clone().removeClass('template').show();
        $('#partners-list').append(template);
    });
    
    $(document).on('click', '.remove-partner', function() {
        $(this).closest('.partner-row').remove();
    });
    
    // ========== تنظیمات - رنج‌ها ==========
    $(document).on('click', '.add-range', function() {
        let gatewayId = $(this).data('gateway');
        let container = $(`.ranges-container[data-gateway="${gatewayId}"]`);
        let rangeCount = container.children('.range-row').length;
        
        let newRange = `
            <div class="range-row">
                <input type="number" name="gateway_ranges[${gatewayId}][${rangeCount}][min]" placeholder="حداقل" style="width:100px">
                <input type="number" name="gateway_ranges[${gatewayId}][${rangeCount}][max]" placeholder="حداکثر" style="width:100px">
                <select name="gateway_ranges[${gatewayId}][${rangeCount}][value_type]">
                    <option value="percent">درصدی</option>
                    <option value="fixed">ثابت</option>
                </select>
                <input type="number" step="0.01" name="gateway_ranges[${gatewayId}][${rangeCount}][value]" placeholder="مقدار" style="width:100px">
                <button type="button" class="remove-range button button-small">❌</button>
            </div>
        `;
        container.append(newRange);
    });
    
    $(document).on('click', '.remove-range', function() {
        if ($(this).closest('.ranges-container').children('.range-row').length > 1) {
            $(this).closest('.range-row').remove();
        } else {
            bzcShowToast('حداقل یک رنج باید وجود داشته باشد', 'warning');
        }
    });
    
    $(document).on('change', '.fee-type', function() {
        let gatewayId = $(this).data('gateway');
        let type = $(this).val();
        
        $(`#percent-${gatewayId}, #fixed-${gatewayId}, #equation-${gatewayId}`).hide();
        if (type === 'percent') $(`#percent-${gatewayId}`).show();
        else if (type === 'fixed') $(`#fixed-${gatewayId}`).show();
        else if (type === 'equation') $(`#equation-${gatewayId}`).show();
    });
    
    $('.fee-type').each(function() { $(this).trigger('change'); });
    
    // ========== محدود کردن ورودی فیلدهای تاریخ به اعداد انگلیسی ==========
    $('.bzc-persian-datepicker').on('input', function() {
        var val = $(this).val();
        val = persianToEnglishNumbers(val);
        val = val.replace(/[^0-9\-]/g, '');
        $(this).val(val);
    });
    
    // ========== جلوگیری از ورود اعداد فارسی در فیلدهای عددی ==========
    $(document).on('input', 'input[type="number"]', function() {
        var val = $(this).val();
        val = persianToEnglishNumbers(val);
        $(this).val(val);
    });
    
    // ========== اضافه کردن Tooltip به دکمه‌ها ==========
    $('#bzc-refresh').attr('title', 'Ctrl+Enter - نمایش سفارش‌ها');
    $('#bzc-save-all-prices').attr('title', 'ذخیره همه قیمت‌های خرید و هزینه‌ها');
    $('#bzc-export-csv').attr('title', 'خروجی CSV از گزارش فعلی');
    $('#bzc-search').attr('title', 'جستجوی زنده - حداقل 2 کاراکتر');
});