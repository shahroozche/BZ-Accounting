<?php
/**
 * Plugin Name: BZ-Accounting
 * Description: افزونه حسابداری پیشرفته وردپرس - ویرایش دستی قیمت خرید، کارمزد درگاه، شرکا، مدیریت پرداختی‌ها و گزارش درگاه‌ها
 * Version: 1.59
 * Author: Shahrooz Chegini
 */

if (!defined('ABSPATH')) {
    exit;
}

define('BZC_VERSION', '1.59');
define('BZC_PLUGIN_URL', plugin_dir_url(__FILE__));
define('BZC_PLUGIN_DIR', plugin_dir_path(__FILE__));

// افزودن منوی ادمین
add_action('admin_menu', 'bzc_add_admin_menu');
function bzc_add_admin_menu() {
    add_menu_page(
        'BZ-Accounting',
        'BZ-Accounting',
        'manage_options',
        'bz-accounting',
        'bzc_render_main_page',
        'dashicons-chart-area',
        25
    );
    add_submenu_page(
        'bz-accounting',
        'تنظیمات',
        'تنظیمات',
        'manage_options',
        'bz-accounting-settings',
        'bzc_render_settings_page'
    );
    add_submenu_page(
        'bz-accounting',
        'پرداختی درگاه‌ها',
        'پرداختی درگاه‌ها',
        'manage_options',
        'bz-accounting-payments',
        'bzc_render_payments_page'
    );
    add_submenu_page(
        'bz-accounting',
        'گزارش درگاه‌ها',
        'گزارش درگاه‌ها',
        'manage_options',
        'bz-accounting-gateway-report',
        'bzc_render_gateway_report_page'
    );
}

// بارگذاری JS و CSS
add_action('admin_enqueue_scripts', 'bzc_enqueue_assets');
function bzc_enqueue_assets($hook) {
    if (strpos($hook, 'bz-accounting') === false) {
        return;
    }
    
    wp_enqueue_script('jquery');
    
    wp_enqueue_style('bzc-persian-datepicker', BZC_PLUGIN_URL . 'assets/css/persian-datepicker.min.css', [], '1.2.0');
    wp_enqueue_script('persian-date', BZC_PLUGIN_URL . 'assets/js/persian-date.min.js', [], '1.1.0', true);
    wp_enqueue_script('persian-datepicker', BZC_PLUGIN_URL . 'assets/js/persian-datepicker.min.js', ['jquery', 'persian-date'], '1.2.0', true);
    
    wp_enqueue_style('bzc-styles', BZC_PLUGIN_URL . 'styles.css', [], BZC_VERSION);
    wp_enqueue_script('bzc-scripts', BZC_PLUGIN_URL . 'scripts.js', ['jquery', 'persian-date', 'persian-datepicker'], BZC_VERSION, true);
    
    wp_localize_script('bzc-scripts', 'bzc_ajax', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('bzc_nonce')
    ]);
}

// ==================== صفحه اصلی ====================
function bzc_render_main_page() {
    ?>
    <div class="wrap bzc-wrap">
        <h1>BZ-Accounting - داشبورد حسابداری</h1>
        <div class="bzc-filters">
            <label>از تاریخ (شمسی):</label>
            <input type="text" id="bzc-start-date" class="bzc-persian-datepicker" placeholder="۱۴۰۴-۰۱-۰۱" autocomplete="off">
            <label>تا تاریخ (شمسی):</label>
            <input type="text" id="bzc-end-date" class="bzc-persian-datepicker" placeholder="۱۴۰۴-۱۲-۲۹" autocomplete="off">
            <input type="text" id="bzc-search" placeholder="جستجو در سفارش‌ها (شماره/محصول)...">
            <button id="bzc-refresh" class="button button-primary">🔍 نمایش سفارش‌ها</button>
            <button id="bzc-save-all-prices" class="button button-primary">💾 ذخیره همه قیمت‌ها</button>
            <button id="bzc-export-csv" class="button button-primary">📥 خروجی CSV</button>
        </div>
        <div id="bzc-orders-table-container">
            <div class="loading">لطفاً روی دکمه "نمایش سفارش‌ها" کلیک کنید...</div>
        </div>
        <div id="bzc-summary"></div>
        <div id="bzc-gateway-summary"></div>
        <div id="bzc-partners-share"></div>
    </div>
    <?php
}

// ==================== صفحه پرداختی درگاه‌ها ====================
function bzc_render_payments_page() {
    // ذخیره پرداختی جدید
    if (isset($_POST['bzc_save_payment']) && check_admin_referer('bzc_payment_nonce')) {
        $gateway_id = sanitize_text_field($_POST['payment_gateway']);
        $payment_date = sanitize_text_field($_POST['payment_date']);
        $payment_amount = floatval($_POST['payment_amount']);
        $payment_type = isset($_POST['payment_type']) ? sanitize_text_field($_POST['payment_type']) : 'payment';
        
        if (!empty($gateway_id) && !empty($payment_date) && $payment_amount != 0) {
            $payments = get_option('bzc_gateway_payments', []);
            $payments[] = [
                'id' => uniqid(),
                'gateway_id' => $gateway_id,
                'date' => $payment_date,
                'amount' => $payment_amount,
                'type' => $payment_type,
                'note' => isset($_POST['payment_note']) ? sanitize_text_field($_POST['payment_note']) : '',
                'created_at' => current_time('mysql')
            ];
            update_option('bzc_gateway_payments', $payments);
            $type_label = $payment_type == 'fee_adjustment' ? 'تعدیل کارمزد' : 'پرداختی';
            echo '<div class="notice notice-success"><p>✅ ' . $type_label . ' با موفقیت ثبت شد.</p></div>';
        } else {
            echo '<div class="notice notice-error"><p>❌ لطفاً تمام فیلدها را به درستی پر کنید. مبلغ نمی‌تواند صفر باشد.</p></div>';
        }
    }
    
    // حذف پرداختی
    if (isset($_GET['delete_payment']) && isset($_GET['payment_id']) && check_admin_referer('delete_payment_' . $_GET['payment_id'])) {
        $payments = get_option('bzc_gateway_payments', []);
        $payment_id = sanitize_text_field($_GET['payment_id']);
        $payments = array_filter($payments, function($p) use ($payment_id) {
            return $p['id'] !== $payment_id;
        });
        update_option('bzc_gateway_payments', array_values($payments));
        echo '<div class="notice notice-success"><p>✅ پرداختی با موفقیت حذف شد.</p></div>';
    }
    
    $payments = get_option('bzc_gateway_payments', []);
    $all_gateways = bzc_get_all_payment_gateways();
    
    $gateway_list = [];
    foreach ($all_gateways as $gateway) {
        $gateway_list[$gateway['id']] = $gateway['title'] . ($gateway['is_active'] ? '' : ' (غیرفعال)');
    }
    ?>
    <div class="wrap bzc-wrap">
        <h1>💰 پرداختی و تعدیل کارمزد درگاه‌های پرداخت</h1>
        
        <div style="background: white; padding: 20px; border-radius: 12px; margin-bottom: 25px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
            <h3>➕ افزودن تراکنش جدید</h3>
            <form method="post" style="display: flex; gap: 15px; align-items: flex-end; flex-wrap: wrap;">
                <?php wp_nonce_field('bzc_payment_nonce'); ?>
                <div>
                    <label><strong>نوع تراکنش:</strong></label>
                    <select name="payment_type" style="padding: 8px; border-radius: 6px; border: 1px solid #ccc;">
                        <option value="payment">💳 پرداختی به درگاه</option>
                        <option value="fee_adjustment">⚖️ تعدیل کارمزد</option>
                    </select>
                </div>
                <div>
                    <label><strong>درگاه پرداخت:</strong></label>
                    <select name="payment_gateway" style="padding: 8px; border-radius: 6px; border: 1px solid #ccc;">
                        <?php foreach ($gateway_list as $id => $title): ?>
                            <option value="<?php echo esc_attr($id); ?>"><?php echo esc_html($title); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label><strong>تاریخ (شمسی):</strong></label>
                    <input type="text" name="payment_date" class="bzc-persian-datepicker" placeholder="۱۴۰۴-۰۱-۰۱" autocomplete="off" required>
                </div>
                <div>
                    <label><strong>مبلغ (تومان):</strong></label>
                    <input type="number" name="payment_amount" placeholder="۰" step="1" style="padding: 8px; border-radius: 6px; border: 1px solid #ccc; width: 150px;" required>
                    <br><small style="color: #666;">مثبت = پرداختی، منفی = کارمزد اضافی</small>
                </div>
                <div>
                    <label><strong>توضیحات (اختیاری):</strong></label>
                    <input type="text" name="payment_note" placeholder="توضیحات..." style="padding: 8px; border-radius: 6px; border: 1px solid #ccc; width: 200px;">
                </div>
                <button type="submit" name="bzc_save_payment" class="button button-primary">💾 ثبت تراکنش</button>
            </form>
            <p style="font-size: 12px; color: #666; margin-top: 10px;">
                💡 <strong>نکات:</strong>
                <br>- <strong>پرداختی به درگاه:</strong> مبلغی که به درگاه پرداخت می‌کنید (مثبت)
                <br>- <strong>تعدیل کارمزد:</strong> برای تصحیح اختلاف کارمزد (منفی = کارمزد اضافی، مثبت = کارمزد کمتر محاسبه شده)
            </p>
        </div>
        
        <div style="background: white; padding: 20px; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); overflow-x: auto;">
            <h3>📋 تاریخچه تراکنش‌ها</h3>
            <table class="widefat" style="direction: rtl;">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>نوع</th>
                        <th>درگاه پرداخت</th>
                        <th>وضعیت</th>
                        <th>تاریخ</th>
                        <th>مبلغ (تومان)</th>
                        <th>توضیحات</th>
                        <th>تاریخ ثبت</th>
                        <th>عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($payments)): ?>
                        <tr><td colspan="9" style="text-align: center; padding: 20px; color: #666;">هیچ تراکنشی ثبت نشده است.</td></tr>
                    <?php else: 
                        $counter = 1;
                        foreach (array_reverse($payments) as $payment):
                            $is_active = false;
                            foreach ($all_gateways as $gateway) {
                                if ($gateway['id'] == $payment['gateway_id']) {
                                    $is_active = $gateway['is_active'];
                                    break;
                                }
                            }
                            $is_fee_adjustment = isset($payment['type']) && $payment['type'] == 'fee_adjustment';
                            $type_label = $is_fee_adjustment ? '⚖️ تعدیل کارمزد' : '💳 پرداختی';
                            $amount_color = $payment['amount'] >= 0 ? '#2c7a2c' : '#dc3232';
                            $amount_display = number_format($payment['amount']);
                            if ($payment['amount'] < 0) {
                                $amount_display = '-' . number_format(abs($payment['amount']));
                            }
                    ?>
                            <tr>
                                <td><?php echo $counter++; ?></td>
                                <td><?php echo $type_label; ?></td>
                                <td><?php echo bzc_get_gateway_display_name($payment['gateway_id']); ?></td>
                                <td>
                                    <?php if ($is_active): ?>
                                        <span style="color: #2c7a2c;">✅ فعال</span>
                                    <?php else: ?>
                                        <span style="color: #ff9800;">⏸️ غیرفعال</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo esc_html($payment['date']); ?></td>
                                <td style="direction: ltr; text-align: left; color: <?php echo $amount_color; ?>; font-weight: bold;">
                                    <?php echo $amount_display; ?>
                                </td>
                                <td><?php echo isset($payment['note']) ? esc_html($payment['note']) : '-'; ?></td>
                                <td><?php echo esc_html($payment['created_at']); ?></td>
                                <td>
                                    <a href="<?php echo wp_nonce_url(add_query_arg(['delete_payment' => '1', 'payment_id' => $payment['id']]), 'delete_payment_' . $payment['id']); ?>" 
                                       class="button button-small" 
                                       style="background: #dc3232; color: white; border: none;"
                                       onclick="return confirm('آیا از حذف این تراکنش اطمینان دارید؟')">
                                        🗑️ حذف
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; 
                    endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- ===== بخش خلاصه تعدیل کارمزدها ===== -->
        <?php 
        $fee_adjustments = array_filter($payments, function($p) {
            return isset($p['type']) && $p['type'] == 'fee_adjustment';
        });
        if (!empty($fee_adjustments)):
        ?>
        <div style="background: white; padding: 20px; border-radius: 12px; margin-top: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
            <h3 style="margin-top: 0; color: #ff9800;">⚖️ خلاصه تعدیل کارمزدها</h3>
            <div style="overflow-x: auto;">
                <table class="widefat" style="direction: rtl;">
                    <thead>
                        <tr>
                            <th>درگاه</th>
                            <th>تعداد تعدیل</th>
                            <th>مجموع تعدیل (تومان)</th>
                            <th>توضیحات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $fee_adj_summary = [];
                        foreach ($fee_adjustments as $adj) {
                            $gateway_id = $adj['gateway_id'];
                            if (!isset($fee_adj_summary[$gateway_id])) {
                                $fee_adj_summary[$gateway_id] = [
                                    'count' => 0,
                                    'total' => 0,
                                    'notes' => []
                                ];
                            }
                            $fee_adj_summary[$gateway_id]['count']++;
                            $fee_adj_summary[$gateway_id]['total'] += $adj['amount'];
                            if (!empty($adj['note'])) {
                                $fee_adj_summary[$gateway_id]['notes'][] = $adj['note'];
                            }
                        }
                        foreach ($fee_adj_summary as $gateway_id => $data):
                            $color = $data['total'] >= 0 ? '#2c7a2c' : '#dc3232';
                            $sign = $data['total'] >= 0 ? '+' : '';
                        ?>
                            <tr>
                                <td><strong><?php echo bzc_get_gateway_display_name($gateway_id); ?></strong></td>
                                <td style="text-align: center;"><?php echo $data['count']; ?></td>
                                <td style="direction: ltr; text-align: left; color: <?php echo $color; ?>; font-weight: bold;">
                                    <?php echo $sign . number_format($data['total']); ?>
                                </td>
                                <td><?php echo !empty($data['notes']) ? esc_html(implode(' - ', $data['notes'])) : '-'; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <p style="font-size: 12px; color: #666; margin-top: 10px;">
                💡 <strong>نکته:</strong> مبلغ مثبت = کارمزد کمتر از حد محاسبه شده (بدهکار)، مبلغ منفی = کارمزد اضافی (طلبکار)
            </p>
        </div>
        <?php endif; ?>
    </div>
    <?php
}

// ==================== تابع محاسبه سهم شرکا برای گزارش درگاه ====================
function bzc_calculate_partners_share_for_gateway($total_sales, $total_gateway_fee, $total_cost = 0) {
    $partners = get_option('bzc_partners', []);
    $partners_share_details = [];
    
    // محاسبه سود ناخالص (فروش - قیمت خرید)
    $total_gross_profit = $total_sales - $total_cost;
    
    // اگر سود ناخالص صفر یا منفی بود، سهم شرکا صفر محاسبه شود
    if ($total_gross_profit <= 0) {
        foreach ($partners as $partner) {
            $partners_share_details[] = [
                'name' => $partner['name'],
                'gross_share' => 0,
                'fee_share' => 0,
                'final_share' => 0,
                'percent' => $partner['percent'],
                'fee_percent' => isset($partner['fee_percent']) ? $partner['fee_percent'] : null
            ];
        }
        return $partners_share_details;
    }
    
    $total_partner_percent = array_sum(array_column($partners, 'percent'));
    $remaining_percent = max(0, 100 - $total_partner_percent);
    
    foreach ($partners as $partner) {
        $partner_gross_share = $total_gross_profit * ($partner['percent'] / 100);
        
        $partner_fee_percent = isset($partner['fee_percent']) ? $partner['fee_percent'] : null;
        if ($partner_fee_percent !== null) {
            $partner_fee_share = $total_gateway_fee * ($partner_fee_percent / 100);
        } else {
            $partners_without_fee = array_filter($partners, function($p) { return !isset($p['fee_percent']) || $p['fee_percent'] === null; });
            $equal_count = count($partners_without_fee);
            $partner_fee_share = $equal_count > 0 ? $total_gateway_fee / $equal_count : 0;
        }
        
        $partner_final_share = $partner_gross_share - $partner_fee_share;
        
        $partners_share_details[] = [
            'name' => $partner['name'],
            'gross_share' => round($partner_gross_share),
            'fee_share' => round($partner_fee_share),
            'final_share' => round($partner_final_share),
            'percent' => $partner['percent'],
            'fee_percent' => $partner_fee_percent
        ];
    }
    
    // سود انباشته (حساب اصلی)
    if ($remaining_percent > 0) {
        $remaining_gross = $total_gross_profit * ($remaining_percent / 100);
        $remaining_fee = $total_gateway_fee * ($remaining_percent / 100);
        $partners_share_details[] = [
            'name' => 'سود انباشته (حساب اصلی)',
            'gross_share' => round($remaining_gross),
            'fee_share' => round($remaining_fee),
            'final_share' => round($remaining_gross - $remaining_fee),
            'percent' => $remaining_percent,
            'fee_percent' => $remaining_percent,
            'is_remaining' => true
        ];
    }
    
    return $partners_share_details;
}

// ==================== صفحه گزارش درگاه‌ها ====================
function bzc_render_gateway_report_page() {
    $selected_gateway = isset($_GET['gateway']) ? sanitize_text_field($_GET['gateway']) : '';
    $start_date = isset($_GET['start_date']) ? sanitize_text_field($_GET['start_date']) : '';
    $end_date = isset($_GET['end_date']) ? sanitize_text_field($_GET['end_date']) : '';
    
    $start_date_gregorian = !empty($start_date) ? bzc_persian_to_gregorian($start_date) : '';
    $end_date_gregorian = !empty($end_date) ? bzc_persian_to_gregorian($end_date) : '';
    
    $active_gateways = bzc_get_active_payment_gateways();
    $payments = get_option('bzc_gateway_payments', []);
    $gateways_fee = get_option('bzc_gateways_fee', []);
    
    $orders_data = bzc_get_orders_by_gateway($start_date_gregorian, $end_date_gregorian, $gateways_fee);
    
    $all_gateway_ids = [];
    foreach ($orders_data as $order) {
        if (!empty($order['gateway']) && !in_array($order['gateway'], $all_gateway_ids)) {
            $all_gateway_ids[] = $order['gateway'];
        }
    }
    
    foreach ($payments as $payment) {
        if (!empty($payment['gateway_id']) && !in_array($payment['gateway_id'], $all_gateway_ids)) {
            $all_gateway_ids[] = $payment['gateway_id'];
        }
    }
    
    foreach ($active_gateways as $gateway_id => $title) {
        if (!in_array($gateway_id, $all_gateway_ids)) {
            $all_gateway_ids[] = $gateway_id;
        }
    }
    
    $all_gateways = [];
    foreach ($all_gateway_ids as $gateway_id) {
        if (isset($active_gateways[$gateway_id])) {
            $all_gateways[$gateway_id] = $active_gateways[$gateway_id];
        } else {
            $all_gateways[$gateway_id] = bzc_get_gateway_display_name($gateway_id);
        }
    }
    
    $gateway_reports = [];
    foreach ($all_gateways as $gateway_id => $gateway_title) {
        $gateway_orders = array_filter($orders_data, function($order) use ($gateway_id) {
            return $order['gateway'] === $gateway_id;
        });
        
        $total_sales = array_sum(array_column($gateway_orders, 'total_sell'));
        $total_cost = array_sum(array_column($gateway_orders, 'total_buy'));
        $total_fee = array_sum(array_column($gateway_orders, 'gateway_fee'));
        $total_items = array_sum(array_column($gateway_orders, 'qty'));
        $total_net_profit = array_sum(array_column($gateway_orders, 'net_profit'));
        
        $profit_percentage = 0;
        if ($total_sales > 0) {
            $profit_percentage = ($total_net_profit / $total_sales) * 100;
        }
        
        // فیلتر پرداختی‌ها بر اساس تاریخ
        $gateway_payments = array_filter($payments, function($p) use ($gateway_id) {
            return $p['gateway_id'] === $gateway_id;
        });
        
        if (!empty($start_date) && !empty($end_date)) {
            $gateway_payments = array_filter($gateway_payments, function($p) use ($start_date, $end_date) {
                return $p['date'] >= $start_date && $p['date'] <= $end_date;
            });
        }
        
        // تفکیک پرداختی‌ها و تعدیل کارمزد
        $payment_amounts = array_filter($gateway_payments, function($p) {
            return !isset($p['type']) || $p['type'] !== 'fee_adjustment';
        });
        $fee_adjustments = array_filter($gateway_payments, function($p) {
            return isset($p['type']) && $p['type'] == 'fee_adjustment';
        });
        
        $total_payments = array_sum(array_column($payment_amounts, 'amount'));
        $total_fee_adjustments = array_sum(array_column($fee_adjustments, 'amount'));
        
        // محاسبه کارمزد نهایی با اعمال تعدیلات
        $final_fee = $total_fee + $total_fee_adjustments;
        
        // محاسبه صحیح بدهی درگاه: فروش کل - کارمزد نهایی - پرداختی‌ها
        $debt = $total_sales - $final_fee - $total_payments;
        
        // محاسبه مبلغی که درگاه باید پرداخت کند (فروش - کارمزد نهایی)
        $amount_due = $total_sales - $final_fee;
        
        // سود خالص با اعمال تعدیلات
        $adjusted_net_profit = $total_net_profit - $total_fee_adjustments;
        
        $all_items = [];
        
        foreach ($gateway_orders as $order) {
            $all_items[] = [
                'date' => $order['order_date'],
                'type' => 'sale',
                'type_label' => '✅ فروش',
                'description' => 'سفارش #' . $order['order_id'] . ' - ' . $order['product'] . ' (' . $order['qty'] . ' عدد)',
                'amount_sell' => $order['total_sell'],
                'amount_buy' => $order['total_buy'],
                'gateway_fee' => $order['gateway_fee'],
                'net_profit' => $order['net_profit'],
                'payment_amount' => 0,
                'sort_date' => $order['order_date'] . ' ' . $order['order_time']
            ];
        }
        
        foreach ($payment_amounts as $payment) {
            $all_items[] = [
                'date' => $payment['date'],
                'type' => 'payment',
                'type_label' => '💳 پرداختی',
                'description' => 'پرداخت به درگاه' . (!empty($payment['note']) ? ' (' . $payment['note'] . ')' : ''),
                'amount_sell' => 0,
                'amount_buy' => 0,
                'gateway_fee' => 0,
                'net_profit' => 0,
                'payment_amount' => $payment['amount'],
                'sort_date' => $payment['date'] . ' 00:00:00'
            ];
        }
        
        foreach ($fee_adjustments as $adjustment) {
            $all_items[] = [
                'date' => $adjustment['date'],
                'type' => 'fee_adjustment',
                'type_label' => '⚖️ تعدیل کارمزد',
                'description' => 'تعدیل کارمزد' . (!empty($adjustment['note']) ? ' (' . $adjustment['note'] . ')' : ''),
                'amount_sell' => 0,
                'amount_buy' => 0,
                'gateway_fee' => $adjustment['amount'],
                'net_profit' => -$adjustment['amount'], // تعدیل کارمزد بر سود خالص تاثیر می‌گذارد
                'payment_amount' => 0,
                'sort_date' => $adjustment['date'] . ' 00:00:00'
            ];
        }
        
        usort($all_items, function($a, $b) {
            return strcmp($a['sort_date'], $b['sort_date']);
        });
        
        if (count($gateway_orders) > 0 || count($gateway_payments) > 0) {
            // محاسبه سهم شرکا برای این درگاه با کارمزد نهایی
            $partners_share = bzc_calculate_partners_share_for_gateway($total_sales, $final_fee, $total_cost);
            
            $gateway_reports[$gateway_id] = [
                'id' => $gateway_id,
                'name' => $gateway_title,
                'total_sales' => $total_sales,
                'total_cost' => $total_cost,
                'total_fee' => $total_fee,
                'total_fee_adjustments' => $total_fee_adjustments,
                'final_fee' => $final_fee,
                'total_items' => $total_items,
                'total_payments' => $total_payments,
                'total_net_profit' => $total_net_profit,
                'adjusted_net_profit' => $adjusted_net_profit,
                'profit_percentage' => $profit_percentage,
                'amount_due' => $amount_due,
                'debt' => $debt,
                'all_items' => $all_items,
                'order_count' => count($gateway_orders),
                'payment_count' => count($payment_amounts),
                'adjustment_count' => count($fee_adjustments),
                'is_active' => isset($active_gateways[$gateway_id]),
                'partners_share' => $partners_share
            ];
        }
    }
    
    if (!empty($selected_gateway) && isset($gateway_reports[$selected_gateway])) {
        $gateway_reports = [$selected_gateway => $gateway_reports[$selected_gateway]];
    }
    
    uasort($gateway_reports, function($a, $b) {
        return $b['total_sales'] - $a['total_sales'];
    });
    ?>
    <div class="wrap bzc-wrap">
        <h1>📊 گزارش کامل درگاه‌های پرداخت</h1>
        
        <div style="background: white; padding: 20px; border-radius: 12px; margin-bottom: 25px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
            <h3>🔍 فیلتر گزارش</h3>
            <form method="get" style="display: flex; gap: 15px; align-items: center; flex-wrap: wrap;">
                <input type="hidden" name="page" value="bz-accounting-gateway-report">
                <div>
                    <label><strong>درگاه پرداخت:</strong></label>
                    <select name="gateway" style="padding: 8px; border-radius: 6px; border: 1px solid #ccc;">
                        <option value="">همه درگاه‌ها</option>
                        <?php foreach ($all_gateways as $id => $title): ?>
                            <option value="<?php echo esc_attr($id); ?>" <?php selected($selected_gateway, $id); ?>>
                                <?php echo esc_html($title); ?>
                                <?php if (!isset($active_gateways[$id])): ?>
                                    (غیرفعال)
                                <?php endif; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label><strong>از تاریخ (شمسی):</strong></label>
                    <input type="text" name="start_date" class="bzc-persian-datepicker" value="<?php echo esc_attr($start_date); ?>" placeholder="۱۴۰۴-۰۱-۰۱" autocomplete="off">
                </div>
                <div>
                    <label><strong>تا تاریخ (شمسی):</strong></label>
                    <input type="text" name="end_date" class="bzc-persian-datepicker" value="<?php echo esc_attr($end_date); ?>" placeholder="۱۴۰۴-۱۲-۲۹" autocomplete="off">
                </div>
                <button type="submit" class="button button-primary">🔍 نمایش گزارش</button>
                <a href="<?php echo admin_url('admin.php?page=bz-accounting-gateway-report'); ?>" class="button">🔄 حذف فیلترها</a>
            </form>
        </div>
        
        <?php if (!empty($gateway_reports)): ?>
            <?php foreach ($gateway_reports as $gateway_id => $report): ?>
                <div style="background: white; padding: 20px; border-radius: 12px; margin-bottom: 25px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                    <h3 style="margin-top: 0; color: #2271b1; border-bottom: 2px solid #2271b1; padding-bottom: 10px;">
                        🏦 <?php echo esc_html($report['name']); ?>
                        <?php if (!$report['is_active']): ?>
                            <span style="font-size: 14px; color: #ff9800; font-weight: normal;">(غیرفعال)</span>
                        <?php endif; ?>
                        <span style="font-size: 14px; color: #666; font-weight: normal;">
                            (<?php echo $report['order_count']; ?> سفارش - <?php echo $report['payment_count']; ?> پرداختی - <?php echo $report['adjustment_count']; ?> تعدیل)
                        </span>
                    </h3>
                    
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 15px; margin: 15px 0;">
                        <div style="background: #e8f0fe; padding: 15px; border-radius: 8px;">
                            <strong>📦 فروش کل:</strong><br>
                            <span style="font-size: 20px; color: #2c7a2c;"><?php echo number_format($report['total_sales']); ?></span> تومان
                        </div>
                        <div style="background: #fff3e0; padding: 15px; border-radius: 8px;">
                            <strong>🛒 قیمت خرید کل:</strong><br>
                            <span style="font-size: 20px; color: #e65100;"><?php echo number_format($report['total_cost']); ?></span> تومان
                        </div>
                        <div style="background: #ffebee; padding: 15px; border-radius: 8px;">
                            <strong>💸 کارمزد درگاه کل:</strong><br>
                            <span style="font-size: 20px; color: #c62828;"><?php echo number_format($report['total_fee']); ?></span> تومان
                        </div>
                        <?php if ($report['total_fee_adjustments'] != 0): ?>
                            <div style="background: <?php echo $report['total_fee_adjustments'] >= 0 ? '#fff3e0' : '#ffebee'; ?>; padding: 15px; border-radius: 8px; border: 2px solid #ff9800;">
                                <strong>⚖️ تعدیل کارمزد:</strong><br>
                                <span style="font-size: 20px; font-weight: bold; color: <?php echo $report['total_fee_adjustments'] >= 0 ? '#e65100' : '#c62828'; ?>;">
                                    <?php echo ($report['total_fee_adjustments'] >= 0 ? '+' : '') . number_format($report['total_fee_adjustments']); ?>
                                </span> تومان
                                <br><small style="font-size: 11px;">کارمزد نهایی: <?php echo number_format($report['final_fee']); ?> تومان</small>
                            </div>
                        <?php endif; ?>
                        <div style="background: #e3f2fd; padding: 15px; border-radius: 8px;">
                            <strong>💰 مبلغ قابل پرداخت:</strong><br>
                            <span style="font-size: 20px; color: #1565c0;"><?php echo number_format($report['amount_due']); ?></span> تومان
                            <br><small style="font-size: 11px;">(فروش - کارمزد نهایی)</small>
                        </div>
                        <div style="background: <?php echo $report['adjusted_net_profit'] >= 0 ? '#e8f5e9' : '#ffebee'; ?>; padding: 15px; border-radius: 8px;">
                            <strong>💰 سود خالص نهایی:</strong><br>
                            <span style="font-size: 20px; font-weight: bold; color: <?php echo $report['adjusted_net_profit'] >= 0 ? '#2e7d32' : '#c62828'; ?>;">
                                <?php echo number_format($report['adjusted_net_profit']); ?>
                            </span> تومان
                            <?php if ($report['total_fee_adjustments'] != 0): ?>
                                <br><small style="font-size: 11px;">(اصلاح شده با تعدیلات)</small>
                            <?php endif; ?>
                        </div>
                        <div style="background: #f3e5f5; padding: 15px; border-radius: 8px;">
                            <strong>📊 درصد سود:</strong><br>
                            <span style="font-size: 20px; font-weight: bold; color: #6a1b9a;">
                                <?php echo number_format($report['profit_percentage'], 2); ?>%
                            </span>
                        </div>
                        <div style="background: #e3f2fd; padding: 15px; border-radius: 8px;">
                            <strong>💳 پرداختی به ما:</strong><br>
                            <span style="font-size: 20px; color: #1565c0;"><?php echo number_format($report['total_payments']); ?></span> تومان
                        </div>
                        <div style="background: <?php echo $report['debt'] >= 0 ? '#e8f5e9' : '#ffebee'; ?>; padding: 15px; border-radius: 8px;">
                            <strong>💰 بدهی درگاه:</strong><br>
                            <span style="font-size: 24px; font-weight: bold; color: <?php echo $report['debt'] >= 0 ? '#2e7d32' : '#c62828'; ?>;">
                                <?php echo number_format($report['debt']); ?>
                            </span> تومان
                        </div>
                    </div>
                    
                    <button class="button button-secondary toggle-details" data-gateway="<?php echo esc_attr($gateway_id); ?>">
                        📋 مشاهده جزئیات کامل
                    </button>
                    
                    <div id="details-<?php echo esc_attr($gateway_id); ?>" style="display: none; margin-top: 15px;">
                        <h4>📋 ریز صورت حساب‌ها (مرتب شده بر اساس تاریخ)</h4>
                        <p style="font-size: 12px; color: #666; margin-bottom: 10px;">
                            📊 درصد سود کلی: <strong><?php echo number_format($report['profit_percentage'], 2); ?>%</strong>
                            <?php if ($report['total_fee_adjustments'] != 0): ?>
                                | ⚖️ تعدیل کارمزد: <strong style="color: #ff9800;"><?php echo ($report['total_fee_adjustments'] >= 0 ? '+' : '') . number_format($report['total_fee_adjustments']); ?></strong> تومان
                            <?php endif; ?>
                        </p>
                        
                        <?php if (!empty($report['all_items'])): ?>
                            <div style="overflow-x: auto;">
                                <table class="widefat" style="direction: rtl;">
                                    <thead>
                                        <tr>
                                            <th>تاریخ</th>
                                            <th>نوع</th>
                                            <th>شماره/توضیحات</th>
                                            <th>مبلغ فروش (تومان)</th>
                                            <th>مبلغ خرید (تومان)</th>
                                            <th>کارمزد درگاه (تومان)</th>
                                            <th>سود خالص (تومان)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        foreach ($report['all_items'] as $item):
                                            if ($item['type'] == 'sale') {
                                                $profit_color = $item['net_profit'] >= 0 ? '#2c7a2c' : '#dc3232';
                                                $bg_color = '#f0f8ff';
                                            } elseif ($item['type'] == 'fee_adjustment') {
                                                $profit_color = $item['gateway_fee'] >= 0 ? '#ff9800' : '#dc3232';
                                                $bg_color = '#fff3e0';
                                            } else {
                                                $profit_color = '#999';
                                                $bg_color = '#f5f5f5';
                                            }
                                        ?>
                                            <tr style="background: <?php echo $bg_color; ?>;">
                                                <td><?php echo esc_html($item['date']); ?></td>
                                                <td><?php echo $item['type_label']; ?></td>
                                                <td><?php echo $item['description']; ?></td>
                                                <td style="direction: ltr; text-align: left; <?php echo $item['type'] == 'sale' ? 'color: #2c7a2c;' : 'color: #999;'; ?>">
                                                    <?php echo $item['type'] == 'sale' ? number_format($item['amount_sell']) : '-'; ?>
                                                </td>
                                                <td style="direction: ltr; text-align: left; <?php echo $item['type'] == 'sale' ? 'color: #e65100;' : 'color: #999;'; ?>">
                                                    <?php echo $item['type'] == 'sale' ? number_format($item['amount_buy']) : '-'; ?>
                                                </td>
                                                <td style="direction: ltr; text-align: left; <?php echo $item['type'] == 'sale' ? 'color: #c62828;' : ($item['type'] == 'fee_adjustment' ? 'color: #ff9800; font-weight: bold;' : 'color: #999;'); ?>">
                                                    <?php 
                                                    if ($item['type'] == 'sale') {
                                                        echo number_format($item['gateway_fee']);
                                                    } elseif ($item['type'] == 'fee_adjustment') {
                                                        echo ($item['gateway_fee'] >= 0 ? '+' : '') . number_format($item['gateway_fee']);
                                                    } else {
                                                        echo '-';
                                                    }
                                                    ?>
                                                </td>
                                                <td style="direction: ltr; text-align: left; font-weight: bold; color: <?php echo $profit_color; ?>;">
                                                    <?php 
                                                    if ($item['type'] == 'sale') {
                                                        echo number_format($item['net_profit']);
                                                    } elseif ($item['type'] == 'fee_adjustment') {
                                                        echo ($item['net_profit'] >= 0 ? '+' : '') . number_format($item['net_profit']);
                                                    } else {
                                                        echo '<span style="color: #1565c0;">' . number_format($item['payment_amount']) . '</span>';
                                                    }
                                                    ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                    <?php 
                                    $total_sales_sum = $report['total_sales'];
                                    $total_buy_sum = $report['total_cost'];
                                    $total_fee_sum = $report['total_fee'];
                                    $total_fee_adj_sum = $report['total_fee_adjustments'];
                                    $final_fee_sum = $report['final_fee'];
                                    $total_net_sum = $report['total_net_profit'];
                                    $adjusted_net_sum = $report['adjusted_net_profit'];
                                    $total_payments_sum = $report['total_payments'];
                                    $amount_due_sum = $report['amount_due'];
                                    $debt_sum = $report['debt'];
                                    ?>
                                    <tfoot style="background: #f5f5f5; font-weight: bold; border-top: 2px solid #2271b1;">
                                        <tr>
                                            <td colspan="3" style="text-align: left;">جمع کل:</td>
                                            <td style="direction: ltr; text-align: left; color: #2c7a2c;"><?php echo number_format($total_sales_sum); ?></td>
                                            <td style="direction: ltr; text-align: left; color: #e65100;"><?php echo number_format($total_buy_sum); ?></td>
                                            <td style="direction: ltr; text-align: left; color: #c62828;"><?php echo number_format($total_fee_sum); ?></td>
                                            <td style="direction: ltr; text-align: left; color: <?php echo $total_net_sum >= 0 ? '#2e7d32' : '#c62828'; ?>;">
                                                <?php echo number_format($total_net_sum); ?>
                                            </td>
                                        </tr>
                                        <?php if ($total_fee_adj_sum != 0): ?>
                                            <tr style="background: #fff3e0;">
                                                <td colspan="3" style="text-align: left; color: #ff9800;">⚖️ تعدیل کارمزد:</td>
                                                <td colspan="3" style="direction: ltr; text-align: left; color: #ff9800; font-weight: bold;">
                                                    <?php echo ($total_fee_adj_sum >= 0 ? '+' : '') . number_format($total_fee_adj_sum); ?>
                                                </td>
                                                <td style="direction: ltr; text-align: left; color: <?php echo $total_fee_adj_sum >= 0 ? '#e65100' : '#c62828'; ?>;">
                                                    <?php echo ($total_fee_adj_sum >= 0 ? '-' : '+') . number_format(abs($total_fee_adj_sum)); ?>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                        <tr>
                                            <td colspan="3" style="text-align: left; font-size: 14px;">💰 کارمزد نهایی (با تعدیل):</td>
                                            <td colspan="4" style="direction: ltr; text-align: left; font-size: 14px; color: #c62828; font-weight: bold;">
                                                <?php echo number_format($final_fee_sum); ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="text-align: left; font-size: 14px;">💰 سود خالص نهایی (با تعدیل):</td>
                                            <td colspan="4" style="direction: ltr; text-align: left; font-size: 14px; font-weight: bold; color: <?php echo $adjusted_net_sum >= 0 ? '#2e7d32' : '#c62828'; ?>;">
                                                <?php echo number_format($adjusted_net_sum); ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="text-align: left; font-size: 14px;">💰 مبلغ قابل پرداخت (فروش - کارمزد نهایی):</td>
                                            <td colspan="4" style="direction: ltr; text-align: left; font-size: 14px; color: #1565c0;">
                                                <?php echo number_format($amount_due_sum); ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="text-align: left; font-size: 14px;">💳 مجموع پرداختی‌ها:</td>
                                            <td colspan="4" style="direction: ltr; text-align: left; font-size: 14px; color: #1565c0;">
                                                <?php echo number_format($total_payments_sum); ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="text-align: left; font-size: 16px; font-weight: bold;">💰 بدهی نهایی درگاه:</td>
                                            <td colspan="4" style="direction: ltr; text-align: left; font-size: 16px; font-weight: bold; color: <?php echo $debt_sum >= 0 ? '#2e7d32' : '#c62828'; ?>;">
                                                <?php echo number_format($debt_sum); ?>
                                            </td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        <?php else: ?>
                            <p style="color: #666; padding: 15px;">هیچ آیتمی برای نمایش وجود ندارد.</p>
                        <?php endif; ?>
                        
                        <!-- ===== بخش سهم شرکا برای این درگاه ===== -->
                        <?php if (!empty($report['partners_share'])): ?>
                            <div style="margin-top: 20px; border-top: 2px dashed #ccc; padding-top: 15px;">
                                <h4 style="color: #2271b1;">👥 سهم شرکا از این درگاه (بر اساس مبلغ دریافتی از درگاه)</h4>
                                <div style="background: #e8f0fe; padding: 10px; border-radius: 8px; margin-bottom: 15px;">
                                    📌 سود ناخالص کل در این درگاه: <?php echo number_format($report['total_sales'] - $report['total_cost']); ?> تومان 
                                    | 💳 کل کارمزد نهایی: <?php echo number_format($report['final_fee']); ?> تومان 
                                    | 💰 سود خالص نهایی: <?php echo number_format($report['adjusted_net_profit']); ?> تومان
                                    <?php if ($report['total_fee_adjustments'] != 0): ?>
                                        <br>⚖️ تعدیل کارمزد اعمال شده: <?php echo ($report['total_fee_adjustments'] >= 0 ? '+' : '') . number_format($report['total_fee_adjustments']); ?> تومان
                                    <?php endif; ?>
                                </div>
                                
                                <?php foreach ($report['partners_share'] as $p): ?>
                                    <?php 
                                    $feeText = isset($p['fee_percent']) && $p['fee_percent'] !== null ? "{$p['fee_percent']}%" : 'مساوی';
                                    $isRemaining = isset($p['is_remaining']) && $p['is_remaining'] === true;
                                    $bgColor = $isRemaining ? '#fff8e1' : '#f0f8ff';
                                    $borderColor = $isRemaining ? '#ff9800' : '#2271b1';
                                    ?>
                                    <div style="background: <?php echo $bgColor; ?>; padding: 15px; border-radius: 8px; margin-bottom: 15px; border-right: 4px solid <?php echo $borderColor; ?>;">
                                        <h4 style="margin-top: 0; color: <?php echo $borderColor; ?>;"><?php echo esc_html($p['name']); ?></h4>
                                        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px;">
                                            <div>📊 سهم از سود ناخالص (<?php echo $p['percent']; ?>%): <?php echo number_format($p['gross_share']); ?> تومان</div>
                                            <div>💳 سهم از کارمزد نهایی (<?php echo $feeText; ?>): <?php echo number_format($p['fee_share']); ?> تومان</div>
                                            <div>💰 <strong>سهم نهایی <?php echo esc_html($p['name']); ?>:</strong> <?php echo number_format($p['final_share']); ?> تومان</div>
                                        </div>
                                        <div style="margin-top: 8px; font-size: 11px; color: #666; background: rgba(0,0,0,0.03); padding: 5px; border-radius: 4px;">
                                            محاسبه: (<?php echo number_format($report['total_sales'] - $report['total_cost']); ?> × <?php echo $p['percent']; ?>%) - (<?php echo number_format($report['final_fee']); ?> × <?php echo $feeText; ?>) = <?php echo number_format($p['final_share']); ?> تومان
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div style="background: white; padding: 30px; border-radius: 12px; text-align: center; color: #666;">
                هیچ داده‌ایی برای نمایش وجود ندارد. لطفاً بازه زمانی را تغییر دهید یا مطمئن شوید که سفارش‌هایی در سیستم وجود دارند.
            </div>
        <?php endif; ?>
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        $('.toggle-details').on('click', function() {
            var gatewayId = $(this).data('gateway');
            var detailsDiv = $('#details-' + gatewayId);
            if (detailsDiv.is(':visible')) {
                detailsDiv.slideUp();
                $(this).text('📋 مشاهده جزئیات کامل');
            } else {
                detailsDiv.slideDown();
                $(this).text('📋 مخفی کردن جزئیات');
            }
        });
    });
    </script>
    <?php
}

// ==================== توابع کمکی ====================

function bzc_get_all_payment_gateways() {
    $all_gateways = [];
    
    if (class_exists('WC_Payment_Gateways')) {
        $gateways = WC_Payment_Gateways::instance()->get_available_payment_gateways();
        foreach ($gateways as $id => $gateway) {
            $all_gateways[$id] = [
                'id' => $id,
                'title' => $gateway->get_title(),
                'is_active' => true
            ];
        }
    }
    
    $inactive_gateways = bzc_get_inactive_gateways_from_orders();
    foreach ($inactive_gateways as $gateway_id) {
        if (!isset($all_gateways[$gateway_id])) {
            $all_gateways[$gateway_id] = [
                'id' => $gateway_id,
                'title' => bzc_get_gateway_display_name($gateway_id),
                'is_active' => false
            ];
        }
    }
    
    $payments = get_option('bzc_gateway_payments', []);
    foreach ($payments as $payment) {
        $gateway_id = $payment['gateway_id'];
        if (!isset($all_gateways[$gateway_id])) {
            $all_gateways[$gateway_id] = [
                'id' => $gateway_id,
                'title' => bzc_get_gateway_display_name($gateway_id),
                'is_active' => false
            ];
        }
    }
    
    usort($all_gateways, function($a, $b) {
        return strcmp($a['title'], $b['title']);
    });
    
    return $all_gateways;
}

function bzc_get_inactive_gateways_from_orders() {
    $gateways = [];
    
    if (!class_exists('WooCommerce')) {
        return $gateways;
    }
    
    $args = [
        'limit' => -1,
        'return' => 'objects',
        'type' => 'shop_order',
        'status' => ['wc-processing', 'wc-sent', 'wc-completed']
    ];
    
    $orders = wc_get_orders($args);
    
    foreach ($orders as $order) {
        if (!method_exists($order, 'get_payment_method')) {
            continue;
        }
        
        $gateway_id = $order->get_payment_method();
        if (!empty($gateway_id) && !in_array($gateway_id, $gateways)) {
            $gateways[] = $gateway_id;
        }
    }
    
    return $gateways;
}

function bzc_get_active_payment_gateways() {
    $all_gateways = bzc_get_all_payment_gateways();
    $active = [];
    foreach ($all_gateways as $gateway) {
        if ($gateway['is_active']) {
            $active[$gateway['id']] = $gateway['title'];
        }
    }
    return $active;
}

function bzc_get_orders_by_gateway($start_date = '', $end_date = '', $gateways_fee = []) {
    if (!class_exists('WooCommerce')) {
        return [];
    }
    
    $valid_statuses = ['wc-processing', 'wc-sent', 'wc-completed'];
    
    $args = [
        'limit' => -1,
        'return' => 'objects',
        'status' => $valid_statuses,
        'type' => 'shop_order'
    ];
    
    if (!empty($start_date) && !empty($end_date)) {
        $args['date_created'] = $start_date . '...' . $end_date;
    }
    
    $orders = wc_get_orders($args);
    $result = [];
    
    if (empty($orders)) {
        return $result;
    }
    
    foreach ($orders as $order) {
        if (!method_exists($order, 'get_payment_method')) {
            continue;
        }
        
        $gateway_id = $order->get_payment_method();
        if (empty($gateway_id)) {
            $gateway_id = 'manual';
        }
        
        $order_date = $order->get_date_created();
        $order_date_formatted = $order_date ? $order_date->date_i18n('Y-m-d') : '';
        $order_time_formatted = $order_date ? $order_date->date_i18n('H:i:s') : '';
        
        $order_total = $order->get_total();
        $fee_config = $gateways_fee[$gateway_id] ?? null;
        $order_gateway_fee = bzc_calculate_gateway_fee($order_total, $fee_config);
        
        foreach ($order->get_items() as $item) {
            $qty = $item->get_quantity();
            $price_sell_total = floatval($item->get_total());
            
            if ($price_sell_total == 0) {
                $product = $item->get_product();
                if ($product) {
                    $price_sell_total = floatval($product->get_price()) * $qty;
                }
            }
            
            $product_name = $item->get_name();
            $meta_key = '_bzc_buy_price_' . sanitize_title($product_name);
            $saved_buy_price_total = floatval(get_post_meta($order->get_id(), $meta_key, true));
            
            if ($saved_buy_price_total == 0) {
                $saved_buy_price_total = 0;
            }
            
            $item_fee_share = 0;
            if ($order_total > 0 && $order_gateway_fee > 0) {
                $item_fee_share = ($price_sell_total / $order_total) * $order_gateway_fee;
            }
            
            $gross_profit = $price_sell_total - $saved_buy_price_total;
            $net_profit = $gross_profit - $item_fee_share;
            
            $result[] = [
                'order_id' => $order->get_id(),
                'order_date' => $order_date_formatted,
                'order_time' => $order_time_formatted,
                'product' => $product_name,
                'qty' => $qty,
                'total_sell' => $price_sell_total,
                'total_buy' => $saved_buy_price_total,
                'gateway_fee' => $item_fee_share,
                'net_profit' => $net_profit,
                'gateway' => $gateway_id
            ];
        }
    }
    
    return $result;
}

function bzc_persian_to_gregorian($persian_date) {
    if (empty($persian_date)) return '';
    
    $persian_date = trim($persian_date);
    $persian_date = preg_replace('/[^0-9\/\-]/', '', $persian_date);
    $persian_date = str_replace('/', '-', $persian_date);
    
    $parts = explode('-', $persian_date);
    if (count($parts) !== 3) return '';
    
    $persian_numbers = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    $english_numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    
    $year = str_replace($persian_numbers, $english_numbers, $parts[0]);
    $month = str_replace($persian_numbers, $english_numbers, $parts[1]);
    $day = str_replace($persian_numbers, $english_numbers, $parts[2]);
    
    if (!is_numeric($year) || !is_numeric($month) || !is_numeric($day)) return '';
    
    try {
        $gregorian = bzc_jalali_to_gregorian(intval($year), intval($month), intval($day));
        return sprintf('%04d-%02d-%02d', $gregorian[0], $gregorian[1], $gregorian[2]);
    } catch (Exception $e) {
        return '';
    }
}

function bzc_jalali_to_gregorian($jy, $jm, $jd) {
    $jy += 1595;
    $days = -355668 + (365 * $jy) + (floor($jy / 33) * 8) + (floor((($jy % 33) + 3) / 4)) + $jd;
    if ($jm < 7) {
        $days += ($jm - 1) * 31;
    } else {
        $days += (($jm - 7) * 30) + 186;
    }
    $gy = 400 * floor($days / 146097);
    $days %= 146097;
    if ($days > 36524) {
        $gy += 100 * floor(--$days / 36524);
        $days %= 36524;
        if ($days >= 365) $days++;
    }
    $gy += 4 * floor($days / 1461);
    $days %= 1461;
    if ($days > 365) {
        $gy += floor(($days - 1) / 365);
        $days = ($days - 1) % 365;
    }
    $gd = $days + 1;
    $sal_a = [0, 31, (($gy % 4 == 0 && $gy % 100 != 0) || ($gy % 400 == 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    for ($gm = 1; $gm <= 12; $gm++) {
        if ($gd <= $sal_a[$gm]) break;
        $gd -= $sal_a[$gm];
    }
    return [$gy, $gm, $gd];
}

function bzc_calculate_gateway_fee($amount, $config) {
    if (!$config) return 0;
    if ($config['type'] == 'fixed') return floatval($config['value']);
    if ($config['type'] == 'percent') return $amount * (floatval($config['value']) / 100);
    if ($config['type'] == 'equation' && isset($config['ranges'])) {
        foreach ($config['ranges'] as $range) {
            $min = floatval($range['min'] ?? 0);
            $max = (isset($range['max']) && $range['max'] !== '' && $range['max'] !== '0') ? floatval($range['max']) : PHP_FLOAT_MAX;
            if ($amount >= $min && $amount <= $max) {
                $value = floatval($range['value']);
                if ($range['value_type'] == 'percent') return $amount * ($value / 100);
                else return $value;
            }
        }
    }
    return 0;
}

function bzc_get_gateway_display_name($gateway_id) {
    $gateways = [
        'cod' => 'پرداخت در محل',
        'zarinpal' => 'زرین پال',
        'payir' => 'پی آیر',
        'idpay' => 'آیدی پی',
        'nextpay' => 'نکست پی',
        'saman' => 'سامان',
        'mellat' => 'ملت',
        'manual' => '📝 ثبت دستی',
        'WC_Gateway_TorobPay' => 'ترب پی',
        'WC_Domino_Zibal_Gateway' => 'زیبال',
        'wc_zibal' => 'زیبال',
        'WCDigiPay' => 'دیجی پی',
        'bank_transfer' => 'انتقال بانکی',
        'check_payment' => 'پرداخت با چک',
        'cash_on_delivery' => 'پرداخت در محل',
        'paypal' => 'پی پال',
        'stripe' => 'استرایپ',
        'bacs' => 'انتقال بانکی (BACS)',
        'cheque' => 'پرداخت با چک',
        'paystack' => 'پی استک',
        'razorpay' => 'ریزر پی',
        'instamojo' => 'اینستا موجو',
        'phonepe' => 'فون پی',
        'paytm' => 'پی تی ام',
        'gpay' => 'جی پی',
        'applepay' => 'اپل پی'
    ];
    
    if (!isset($gateways[$gateway_id])) {
        $name = str_replace(['_', '-'], ' ', $gateway_id);
        $name = str_replace(['wc', 'gateway'], '', $name);
        $name = ucwords($name);
        return trim($name);
    }
    
    return $gateways[$gateway_id];
}

// ==================== AJAX برای دریافت داده‌های سفارش‌ها ====================
add_action('wp_ajax_bzc_get_orders_data', 'bzc_ajax_get_orders_data');
function bzc_ajax_get_orders_data() {
    check_ajax_referer('bzc_nonce', 'nonce');
    
    $start_date_persian = sanitize_text_field($_POST['start_date']);
    $end_date_persian = sanitize_text_field($_POST['end_date']);
    $search = sanitize_text_field($_POST['search']);
    
    $start_date = bzc_persian_to_gregorian($start_date_persian);
    $end_date = bzc_persian_to_gregorian($end_date_persian);
    
    if (empty($start_date) || empty($end_date)) {
        wp_send_json_error('تاریخ وارد شده نامعتبر است');
        return;
    }
    
    $valid_statuses = ['wc-processing', 'wc-sent'];
    
    $args = [
        'limit' => -1,
        'return' => 'objects',
        'date_created' => $start_date . '...' . $end_date,
        'status' => $valid_statuses,
        'type' => 'shop_order'
    ];
    
    $orders = wc_get_orders($args);
    
    if (empty($orders)) {
        wp_send_json([
            'orders' => [],
            'summary' => [
                'total_sales' => 0,
                'total_items' => 0,
                'total_cost' => 0,
                'total_gross_profit' => 0,
                'total_gateway_fee' => 0,
                'total_net_profit' => 0
            ],
            'gateway_summary' => [],
            'partners' => []
        ]);
        return;
    }
    
    $partners = get_option('bzc_partners', []);
    $gateways_fee = get_option('bzc_gateways_fee', []);
    
    $total_sales = 0;
    $total_items = 0;
    $total_cost = 0;
    $total_gross_profit = 0;
    $total_gateway_fee = 0;
    $total_net_profit = 0;
    $orders_data = [];
    $gateway_summary = [];
    
    foreach ($orders as $order) {
        if (!method_exists($order, 'get_payment_method')) {
            continue;
        }
        
        $order_status = 'wc-' . $order->get_status();
        if (!in_array($order_status, $valid_statuses)) continue;
        
        if (!empty($search)) {
            $match = false;
            if (strpos(strval($order->get_id()), $search) !== false) $match = true;
            foreach ($order->get_items() as $item) {
                if (strpos($item->get_name(), $search) !== false) $match = true;
            }
            if (!$match) continue;
        }
        
        $order_total = $order->get_total();
        $gateway_id = $order->get_payment_method();
        
        $order_date = $order->get_date_created();
        $order_date_formatted = $order_date ? $order_date->date_i18n('Y-m-d H:i') : '';
        
        if (empty($gateway_id)) {
            $gateway_id = 'manual';
        }
        
        if (!isset($gateway_summary[$gateway_id])) {
            $gateway_summary[$gateway_id] = [
                'name' => $gateway_id,
                'total_sales' => 0,
                'total_fee' => 0,
                'total_net_profit' => 0,
                'order_count' => 0,
                'items_count' => 0
            ];
        }
        
        $fee_config = $gateways_fee[$gateway_id] ?? null;
        $order_gateway_fee = bzc_calculate_gateway_fee($order_total, $fee_config);
        
        if ($gateway_id == 'manual' && $order_gateway_fee == 0 && $fee_config === null) {
            $order_gateway_fee = 0;
        }
        
        $order_total_sales = 0;
        $order_total_cost = 0;
        $order_gross_profit = 0;
        $order_gateway_fee_total = 0;
        $order_net_profit_total = 0;
        
        foreach ($order->get_items() as $item) {
            $qty = $item->get_quantity();
            $price_sell_total = floatval($item->get_total());
            
            if ($price_sell_total == 0) {
                $product = $item->get_product();
                if ($product) {
                    $price_sell_total = floatval($product->get_price()) * $qty;
                }
            }
            
            $unit_sell_price = $price_sell_total / $qty;
            $product_name = $item->get_name();
            
            $meta_key = '_bzc_buy_price_' . sanitize_title($product_name);
            $saved_buy_price_total = floatval(get_post_meta($order->get_id(), $meta_key, true));
            
            if ($saved_buy_price_total == 0) {
                if ($price_sell_total > 0) {
                    $saved_buy_price_total = $price_sell_total * 0;
                } else {
                    $product = $item->get_product();
                    if ($product) {
                        $product_price = floatval($product->get_price());
                        $saved_buy_price_total = $product_price * $qty * 0;
                        $price_sell_total = $product_price * $qty;
                        $unit_sell_price = $product_price;
                    }
                }
            }
            
            $unit_buy_price = $saved_buy_price_total / $qty;
            
            $item_fee_share = 0;
            if ($order_total > 0 && $order_gateway_fee > 0) {
                $item_fee_share = ($price_sell_total / $order_total) * $order_gateway_fee;
            }
            
            $gross_profit = $price_sell_total - $saved_buy_price_total;
            $net_profit = $gross_profit - $item_fee_share;
            
            $orders_data[] = [
                'order_id' => $order->get_id(),
                'order_date' => $order_date_formatted,
                'product' => $product_name,
                'qty' => $qty,
                'unit_sell_price' => round($unit_sell_price),
                'total_sell' => round($price_sell_total),
                'unit_buy_price' => round($unit_buy_price),
                'total_buy' => round($saved_buy_price_total),
                'gateway' => ($gateway_id == 'manual') ? 'ثبت دستی' : $gateway_id,
                'fee_share' => round($item_fee_share),
                'gross_profit' => round($gross_profit),
                'net_profit' => round($net_profit),
                'status' => $order_status
            ];
            
            $order_total_sales += $price_sell_total;
            $order_total_cost += $saved_buy_price_total;
            $order_gross_profit += $gross_profit;
            $order_gateway_fee_total += $item_fee_share;
            $order_net_profit_total += $net_profit;
            
            $total_sales += $price_sell_total;
            $total_items += $qty;
            $total_cost += $saved_buy_price_total;
            $total_gross_profit += $gross_profit;
            $total_gateway_fee += $item_fee_share;
            $total_net_profit += $net_profit;
        }
        
        $gateway_summary[$gateway_id]['total_sales'] += $order_total_sales;
        $gateway_summary[$gateway_id]['total_fee'] += $order_gateway_fee_total;
        $gateway_summary[$gateway_id]['total_net_profit'] += $order_net_profit_total;
        $gateway_summary[$gateway_id]['order_count'] += 1;
        $gateway_summary[$gateway_id]['items_count'] += $order->get_item_count();
    }
    
    $gateway_summary_output = [];
    foreach ($gateway_summary as $gateway_id => $data) {
        $gateway_summary_output[] = [
            'gateway_id' => $gateway_id,
            'gateway_name' => bzc_get_gateway_display_name($gateway_id),
            'total_sales' => round($data['total_sales']),
            'total_fee' => round($data['total_fee']),
            'net_sales' => round($data['total_sales'] - $data['total_fee']),
            'total_net_profit' => round($data['total_net_profit']),
            'order_count' => $data['order_count'],
            'items_count' => $data['items_count']
        ];
    }
    
    usort($gateway_summary_output, function($a, $b) {
        return $b['total_sales'] - $a['total_sales'];
    });
    
    $partners_share_details = [];
    $total_partner_percent = array_sum(array_column($partners, 'percent'));
    $remaining_percent = max(0, 100 - $total_partner_percent);
    
    foreach ($partners as $partner) {
        $partner_gross_share = $total_gross_profit * ($partner['percent'] / 100);
        
        $partner_fee_percent = isset($partner['fee_percent']) ? $partner['fee_percent'] : null;
        if ($partner_fee_percent !== null) {
            $partner_fee_share = $total_gateway_fee * ($partner_fee_percent / 100);
        } else {
            $partners_without_fee = array_filter($partners, function($p) { return !isset($p['fee_percent']) || $p['fee_percent'] === null; });
            $equal_count = count($partners_without_fee);
            $partner_fee_share = $equal_count > 0 ? $total_gateway_fee / $equal_count : 0;
        }
        
        $partner_final_share = $partner_gross_share - $partner_fee_share;
        
        $partners_share_details[] = [
            'name' => $partner['name'],
            'gross_share' => round($partner_gross_share),
            'fee_share' => round($partner_fee_share),
            'final_share' => round($partner_final_share),
            'percent' => $partner['percent'],
            'fee_percent' => $partner_fee_percent
        ];
    }
    
    if ($remaining_percent > 0) {
        $remaining_gross = $total_gross_profit * ($remaining_percent / 100);
        $remaining_fee = $total_gateway_fee * ($remaining_percent / 100);
        $partners_share_details[] = [
            'name' => 'سود انباشته (حساب اصلی)',
            'gross_share' => round($remaining_gross),
            'fee_share' => round($remaining_fee),
            'final_share' => round($remaining_gross - $remaining_fee),
            'percent' => $remaining_percent,
            'fee_percent' => $remaining_percent,
            'is_remaining' => true
        ];
    }
    
    wp_send_json([
        'orders' => $orders_data,
        'summary' => [
            'total_sales' => round($total_sales),
            'total_items' => $total_items,
            'total_cost' => round($total_cost),
            'total_gross_profit' => round($total_gross_profit),
            'total_gateway_fee' => round($total_gateway_fee),
            'total_net_profit' => round($total_net_profit)
        ],
        'gateway_summary' => $gateway_summary_output,
        'partners' => $partners_share_details
    ]);
}

// AJAX برای ذخیره قیمت خرید تکی
add_action('wp_ajax_bzc_save_buy_price', 'bzc_ajax_save_buy_price');
function bzc_ajax_save_buy_price() {
    check_ajax_referer('bzc_nonce', 'nonce');
    $order_id = intval($_POST['order_id']);
    $product_name = sanitize_text_field($_POST['product_name']);
    $buy_price = floatval($_POST['buy_price']);
    update_post_meta($order_id, '_bzc_buy_price_' . sanitize_title($product_name), $buy_price);
    wp_send_json_success(['message' => 'قیمت خرید با موفقیت ذخیره شد']);
}

// AJAX برای ذخیره همه قیمت‌ها
add_action('wp_ajax_bzc_save_all_buy_prices', 'bzc_ajax_save_all_buy_prices');
function bzc_ajax_save_all_buy_prices() {
    check_ajax_referer('bzc_nonce', 'nonce');
    $prices = $_POST['prices'];
    $saved_count = 0;
    foreach ($prices as $price_data) {
        update_post_meta(intval($price_data['order_id']), '_bzc_buy_price_' . sanitize_title($price_data['product_name']), floatval($price_data['buy_price']));
        $saved_count++;
    }
    wp_send_json_success(['message' => $saved_count . ' قیمت با موفقیت ذخیره شد']);
}

// ==================== صفحه تنظیمات ====================
function bzc_render_settings_page() {
    if (isset($_POST['bzc_save_partners']) && check_admin_referer('bzc_settings')) {
        $partners = [];
        if (isset($_POST['partner_name']) && is_array($_POST['partner_name'])) {
            foreach ($_POST['partner_name'] as $i => $name) {
                if (!empty($name)) {
                    $partners[] = [
                        'name' => sanitize_text_field($name),
                        'percent' => floatval($_POST['partner_percent'][$i]),
                        'fee_percent' => isset($_POST['partner_fee_percent'][$i]) && $_POST['partner_fee_percent'][$i] !== '' ? floatval($_POST['partner_fee_percent'][$i]) : null
                    ];
                }
            }
        }
        update_option('bzc_partners', $partners);
        echo '<div class="notice notice-success"><p>شرکا با موفقیت ذخیره شدند.</p></div>';
    }

    if (isset($_POST['bzc_save_gateways']) && check_admin_referer('bzc_settings')) {
        $gateways_fee = [];
        
        if (isset($_POST['gateway_id']) && is_array($_POST['gateway_id'])) {
            foreach ($_POST['gateway_id'] as $index => $gateway_id) {
                $type = $_POST['gateway_fee_type'][$gateway_id] ?? 'percent';
                
                if ($type == 'percent') {
                    $gateways_fee[$gateway_id] = [
                        'type' => 'percent',
                        'value' => floatval($_POST['gateway_percent'][$gateway_id] ?? 0)
                    ];
                } 
                elseif ($type == 'fixed') {
                    $gateways_fee[$gateway_id] = [
                        'type' => 'fixed',
                        'value' => floatval($_POST['gateway_fixed'][$gateway_id] ?? 0)
                    ];
                }
                elseif ($type == 'equation') {
                    $ranges = [];
                    if (isset($_POST['gateway_ranges'][$gateway_id]) && is_array($_POST['gateway_ranges'][$gateway_id])) {
                        foreach ($_POST['gateway_ranges'][$gateway_id] as $range) {
                            if (!empty($range['value']) || $range['value'] == '0') {
                                $ranges[] = [
                                    'min' => !empty($range['min']) ? floatval($range['min']) : 0,
                                    'max' => (!empty($range['max']) || $range['max'] == '0') ? floatval($range['max']) : '',
                                    'value_type' => $range['value_type'],
                                    'value' => floatval($range['value'])
                                ];
                            }
                        }
                    }
                    $gateways_fee[$gateway_id] = [
                        'type' => 'equation',
                        'ranges' => $ranges
                    ];
                }
            }
        }
        
        update_option('bzc_gateways_fee', $gateways_fee);
        echo '<div class="notice notice-success"><p>کارمزد درگاه‌ها با موفقیت ذخیره شد.</p></div>';
    }

    $partners = get_option('bzc_partners', []);
    $gateways_fee = get_option('bzc_gateways_fee', []);
    $all_gateways = bzc_get_all_payment_gateways();
    ?>
    <div class="wrap bzc-settings-wrap">
        <h1>تنظیمات BZ-Accounting</h1>
        
        <form method="post">
            <?php wp_nonce_field('bzc_settings'); ?>
            <h2>👥 مدیریت شرکا</h2>
            <p><small>درصد سود: درصد از سود ناخالص | درصد کارمزد: درصد از کارمزد درگاه (خالی = مساوی)</small></p>
            <div id="partners-list">
                <?php foreach ($partners as $idx => $partner): ?>
                    <div class="partner-row">
                        <input type="text" name="partner_name[]" value="<?php echo esc_attr($partner['name']); ?>" placeholder="نام شریک" style="width: 150px;">
                        <input type="number" step="0.1" name="partner_percent[]" value="<?php echo esc_attr($partner['percent']); ?>" placeholder="درصد سود" style="width: 100px;">
                        <input type="number" step="0.1" name="partner_fee_percent[]" value="<?php echo isset($partner['fee_percent']) ? esc_attr($partner['fee_percent']) : ''; ?>" placeholder="درصد کارمزد (اختیاری)" style="width: 150px;">
                        <button type="button" class="remove-partner">حذف</button>
                    </div>
                <?php endforeach; ?>
                <div class="partner-row template" style="display:none;">
                    <input type="text" name="partner_name[]" placeholder="نام شریک" style="width: 150px;">
                    <input type="number" step="0.1" name="partner_percent[]" placeholder="درصد سود" style="width: 100px;">
                    <input type="number" step="0.1" name="partner_fee_percent[]" placeholder="درصد کارمزد (اختیاری)" style="width: 150px;">
                    <button type="button" class="remove-partner">حذف</button>
                </div>
            </div>
            <button type="button" id="add-partner" class="button">افزودن شریک جدید</button>
            <input type="submit" name="bzc_save_partners" class="button button-primary" value="ذخیره شرکا">
        </form>

        <h2>💰 تنظیم کارمزد درگاه‌های پرداخت</h2>
        <p><small>تنظیم کارمزد برای تمام درگاه‌های فعال و غیرفعال (درگاه‌هایی که قبلاً استفاده شده‌اند)</small></p>
        <form method="post">
            <?php wp_nonce_field('bzc_settings'); ?>
            <table class="widefat">
                <thead>
                    <tr>
                        <th>درگاه</th>
                        <th>وضعیت</th>
                        <th>نوع کارمزد</th>
                        <th>تنظیمات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($all_gateways as $gateway): 
                        $id = $gateway['id'];
                        $title = $gateway['title'];
                        $is_active = $gateway['is_active'];
                        $fee = $gateways_fee[$id] ?? ['type' => 'percent', 'value' => 0, 'ranges' => []];
                    ?>
                        <tr class="gateway-row">
                            <td><?php echo esc_html($title); ?><input type="hidden" name="gateway_id[]" value="<?php echo esc_attr($id); ?>"></td>
                            <td>
                                <?php if ($is_active): ?>
                                    <span style="color: #2c7a2c;">✅ فعال</span>
                                <?php else: ?>
                                    <span style="color: #ff9800;">⏸️ غیرفعال</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <select name="gateway_fee_type[<?php echo esc_attr($id); ?>]" class="fee-type" data-gateway="<?php echo esc_attr($id); ?>">
                                    <option value="percent" <?php selected($fee['type'], 'percent'); ?>>درصدی</option>
                                    <option value="fixed" <?php selected($fee['type'], 'fixed'); ?>>ثابت (تومان)</option>
                                    <option value="equation" <?php selected($fee['type'], 'equation'); ?>>رنجی (پلکانی)</option>
                                </select>
                             </td>
                             <td>
                                <div class="fee-percent-section" id="percent-<?php echo esc_attr($id); ?>" style="display: <?php echo ($fee['type'] == 'percent') ? 'block' : 'none'; ?>">
                                    <input type="number" step="0.01" name="gateway_percent[<?php echo esc_attr($id); ?>]" value="<?php echo ($fee['type']=='percent') ? esc_attr($fee['value']) : '0'; ?>" style="width: 150px;"> درصد
                                </div>
                                <div class="fee-fixed-section" id="fixed-<?php echo esc_attr($id); ?>" style="display: <?php echo ($fee['type'] == 'fixed') ? 'block' : 'none'; ?>">
                                    <input type="number" name="gateway_fixed[<?php echo esc_attr($id); ?>]" value="<?php echo ($fee['type']=='fixed') ? esc_attr($fee['value']) : '0'; ?>" style="width: 150px;"> تومان
                                </div>
                                <div class="fee-equation-section" id="equation-<?php echo esc_attr($id); ?>" style="display: <?php echo ($fee['type'] == 'equation') ? 'block' : 'none'; ?>">
                                    <div class="ranges-container" data-gateway="<?php echo esc_attr($id); ?>">
                                        <?php 
                                        $ranges = ($fee['type'] == 'equation' && isset($fee['ranges'])) ? $fee['ranges'] : [];
                                        if (empty($ranges)) $ranges = [['min' => '', 'max' => '', 'value_type' => 'percent', 'value' => '']];
                                        foreach ($ranges as $idx => $range): ?>
                                            <div class="range-row">
                                                <input type="number" name="gateway_ranges[<?php echo esc_attr($id); ?>][<?php echo $idx; ?>][min]" value="<?php echo esc_attr($range['min']); ?>" placeholder="حداقل" style="width:100px">
                                                <input type="number" name="gateway_ranges[<?php echo esc_attr($id); ?>][<?php echo $idx; ?>][max]" value="<?php echo esc_attr($range['max']); ?>" placeholder="حداکثر" style="width:100px">
                                                <select name="gateway_ranges[<?php echo esc_attr($id); ?>][<?php echo $idx; ?>][value_type]">
                                                    <option value="percent" <?php selected($range['value_type'], 'percent'); ?>>درصدی</option>
                                                    <option value="fixed" <?php selected($range['value_type'], 'fixed'); ?>>ثابت</option>
                                                </select>
                                                <input type="number" step="0.01" name="gateway_ranges[<?php echo esc_attr($id); ?>][<?php echo $idx; ?>][value]" value="<?php echo esc_attr($range['value']); ?>" placeholder="مقدار" style="width:100px">
                                                <button type="button" class="remove-range button button-small">❌</button>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                    <button type="button" class="add-range button button-secondary" data-gateway="<?php echo esc_attr($id); ?>">+ افزودن رنج</button>
                                </div>
                             </td>
                         </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <p style="margin-top: 10px; font-size: 12px; color: #666;">
                💡 <strong>نکته:</strong> درگاه‌های غیرفعال نیز نمایش داده می‌شوند تا بتوانید کارمزد آنها را برای گزارش‌های قبلی تنظیم کنید.
            </p>
            <input type="submit" name="bzc_save_gateways" class="button button-primary" value="ذخیره کارمزد درگاه‌ها">
        </form>
    </div>
    <?php
}
?>