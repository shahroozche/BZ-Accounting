jQuery(document).ready(function($) {
    
    // ========== توابع کمکی ==========
    
    function numberFormat(num) {
        if (num === undefined || num === null) return '0';
        return Math.round(num).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }
    
    function getGatewayName(gatewayId) {
        const gateways = {
            'cod': 'پرداخت در محل',
            'zarinpal': 'زرین پال',
            'payir': 'پی آیر',
            'idpay': 'آیدی پی',
            'nextpay': 'نکست پی',
            'saman': 'سامان',
            'mellat': 'ملت',
            'manual': '📝 ثبت دستی',
            'WC_Gateway_TorobPay': 'ترب پی',
            'WC_Domino_Zibal_Gateway': 'زیبال',
            'wc_zibal': 'زیبال',
            'WCDigiPay': 'دیجی پی'
        };
        return gateways[gatewayId] || gatewayId;
    }
    
    function getStatusText(status) {
        const statusMap = {
            'wc-processing': '🟡 درحال آماده سازی',
            'wc-sent': '📦 ارسال شد',
            'wc-pending': '⏳ در انتظار',
            'wc-completed': '✅ تکمیل شده',
            'wc-on-hold': '🔒 در انتظار بررسی',
            'wc-checkout-draft': '📝 پیش‌نویس'
        };
        return statusMap[status] || status;
    }
    
    // ========== توابع تاریخ شمسی ==========
    
    function toPersianDate(gregorianDate) {
        if (!gregorianDate) return '';
        try {
            var date = new Date(gregorianDate);
            if (isNaN(date.getTime())) return gregorianDate;
            return date.toLocaleDateString('fa-IR', {
                year: 'numeric',
                month: '2-digit',
                day: '2-digit'
            }).replace(/\//g, '-');
        } catch(e) {
            return gregorianDate;
        }
    }
    
    function getTodayPersianDate() {
        var today = new Date();
        return toPersianDate(today);
    }
    
    function getYesterdayPersianDate() {
        var yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        return toPersianDate(yesterday);
    }
    
    function isValidPersianDate(dateStr) {
        var pattern = /^(\d{4})-(\d{1,2})-(\d{1,2})$/;
        if (!pattern.test(dateStr)) return false;
        var parts = dateStr.split('-');
        var year = parseInt(parts[0]);
        var month = parseInt(parts[1]);
        var day = parseInt(parts[2]);
        
        if (year < 1300 || year > 1500) return false;
        if (month < 1 || month > 12) return false;
        if (day < 1 || day > 31) return false;
        
        if (month <= 6 && day > 31) return false;
        if (month > 6 && day > 30) return false;
        if (month === 12 && day > 29) return false;
        
        return true;
    }
    
    // ========== تبدیل اعداد فارسی به انگلیسی ==========
    function persianToEnglishNumbers(str) {
        if (!str) return str;
        var persianNumbers = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        var englishNumbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
        for (var i = 0; i < persianNumbers.length; i++) {
            str = str.replace(new RegExp(persianNumbers[i], 'g'), englishNumbers[i]);
        }
        return str;
    }
    
    // ========== تابع اصلی بارگذاری سفارش‌ها ==========
    
    function loadOrders(startDate, endDate, search = '') {
        $('#bzc-orders-table-container').html('<div class="loading">در حال بارگذاری سفارش‌ها...</div>');
        
        // تبدیل اعداد فارسی به انگلیسی برای تاریخ‌ها
        startDate = persianToEnglishNumbers(startDate);
        endDate = persianToEnglishNumbers(endDate);
        search = persianToEnglishNumbers(search);
        
        $.post(bzc_ajax.ajax_url, {
            action: 'bzc_get_orders_data',
            nonce: bzc_ajax.nonce,
            start_date: startDate,
            end_date: endDate,
            search: search
        }, function(res) {
            if (res.error) {
                $('#bzc-orders-table-container').html('<div class="loading" style="color: #ff9800;">⚠️ ' + res.error + '</div>');
                $('#bzc-summary').html('');
                $('#bzc-gateway-summary').html('');
                $('#bzc-partners-share').html('');
                return;
            }
            
            if (!res.orders || res.orders.length === 0) {
                $('#bzc-orders-table-container').html('<div class="loading" style="color: #ff9800;">📭 در بازه تاریخ ' + startDate + ' تا ' + endDate + ' هیچ سفارشی با وضعیت "درحال آماده سازی" یا "ارسال شد" یافت نشد.</div>');
                $('#bzc-summary').html('');
                $('#bzc-gateway-summary').html('');
                $('#bzc-partners-share').html('');
                return;
            }
            
            let html = '<div style="overflow-x: auto;">';
            html += '<table class="bzc-orders-table" style="width: 100%; border-collapse: collapse; direction: rtl;">';
            html += '<thead><tr style="background-color: #2271b1; color: white;">';
            html += '<th style="padding: 12px;">شماره سفارش</th>';
            html += '<th style="padding: 12px;">تاریخ سفارش</th>';
            html += '<th style="padding: 12px;">قلم سفارش</th>';
            html += '<th style="padding: 12px;">تعداد</th>';
            html += '<th style="padding: 12px;">قیمت فروش فی</th>';
            html += '<th style="padding: 12px;">قیمت فروش کل</th>';
            html += '<th style="padding: 12px;">قیمت خرید فی</th>';
            html += '<th style="padding: 12px;">قیمت خرید کل</th>';
            html += '<th style="padding: 12px;">درگاه پرداخت</th>';
            html += '<th style="padding: 12px;">کارمزد</th>';
            html += '<th style="padding: 12px;">سود ناخالص</th>';
            html += '<th style="padding: 12px;">سود خالص</th>';
            html += '<th style="padding: 12px;">وضعیت</th>';
            html += '<th style="padding: 12px;">عملیات</th>';
            html += '</tr></thead><tbody>';
            
            res.orders.forEach((order, index) => {
                let rowClass = index % 2 === 0 ? 'background-color: #f9f9f9;' : '';
                let profitColor = order.gross_profit >= 0 ? '#2c7a2c' : '#dc3232';
                let netProfitColor = order.net_profit >= 0 ? '#2c7a2c' : '#dc3232';
                
                html += `<tr data-order-id="${order.order_id}" data-product-name="${order.product}" style="${rowClass}">`;
                html += `<td style="padding: 10px; text-align: center;">${order.order_id}</td>`;
                html += `<td style="padding: 10px; text-align: center; direction: ltr;">${order.order_date || '-'}</td>`;
                html += `<td style="padding: 10px; text-align: right;">${order.product}</td>`;
                html += `<td style="padding: 10px; text-align: center;" class="qty-cell">${numberFormat(order.qty)}</td>`;
                html += `<td style="padding: 10px; text-align: left;">${numberFormat(order.unit_sell_price)}</td>`;
                html += `<td style="padding: 10px; text-align: left;" class="total-sell">${numberFormat(order.total_sell)}</td>`;
                html += `<td style="padding: 10px; text-align: center;"><input type="number" class="buy-price-input" value="${order.unit_buy_price}" step="1000" style="width: 100px; padding: 5px;"></td>`;
                html += `<td style="padding: 10px; text-align: left;" class="total-buy-cell">${numberFormat(order.total_buy)}</td>`;
                html += `<td style="padding: 10px; text-align: center;">${getGatewayName(order.gateway)}</td>`;
                html += `<td style="padding: 10px; text-align: left; color: #ff9800;" class="fee-cell">${numberFormat(order.fee_share)}</td>`;
                html += `<td style="padding: 10px; text-align: left; color: ${profitColor};" class="gross-profit-cell">${numberFormat(order.gross_profit)}</td>`;
                html += `<td style="padding: 10px; text-align: left; color: ${netProfitColor};" class="net-profit-cell">${numberFormat(order.net_profit)}</td>`;
                html += `<td style="padding: 10px; text-align: center;">${getStatusText(order.status)}</td>`;
                html += `<td style="padding: 10px; text-align: center;"><button class="save-buy-price" style="background: #46b450; color: white; border: none; padding: 5px 12px; border-radius: 4px; cursor: pointer;">💾 ذخیره</button></td>`;
                html += `</tr>`;
            });
            
            html += '</tbody></table></div>';
            $('#bzc-orders-table-container').html(html);
            
            let totalFee = 0;
            $('.fee-cell').each(function() {
                let val = parseFloat($(this).text().replace(/,/g, ''));
                if (!isNaN(val)) totalFee += val;
            });
            
            let summaryHtml = `
                <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 12px; margin-top: 20px;">
                    <h3 style="margin-top: 0;">📊 خلاصه بازه (${startDate} تا ${endDate})</h3>
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 15px;">
                        <div style="background: rgba(255,255,255,0.2); padding: 10px; border-radius: 8px;">
                            <strong>فروش کل:</strong><br>${numberFormat(res.summary.total_sales)} تومان
                        </div>
                        <div style="background: rgba(255,255,255,0.2); padding: 10px; border-radius: 8px;">
                            <strong>تعداد اقلام:</strong><br>${numberFormat(res.summary.total_items)}
                        </div>
                        <div style="background: rgba(255,255,255,0.2); padding: 10px; border-radius: 8px;">
                            <strong>خرید کل:</strong><br>${numberFormat(res.summary.total_cost)} تومان
                        </div>
                        <div style="background: rgba(255,255,255,0.2); padding: 10px; border-radius: 8px;">
                            <strong>سود ناخالص کل:</strong><br>${numberFormat(res.summary.total_gross_profit)} تومان
                        </div>
                        <div style="background: rgba(255,255,255,0.2); padding: 10px; border-radius: 8px;">
                            <strong>کارمزد درگاه:</strong><br>${numberFormat(totalFee)} تومان
                        </div>
                        <div style="background: rgba(255,255,255,0.2); padding: 10px; border-radius: 8px;">
                            <strong>سود خالص کل:</strong><br>${numberFormat(res.summary.total_net_profit)} تومان
                        </div>
                    </div>
                </div>
            `;
            $('#bzc-summary').html(summaryHtml);
            
            // ========== بخش خلاصه درگاه‌های پرداخت ==========
            let gatewayHtml = `
                <div style="background: white; padding: 20px; border-radius: 12px; margin-top: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                    <h3 style="margin-top: 0; color: #2271b1;">🏦 خلاصه فروش بر اساس درگاه پرداخت</h3>
                    <div style="overflow-x: auto;">
                        <table style="width: 100%; border-collapse: collapse; direction: rtl; margin-top: 10px;">
                            <thead>
                                <tr style="background-color: #f0f8ff; border-bottom: 2px solid #2271b1;">
                                    <th style="padding: 10px; text-align: center;">درگاه پرداخت</th>
                                    <th style="padding: 10px; text-align: center;">تعداد سفارش</th>
                                    <th style="padding: 10px; text-align: center;">تعداد اقلام</th>
                                    <th style="padding: 10px; text-align: center;">جمع فروش</th>
                                    <th style="padding: 10px; text-align: center;">کارمزد</th>
                                    <th style="padding: 10px; text-align: center;">فروش خالص</th>
                                    <th style="padding: 10px; text-align: center;">سود خالص</th>
                                    <th style="padding: 10px; text-align: center;">درصد از کل</th>
                                </tr>
                            </thead>
                            <tbody>
            `;
            
            if (res.gateway_summary && res.gateway_summary.length > 0) {
                let totalSalesAll = res.summary.total_sales || 1;
                res.gateway_summary.forEach((gateway, index) => {
                    let bgColor = index % 2 === 0 ? '#f9f9f9' : 'white';
                    let percent = (gateway.total_sales / totalSalesAll * 100);
                    gatewayHtml += `
                        <tr style="background-color: ${bgColor}; border-bottom: 1px solid #eee;">
                            <td style="padding: 10px; text-align: center; font-weight: bold;">${gateway.gateway_name}</td>
                            <td style="padding: 10px; text-align: center;">${numberFormat(gateway.order_count)}</td>
                            <td style="padding: 10px; text-align: center;">${numberFormat(gateway.items_count)}</td>
                            <td style="padding: 10px; text-align: left; color: #2c7a2c;">${numberFormat(gateway.total_sales)}</td>
                            <td style="padding: 10px; text-align: left; color: #ff9800;">${numberFormat(gateway.total_fee)}</td>
                            <td style="padding: 10px; text-align: left; color: #2271b1; font-weight: bold;">${numberFormat(gateway.net_sales)}</td>
                            <td style="padding: 10px; text-align: left; color: ${gateway.total_net_profit >= 0 ? '#2c7a2c' : '#dc3232'}; font-weight: bold;">${numberFormat(gateway.total_net_profit)}</td>
                            <td style="padding: 10px; text-align: center;">
                                <div style="background: #e8f0fe; border-radius: 10px; height: 20px; width: 100%; max-width: 150px; margin: 0 auto; position: relative;">
                                    <div style="background: linear-gradient(90deg, #667eea, #764ba2); border-radius: 10px; height: 100%; width: ${Math.min(percent, 100)}%;"></div>
                                    <span style="position: absolute; top: 0; left: 0; right: 0; font-size: 10px; line-height: 20px; text-align: center; color: ${percent > 30 ? 'white' : '#333'};">
                                        ${percent.toFixed(1)}%
                                    </span>
                                </div>
                            </td>
                        </tr>
                    `;
                });
            } else {
                gatewayHtml += `
                    <tr>
                        <td colspan="8" style="padding: 15px; text-align: center; color: #666;">هیچ اطلاعاتی برای نمایش وجود ندارد</td>
                    </tr>
                `;
            }
            
            gatewayHtml += `
                            </tbody>
                        </table>
                    </div>
                </div>
            `;
            
            $('#bzc-gateway-summary').html(gatewayHtml);
            
            // ========== بخش شرکا ==========
            let partnersHtml = `<div style="background: white; padding: 20px; border-radius: 12px; margin-top: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <h3 style="margin-top: 0; color: #2271b1;">👥 سهم شرکا در این بازه</h3>
                <div style="background: #e8f0fe; padding: 10px; border-radius: 8px; margin-bottom: 15px;">
                    📌 سود ناخالص کل: ${numberFormat(res.summary.total_gross_profit)} تومان | 💳 کل کارمزد: ${numberFormat(totalFee)} تومان | 💰 سود خالص کل: ${numberFormat(res.summary.total_net_profit)} تومان
                </div>`;
            
            if (res.partners && res.partners.length > 0) {
                res.partners.forEach(p => {
                    let feeText = p.fee_percent ? `${p.fee_percent}%` : 'مساوی';
                    let isRemaining = p.is_remaining === true;
                    let bgColor = isRemaining ? '#fff8e1' : '#f0f8ff';
                    let borderColor = isRemaining ? '#ff9800' : '#2271b1';
                    
                    partnersHtml += `
                        <div style="background: ${bgColor}; padding: 15px; border-radius: 8px; margin-bottom: 15px; border-right: 4px solid ${borderColor};">
                            <h4 style="margin-top: 0; color: ${borderColor};">${p.name}</h4>
                            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px;">
                                <div>📊 سهم از سود ناخالص (${p.percent}%): ${numberFormat(p.gross_share)} تومان</div>
                                <div>💳 سهم از کارمزد (${feeText}): ${numberFormat(p.fee_share)} تومان</div>
                                <div>💰 <strong>سود نهایی ${p.name}:</strong> ${numberFormat(p.final_share)} تومان</div>
                            </div>
                            <div style="margin-top: 8px; font-size: 11px; color: #666; background: rgba(0,0,0,0.03); padding: 5px; border-radius: 4px;">
                                محاسبه: (${numberFormat(res.summary.total_gross_profit)} × ${p.percent}%) - (${numberFormat(totalFee)} × ${feeText}) = ${numberFormat(p.final_share)} تومان
                            </div>
                        </div>
                    `;
                });
            } else {
                partnersHtml += '<div style="padding: 12px;">هیچ شریکی تعریف نشده است. لطفاً ابتدا در بخش تنظیمات، شرکا را اضافه کنید.</div>';
            }
            
            partnersHtml += `</div>`;
            $('#bzc-partners-share').html(partnersHtml);
        }).fail(function(xhr, status, error) {
            console.error('خطا:', error);
            $('#bzc-orders-table-container').html('<div class="loading" style="color: #dc3232;">❌ خطا در دریافت اطلاعات از سرور. لطفاً دوباره تلاش کنید.</div>');
            $('#bzc-summary').html('');
            $('#bzc-gateway-summary').html('');
            $('#bzc-partners-share').html('');
        });
    }
    
    // ========== رویداد ذخیره تکی ==========
    $(document).on('click', '.save-buy-price', function() {
        let row = $(this).closest('tr');
        let orderId = row.data('order-id');
        let productName = row.data('product-name');
        let newUnitBuyPrice = parseFloat(row.find('.buy-price-input').val());
        let qty = parseFloat(row.find('.qty-cell').text().replace(/,/g, ''));
        let totalSell = parseFloat(row.find('.total-sell').text().replace(/,/g, ''));
        
        if (isNaN(newUnitBuyPrice) || newUnitBuyPrice < 0) {
            alert('⚠️ لطفاً یک قیمت معتبر وارد کنید');
            return;
        }
        
        let totalBuyPrice = newUnitBuyPrice * qty;
        
        $.post(bzc_ajax.ajax_url, {
            action: 'bzc_save_buy_price',
            nonce: bzc_ajax.nonce,
            order_id: orderId,
            product_name: productName,
            buy_price: totalBuyPrice
        }, function(response) {
            if (response.success) {
                let newGrossProfit = totalSell - totalBuyPrice;
                row.find('.total-buy-cell').text(numberFormat(totalBuyPrice));
                row.find('.gross-profit-cell').text(numberFormat(newGrossProfit)).css('color', newGrossProfit >= 0 ? '#2c7a2c' : '#dc3232');
                alert('✓ قیمت خرید با موفقیت ذخیره شد');
                setTimeout(() => $('#bzc-refresh').click(), 500);
            } else {
                alert('❌ خطا در ذخیره سازی قیمت');
            }
        }).fail(function() {
            alert('❌ خطا در ارتباط با سرور');
        });
    });
    
    // ========== رویداد ذخیره همه قیمت‌ها ==========
    $('#bzc-save-all-prices').on('click', function() {
        let allPrices = [];
        let hasError = false;
        
        $('.bzc-orders-table tbody tr').each(function() {
            let row = $(this);
            let newUnitBuyPrice = parseFloat(row.find('.buy-price-input').val());
            let qty = parseFloat(row.find('.qty-cell').text().replace(/,/g, ''));
            
            if (isNaN(newUnitBuyPrice) || newUnitBuyPrice < 0) {
                hasError = true;
                row.find('.buy-price-input').css('border', '2px solid red');
                return false;
            }
            row.find('.buy-price-input').css('border', '');
            
            allPrices.push({
                order_id: row.data('order-id'),
                product_name: row.data('product-name'),
                buy_price: newUnitBuyPrice * qty
            });
        });
        
        if (hasError) {
            alert('⚠️ لطفاً تمام قیمت‌های معتبر را وارد کنید');
            return;
        }
        
        if (allPrices.length === 0) {
            alert('هیچ قیمتی برای ذخیره وجود ندارد');
            return;
        }
        
        let savingBtn = $(this);
        let originalText = savingBtn.text();
        savingBtn.text('در حال ذخیره...').prop('disabled', true);
        
        $.post(bzc_ajax.ajax_url, {
            action: 'bzc_save_all_buy_prices',
            nonce: bzc_ajax.nonce,
            prices: allPrices
        }, function(response) {
            if (response.success) {
                alert(response.data.message);
                $('#bzc-refresh').click();
            } else {
                alert('❌ خطا در ذخیره سازی');
            }
        }).fail(function() {
            alert('❌ خطا در ارتباط با سرور');
        }).always(function() {
            savingBtn.text(originalText).prop('disabled', false);
        });
    });
    
    // ========== خروجی CSV ==========
    $('#bzc-export-csv').on('click', function() {
        let csvRows = [];
        
        let headers = [];
        $('.bzc-orders-table th').each(function() {
            headers.push('"' + $(this).text().replace(/"/g, '""') + '"');
        });
        csvRows.push(headers.join(','));
        
        $('.bzc-orders-table tbody tr').each(function() {
            let rowData = [];
            $(this).find('td').each(function(index) {
                if (index === 6) {
                    let val = $(this).find('input').val();
                    rowData.push('"' + (val ? val.replace(/"/g, '""') : '') + '"');
                } else {
                    let text = $(this).text().trim();
                    rowData.push('"' + text.replace(/"/g, '""') + '"');
                }
            });
            csvRows.push(rowData.join(','));
        });
        
        csvRows.push('""');
        csvRows.push('"*** خلاصه بازه ***"');
        let summaryText = $('#bzc-summary').text();
        let summaryLines = summaryText.split('\n');
        summaryLines.forEach(line => {
            if (line.trim()) {
                csvRows.push('"' + line.trim().replace(/"/g, '""') + '"');
            }
        });
        
        csvRows.push('""');
        csvRows.push('"*** خلاصه درگاه‌های پرداخت ***"');
        let gatewayText = $('#bzc-gateway-summary').text();
        let gatewayLines = gatewayText.split('\n');
        gatewayLines.forEach(line => {
            if (line.trim() && !line.includes('خلاصه فروش بر اساس درگاه پرداخت')) {
                csvRows.push('"' + line.trim().replace(/"/g, '""') + '"');
            }
        });
        
        csvRows.push('""');
        csvRows.push('"*** سهم شرکا ***"');
        let partnersText = $('#bzc-partners-share').text();
        let partnersLines = partnersText.split('\n');
        partnersLines.forEach(line => {
            if (line.trim() && !line.includes('سهم شرکا') && !line.includes('اضافه کنید')) {
                csvRows.push('"' + line.trim().replace(/"/g, '""') + '"');
            }
        });
        
        let blob = new Blob(["\uFEFF" + csvRows.join('\n')], {type: 'text/csv;charset=utf-8;'});
        let link = document.createElement('a');
        let url = URL.createObjectURL(blob);
        link.href = url;
        link.download = 'bz_accounting_report_' + new Date().toISOString().slice(0, 19) + '.csv';
        link.click();
        URL.revokeObjectURL(url);
    });
    
    // ========== رویدادهای اصلی ==========
    $('#bzc-refresh').on('click', function() {
        let startDate = $('#bzc-start-date').val();
        let endDate = $('#bzc-end-date').val();
        let search = $('#bzc-search').val();
        
        // تبدیل اعداد فارسی به انگلیسی
        startDate = persianToEnglishNumbers(startDate);
        endDate = persianToEnglishNumbers(endDate);
        
        if (!startDate || !endDate) {
            alert('⚠️ لطفاً هر دو تاریخ شروع و پایان را وارد کنید');
            return;
        }
        
        if (!isValidPersianDate(startDate) || !isValidPersianDate(endDate)) {
            alert('⚠️ فرمت تاریخ باید YYYY-MM-DD باشد (مثال: 1404-01-01)');
            return;
        }
        
        loadOrders(startDate, endDate, search);
    });
    
    $('#bzc-search').on('keypress', function(e) {
        if (e.which === 13) $('#bzc-refresh').click();
    });
    
    // ========== بارگذاری اولیه ==========
    let today = getTodayPersianDate();
    let yesterday = getYesterdayPersianDate();
    $('#bzc-start-date').val(yesterday);
    $('#bzc-end-date').val(today);
    loadOrders(yesterday, today, '');
    
    // ========== بخش تنظیمات - شرکا ==========
    $('#add-partner').on('click', function() {
        let template = $('.partner-row.template').clone().removeClass('template').show();
        $('#partners-list').append(template);
    });
    
    $(document).on('click', '.remove-partner', function() {
        $(this).closest('.partner-row').remove();
    });
    
    // ========== تنظیمات - رنج‌ها ==========
    $(document).on('click', '.add-range', function() {
        let gatewayId = $(this).data('gateway');
        let container = $(`.ranges-container[data-gateway="${gatewayId}"]`);
        let rangeCount = container.children('.range-row').length;
        
        let newRange = `
            <div class="range-row">
                <input type="number" name="gateway_ranges[${gatewayId}][${rangeCount}][min]" placeholder="حداقل" style="width:100px">
                <input type="number" name="gateway_ranges[${gatewayId}][${rangeCount}][max]" placeholder="حداکثر" style="width:100px">
                <select name="gateway_ranges[${gatewayId}][${rangeCount}][value_type]">
                    <option value="percent">درصدی</option>
                    <option value="fixed">ثابت</option>
                </select>
                <input type="number" step="0.01" name="gateway_ranges[${gatewayId}][${rangeCount}][value]" placeholder="مقدار" style="width:100px">
                <button type="button" class="remove-range button button-small">❌</button>
            </div>
        `;
        container.append(newRange);
    });
    
    $(document).on('click', '.remove-range', function() {
        if ($(this).closest('.ranges-container').children('.range-row').length > 1) {
            $(this).closest('.range-row').remove();
        } else {
            alert('حداقل یک رنج باید وجود داشته باشد');
        }
    });
    
    $(document).on('change', '.fee-type', function() {
        let gatewayId = $(this).data('gateway');
        let type = $(this).val();
        
        $(`#percent-${gatewayId}, #fixed-${gatewayId}, #equation-${gatewayId}`).hide();
        if (type === 'percent') $(`#percent-${gatewayId}`).show();
        else if (type === 'fixed') $(`#fixed-${gatewayId}`).show();
        else if (type === 'equation') $(`#equation-${gatewayId}`).show();
    });
    
    $('.fee-type').each(function() { $(this).trigger('change'); });
    
    // ========== محدود کردن ورودی فیلدهای تاریخ به اعداد انگلیسی ==========
    $('.bzc-persian-datepicker').on('input', function() {
        var val = $(this).val();
        // تبدیل اعداد فارسی به انگلیسی
        val = persianToEnglishNumbers(val);
        // حذف کاراکترهای غیرمجاز (فقط اعداد و خط تیره)
        val = val.replace(/[^0-9\-]/g, '');
        $(this).val(val);
    });
    
    // ========== جلوگیری از ورود اعداد فارسی در فیلدهای عددی ==========
    $(document).on('input', 'input[type="number"]', function() {
        var val = $(this).val();
        val = persianToEnglishNumbers(val);
        $(this).val(val);
    });
});