<?php
if (!defined('ABSPATH')) exit;

/**
 * BZ-Accounting: extended document operations + party reports.
 * Adds purchase invoices, sales/purchase returns, split payments and party ledger reports.
 */
if (!defined('BZC_DOCS_VERSION')) define('BZC_DOCS_VERSION', '1.3.0');

function bzc_invoice_payments_table(){ return bzc_invoice_table('payments'); }

/**
 * Party-ledger convention:
 *   party_effect > 0  => party owes us (receivable)
 *   party_effect < 0  => we owe party (payable)
 *
 * Documents create only a party obligation. They never create income/expense.
 * Real settlements create income/expense and reduce that obligation.
 */
function bzc_docs_party_effect_for_document($type, $amount) {
    $amount = (float) $amount;
    if ($amount <= 0) return 0.0;
    if ($type === 'invoice') return $amount;
    if ($type === 'purchase') return -$amount;
    if ($type === 'sales_return') return -$amount;
    if ($type === 'purchase_return') return $amount;
    return 0.0;
}

function bzc_docs_ensure_party_effect_column() {
    global $wpdb;
    $t = bzc_finance_table('transactions');
    $col = $wpdb->get_var("SHOW COLUMNS FROM {$t} LIKE 'party_effect'");
    if (!$col) $wpdb->query("ALTER TABLE {$t} ADD party_effect decimal(20,2) NOT NULL DEFAULT 0 AFTER party_id");
}

function bzc_docs_add_party_obligation($id, $type, $total, $party, $date) {
    global $wpdb;
    $id = (int)$id; $party = (int)$party; $total = (float)$total;
    if ($id <= 0 || $party <= 0 || $total <= 0) return;
    $effect = bzc_docs_party_effect_for_document($type, $total);
    if (!$effect) return;
    bzc_docs_ensure_party_effect_column();
    $tx = bzc_finance_table('transactions');
    $source_id = 'invoice:'.$id.':obligation';
    $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$tx} WHERE source_type='invoice' AND source_id=%s LIMIT 1", $source_id));
    if ($exists) return;
    $now = current_time('mysql');
    $wpdb->insert($tx, [
        'transaction_date' => $date,
        'type' => 'document_obligation',
        'amount' => abs($effect),
        'account_id' => 0,
        'party_id' => $party,
        'party_effect' => $effect,
        'description' => 'تعهد سند '.bzc_doc_label($type).' #'.$id,
        'reference' => 'invoice:'.$id,
        'source_type' => 'invoice',
        'source_id' => $source_id,
        'status' => 'posted',
        'created_by' => get_current_user_id(),
        'created_at' => $now,
        'updated_at' => $now,
    ]);
}

function bzc_docs_rebuild_party_ledger($id, $type, $total, $party, $date) {
    bzc_docs_add_party_obligation($id, $type, $total, $party, $date);
}

function bzc_docs_backfill_party_obligations() {
    global $wpdb;
    bzc_docs_ensure_party_effect_column();
    $invoices = bzc_invoice_table('invoices');
    $tx = bzc_finance_table('transactions');
    $rows = $wpdb->get_results("SELECT id,type,total,party_id,issue_date,order_id FROM {$invoices} WHERE type IN ('invoice','purchase','sales_return','purchase_return') AND party_id>0 AND total>0", ARRAY_A);
    $created = 0;
    foreach ($rows as $r) {
        $sid = 'invoice:'.(int)$r['id'].':obligation';
        $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$tx} WHERE source_type='invoice' AND source_id=%s LIMIT 1", $sid));
        if ($exists) continue;
        if ($r['type'] === 'invoice' && !empty($r['order_id'])) continue;
        bzc_docs_add_party_obligation((int)$r['id'], $r['type'], (float)$r['total'], (int)$r['party_id'], $r['issue_date']);
        $created++;
    }
    // Online WooCommerce orders are already settled from the customer's point of view;
    // the money is receivable from the gateway, not from the customer. Never affect the customer's party balance.
    $wpdb->query("UPDATE {$tx} SET party_effect = 0 WHERE source_type='woocommerce_order' AND type='gateway_receivable' AND status='posted'");
    // Older builds could have created a document obligation for WooCommerce invoices. Remove that false customer debt.
    $wpdb->query("DELETE t FROM {$tx} t INNER JOIN {$invoices} i ON i.id = CAST(SUBSTRING_INDEX(SUBSTRING_INDEX(t.source_id, ':', 2), ':', -1) AS UNSIGNED) WHERE t.source_type='invoice' AND t.source_id LIKE 'invoice:%:obligation' AND i.type='invoice' AND i.order_id>0");
    return $created;
}

function bzc_docs_maybe_migrate_party_ledger() {
    $version = get_option('bzc_docs_party_ledger_version', '0');
    if (version_compare($version, '1.3.0', '>=')) return;
    bzc_docs_backfill_party_obligations();
    update_option('bzc_docs_party_ledger_version', '1.3.0');
}
add_action('admin_init', 'bzc_docs_maybe_migrate_party_ledger', 5);

function bzc_docs_install(){
    global $wpdb;
    require_once ABSPATH.'wp-admin/includes/upgrade.php';
    $charset=$wpdb->get_charset_collate();
    $t=bzc_invoice_payments_table();
    dbDelta("CREATE TABLE {$t} (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        invoice_id bigint(20) unsigned NOT NULL,
        method varchar(20) NOT NULL DEFAULT 'credit',
        amount decimal(20,2) NOT NULL DEFAULT 0,
        account_id bigint(20) unsigned NOT NULL DEFAULT 0,
        check_id bigint(20) unsigned NOT NULL DEFAULT 0,
        check_number varchar(100) NOT NULL DEFAULT '',
        note varchar(255) NOT NULL DEFAULT '',
        created_at datetime NOT NULL,
        PRIMARY KEY(id), KEY invoice_id(invoice_id), KEY method(method), KEY account_id(account_id), KEY check_id(check_id)
    ) {$charset};");

    // Version 1.1.0: repair document accounting to cash-basis.
    // Old versions posted the document total as income/expense and could leave
    // duplicate settlement rows. Rebuild finance effects from the authoritative
    // invoice-payments rows so each real settlement has exactly one transaction.
    global $wpdb;
    $invoices_table=bzc_invoice_table('invoices');
    $rows=$wpdb->get_results("SELECT * FROM {$invoices_table} WHERE type<>'proforma' ORDER BY id ASC",ARRAY_A);
    foreach($rows as $doc){
        $doc_id=(int)$doc['id'];
        $payment_rows=$wpdb->get_results($wpdb->prepare('SELECT * FROM '.bzc_invoice_payments_table().' WHERE invoice_id=%d ORDER BY id ASC',$doc_id),ARRAY_A);
        // Remove old check records tied to this document; the rebuild will recreate pending checks.
        $check_ids=[];
        foreach($payment_rows as $pr){ if(!empty($pr['check_id'])) $check_ids[]=(int)$pr['check_id']; }
        if(!empty($doc['check_id'])) $check_ids[]=(int)$doc['check_id'];
        foreach(array_unique($check_ids) as $cid){ if($cid>0) $wpdb->delete(bzc_finance_table('checks'),['id'=>$cid]); }
        if($check_ids) $wpdb->update($t,['check_id'=>0],['invoice_id'=>$doc_id]);

        if(function_exists('bzc_docs_apply_finance')){
            $payments=[];
            foreach($payment_rows as $pr){
                $payments[]=[
                    'method'=>$pr['method'],
                    'amount'=>(float)$pr['amount'],
                    'account_id'=>(int)$pr['account_id'],
                    'check_number'=>$pr['check_number']
                ];
            }
            bzc_docs_apply_finance($doc_id,$doc['type'],$payments,(float)$doc['total'],(int)$doc['party_id'],$doc['issue_date']);
        }
    }

    update_option('bzc_docs_db_version', BZC_DOCS_VERSION);
}
add_action('plugins_loaded','bzc_docs_maybe_install',35);
function bzc_docs_maybe_install(){ if(get_option('bzc_docs_db_version')!==BZC_DOCS_VERSION) bzc_docs_install(); }

function bzc_doc_label($type){
    return ['invoice'=>'فاکتور فروش','proforma'=>'پیش‌فاکتور','purchase'=>'فاکتور خرید','sales_return'=>'بازگشت از فروش','purchase_return'=>'بازگشت از خرید'][$type]??'سند';
}
function bzc_doc_prefix($type){ return ['invoice'=>'F','proforma'=>'P','purchase'=>'B','sales_return'=>'SR','purchase_return'=>'PR'][$type]??'D'; }
function bzc_doc_next_no($type){
    global $wpdb; $prefix=bzc_doc_prefix($type); $max=$wpdb->get_var($wpdb->prepare("SELECT invoice_no FROM ".bzc_invoice_table('invoices')." WHERE invoice_no LIKE %s ORDER BY id DESC LIMIT 1",$prefix.'-%')); $n=1; if($max&&preg_match('/-(\d+)$/',$max,$m))$n=(int)$m[1]+1; return $prefix.'-'.str_pad($n,6,'0',STR_PAD_LEFT);
}
function bzc_doc_get_payments($invoice_id){
    global $wpdb; $rows=$wpdb->get_results($wpdb->prepare('SELECT * FROM '.bzc_invoice_payments_table().' WHERE invoice_id=%d ORDER BY id',$invoice_id),ARRAY_A);
    if($rows) return $rows;
    $r=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.bzc_invoice_table('invoices').' WHERE id=%d',$invoice_id),ARRAY_A);
    if(!$r)return [];
    $amount=(float)$r['total']; if($amount<=0)return [];
    return [[
        'id'=>0,'invoice_id'=>$invoice_id,'method'=>$r['payment_type']?:'credit','amount'=>$amount,
        'account_id'=>(int)$r['payment_account_id'],'check_id'=>(int)$r['check_id'],'check_number'=>'','note'=>'','created_at'=>$r['created_at']
    ]];
}
function bzc_doc_payment_summary($invoice_id){
    $rows=bzc_doc_get_payments($invoice_id); $paid=0;$credit=0;$check=0;$bank=0;
    foreach($rows as $r){$a=(float)$r['amount']; if($r['method']==='credit')$credit+=$a; elseif($r['method']==='check'){$check+=$a;$paid+=$a;} else {$bank+=$a;$paid+=$a;}}
    return ['paid'=>$paid,'credit'=>$credit,'check'=>$check,'bank'=>$bank,'rows'=>$rows];
}

// Add the operation center and party report menu.
add_action('admin_menu',function(){
    add_submenu_page('bz-accounting','عملیات فاکتور','🧾 عملیات فاکتور','manage_options','bz-accounting-documents','bzc_docs_center');
    add_submenu_page('bz-accounting','گزارش طرف حساب‌ها','👥 گزارش طرف حساب‌ها','manage_options','bz-accounting-party-reports','bzc_docs_party_reports');
    add_submenu_page(null,'سند جدید','سند جدید','manage_options','bz-accounting-document-form','bzc_docs_form_page');
},30);

// UI assets for document operations and party reports.
add_action('admin_enqueue_scripts', function($hook){
    if (strpos($hook, 'bz-accounting-documents') === false && strpos($hook, 'bz-accounting-party-reports') === false && strpos($hook, 'bz-accounting-document-form') === false) return;
    wp_enqueue_style('bzc-finance', BZC_PLUGIN_URL . 'accounting.css', [], BZC_FINANCE_VERSION);
});

function bzc_docs_center(){
    if(!current_user_can('manage_options')) wp_die('دسترسی غیرمجاز');
    $doc_view=sanitize_key($_GET['doc_view']??'');
    if(in_array($doc_view,['invoice','proforma'],true) && function_exists('bzc_invoice_admin_page')) {
        bzc_invoice_admin_page($doc_view);
        return;
    }
    $base=admin_url('admin.php');
    echo '<div class="wrap bzc-docs-wrap" dir="rtl"><div class="bzc-page-head"><div><h1>🧾 عملیات فاکتور</h1><p>تمام اسناد خرید، فروش و مرجوعی را از یکجا مدیریت کنید.</p></div></div><div class="bzc-doc-cards">';
    $cards=[
      ['فاکتور فروش','ثبت، جستجو، ویرایش و چاپ فاکتور فروش','bz-accounting-documents&doc_view=invoice','#1687d9'],
      ['پیش‌فاکتور','ثبت پیش‌فاکتور و تبدیل آن به فاکتور','bz-accounting-documents&doc_view=proforma','#0b6fb8'],
      ['فاکتور خرید','ثبت خرید از تأمین‌کننده و ایجاد بدهی/پرداخت','bz-accounting-document-form&type=purchase','#6b4bb6'],
      ['بازگشت از فروش','ثبت مرجوعی مشتری و برگشت وجه/اعتبار','bz-accounting-document-form&type=sales_return','#c0392b'],
      ['بازگشت از خرید','ثبت مرجوعی به تأمین‌کننده و طلب از تأمین‌کننده','bz-accounting-document-form&type=purchase_return','#d27b00'],
    ];
    foreach($cards as $c){$url=add_query_arg('page',$c[2],$base); if(strpos($c[2],'&')!==false){$parts=explode('&',$c[2]);$url=add_query_arg('page',$parts[0],$base);parse_str(implode('&',array_slice($parts,1)),$q);$url=add_query_arg($q,$url);} echo '<a href="'.esc_url($url).'" class="bzc-doc-card" style="--bzc-accent:'.esc_attr($c[3]).'"><span class="bzc-doc-card-icon">'.($c[0]==='فاکتور فروش'?'🧾':($c[0]==='پیش‌فاکتور'?'📄':($c[0]==='فاکتور خرید'?'🛒':'↩️'))).'</span><strong>'.esc_html($c[0]).'</strong><span class="bzc-doc-card-desc">'.esc_html($c[1]).'</span><span class="bzc-doc-card-arrow">مشاهده ←</span></a>';}
    echo '</div></div>';
}

function bzc_docs_party_reports(){
    if(!current_user_can('manage_options')) wp_die('دسترسی غیرمجاز');
    global $wpdb;
    $party_id=absint($_GET['party_id']??0);
    $q=sanitize_text_field(wp_unslash($_GET['s']??''));
    $pt=bzc_finance_table('parties');
    $tt=bzc_finance_table('transactions');
    $has_effect=(bool)$wpdb->get_var("SHOW COLUMNS FROM {$tt} LIKE 'party_effect'");

    $calc_party=function($pid) use($wpdb,$tt,$has_effect){
        $received=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM {$tt} WHERE party_id=%d AND type='income' AND status='posted'",$pid));
        $paid=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM {$tt} WHERE party_id=%d AND type='expense' AND status='posted'",$pid));
        if($has_effect){
            $net=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(party_effect),0) FROM {$tt} WHERE party_id=%d AND status='posted'",$pid));
        }else{
            $net=$received-$paid;
        }
        return [
            'received'=>$received,
            'paid'=>$paid,
            'receivable'=>max(0,$net),
            'payable'=>max(0,-$net),
            'net'=>$net,
            'status'=>abs($net)<0.005?'تسویه':($net>0?'بدهکار':'بستانکار'),
        ];
    };

    if($party_id){
        $party=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$pt} WHERE id=%d",$party_id),ARRAY_A);
        if(!$party){echo '<div class="wrap" dir="rtl"><div class="notice notice-error"><p>طرف حساب پیدا نشد.</p></div></div>';return;}
        $stats=$calc_party($party_id);
        $ledger=$wpdb->get_results($wpdb->prepare("SELECT t.*, c.name category_name, a.name account_name FROM {$tt} t LEFT JOIN ".bzc_finance_table('categories')." c ON c.id=t.category_id LEFT JOIN ".bzc_finance_table('accounts')." a ON a.id=t.account_id WHERE t.party_id=%d ORDER BY t.transaction_date DESC,t.id DESC",$party_id),ARRAY_A);
        $invoices=$wpdb->get_results($wpdb->prepare("SELECT i.*,p.name party_name FROM ".bzc_invoice_table('invoices')." i LEFT JOIN {$pt} p ON p.id=i.party_id WHERE i.party_id=%d ORDER BY i.issue_date DESC,i.id DESC",$party_id),ARRAY_A);
        echo '<div class="wrap bzc-party-wrap" dir="rtl"><div class="bzc-page-head"><div><h1>👥 گردش حساب: '.esc_html($party['name']).'</h1><p>دریافتی، پرداختی، بدهکاری، بستانکاری و ریز کامل گردش این طرف حساب</p></div></div>';
        echo '<p><a class="button bzc-back-btn" href="'.esc_url(admin_url('admin.php?page=bz-accounting-party-reports')).'">← بازگشت به لیست</a></p>';
        echo '<div class="bzc-party-summary">';
        echo '<div class="bzc-summary-card"><strong>دریافتی</strong><div style="font-size:22px;margin-top:8px">'.esc_html(bzc_finance_money($stats['received'])).'</div></div>';
        echo '<div class="bzc-summary-card"><strong>پرداختی</strong><div style="font-size:22px;margin-top:8px">'.esc_html(bzc_finance_money($stats['paid'])).'</div></div>';
        echo '<div class="bzc-summary-card"><strong>بدهکاری طرف حساب</strong><div style="font-size:22px;margin-top:8px">'.esc_html(bzc_finance_money($stats['receivable'])).'</div><small>طرف حساب به ما بدهکار است</small></div>';
        echo '<div class="bzc-summary-card"><strong>بستانکاری طرف حساب</strong><div style="font-size:22px;margin-top:8px">'.esc_html(bzc_finance_money($stats['payable'])).'</div><small>ما به طرف حساب بدهکاریم</small></div>';
        echo '<div class="bzc-summary-card"><strong>وضعیت</strong><div style="font-size:22px;margin-top:8px">'.esc_html($stats['status']).'</div></div>';
        echo '<div class="bzc-summary-card"><strong>تعداد فاکتورها</strong><div style="font-size:22px;margin-top:8px">'.count($invoices).'</div></div>';
        echo '</div>';
        $detail_doc=absint($_GET['detail_doc']??0);
        $detail_tx=absint($_GET['detail_tx']??0);
        $detail_base=['page'=>'bz-accounting-party-reports','party_id'=>$party_id];

        if($detail_doc){
            $doc=$wpdb->get_row($wpdb->prepare("SELECT i.*,p.name party_name FROM ".bzc_invoice_table('invoices')." i LEFT JOIN {$pt} p ON p.id=i.party_id WHERE i.id=%d AND i.party_id=%d",$detail_doc,$party_id),ARRAY_A);
            if($doc){
                $items=$wpdb->get_results($wpdb->prepare('SELECT * FROM '.bzc_invoice_table('items').' WHERE invoice_id=%d ORDER BY id',$detail_doc),ARRAY_A);
                $payments=bzc_doc_get_payments($detail_doc);
                echo '<section class="bzc-finance-panel bzc-doc-panel bzc-detail-panel"><div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap"><div><h2 style="margin:0">🔎 جزئیات سند '.esc_html($doc['invoice_no']).'</h2><p style="margin:6px 0 0;color:#667085">'.esc_html(bzc_doc_label($doc['type'])).' · '.esc_html(bzc_finance_date($doc['issue_date'])).'</p></div><a class="button" href="'.esc_url(add_query_arg($detail_base,admin_url('admin.php'))).'">بستن جزئیات</a></div>';
                echo '<div class="bzc-party-summary" style="margin-top:18px"><div class="bzc-summary-card"><strong>طرف حساب</strong><div style="font-size:18px;margin-top:8px">'.esc_html($doc['party_name']).'</div></div><div class="bzc-summary-card"><strong>مبلغ سند</strong><div style="font-size:18px;margin-top:8px">'.esc_html(bzc_finance_money($doc['total'])).'</div></div><div class="bzc-summary-card"><strong>وضعیت</strong><div style="font-size:18px;margin-top:8px">'.esc_html($doc['status']).'</div></div></div>';
                echo '<h3>📦 اقلام سند</h3><table class="widefat striped"><thead><tr><th>شرح</th><th>تعداد</th><th>قیمت واحد</th><th>تخفیف</th><th>جمع</th></tr></thead><tbody>';
                foreach($items as $it) echo '<tr><td>'.esc_html($it['product_name']).'</td><td>'.esc_html($it['quantity']).'</td><td>'.esc_html(bzc_finance_money($it['unit_price'])).'</td><td>'.esc_html(bzc_finance_money($it['discount'])).'</td><td>'.esc_html(bzc_finance_money($it['total'])).'</td></tr>';
                echo '</tbody></table>';
                echo '<h3>💳 پرداخت‌ها / تسویه‌های ثبت‌شده</h3><table class="widefat striped"><thead><tr><th>روش</th><th>مبلغ</th><th>حساب</th><th>شماره چک</th><th>جزئیات</th></tr></thead><tbody>';
                foreach($payments as $pay){$method=['credit'=>'نسیه','bank'=>'حساب بانکی','check'=>'چک'][$pay['method']]??$pay['method'];$account='—';if(!empty($pay['account_id'])){$account=$wpdb->get_var($wpdb->prepare('SELECT name FROM '.bzc_finance_table('accounts').' WHERE id=%d',(int)$pay['account_id']))?:'—';}$tx_id=(int)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$tt} WHERE source_type='invoice' AND source_id LIKE %s LIMIT 1",'invoice:'.$detail_doc.':payment:'.(int)$pay['id']));$tx_url=$tx_id?add_query_arg(array_merge($detail_base,['detail_tx'=>$tx_id]),admin_url('admin.php')):'';echo '<tr><td>'.esc_html($method).'</td><td>'.esc_html(bzc_finance_money($pay['amount'])).'</td><td>'.esc_html($account).'</td><td>'.esc_html($pay['check_number']?:'—').'</td><td>'.($tx_url?'<a class="button button-small" href="'.esc_url($tx_url).'">مشاهده جزئیات پرداخت</a>':'<span style="color:#98a2b3">هنوز تسویه واقعی ثبت نشده</span>').'</td></tr>'; }
                echo '</tbody></table></section>';
            }
        }

        if($detail_tx){
            $tx_detail=$wpdb->get_row($wpdb->prepare("SELECT t.*,c.name category_name,a.name account_name FROM {$tt} t LEFT JOIN ".bzc_finance_table('categories')." c ON c.id=t.category_id LEFT JOIN ".bzc_finance_table('accounts')." a ON a.id=t.account_id WHERE t.id=%d AND t.party_id=%d",$detail_tx,$party_id),ARRAY_A);
            if($tx_detail){
                echo '<section class="bzc-finance-panel bzc-doc-panel bzc-detail-panel"><div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap"><div><h2 style="margin:0">💳 جزئیات تراکنش</h2><p style="margin:6px 0 0;color:#667085">'.esc_html(bzc_finance_date($tx_detail['transaction_date'])).'</p></div><a class="button" href="'.esc_url(add_query_arg($detail_base,admin_url('admin.php'))).'">بستن جزئیات</a></div>';
                echo '<table class="widefat striped" style="margin-top:18px"><tbody>';
                $detail_rows=[['شرح',$tx_detail['description']],['نوع',$tx_detail['type']],['مبلغ',bzc_finance_money($tx_detail['amount'])],['حساب',$tx_detail['account_name']?:'—'],['دسته‌بندی',$tx_detail['category_name']?:'—'],['وضعیت',$tx_detail['status']],['اثر روی طرف حساب',((float)$tx_detail['party_effect']>0?'بدهکاری طرف حساب':((float)$tx_detail['party_effect']<0?'بستانکاری طرف حساب':'بدون اثر')).' · '.bzc_finance_money(abs((float)$tx_detail['party_effect']))],['مرجع',$tx_detail['reference']?:'—']];
                foreach($detail_rows as $dr) echo '<tr><th style="width:180px">'.esc_html($dr[0]).'</th><td>'.esc_html($dr[1]).'</td></tr>';
                echo '</tbody></table></section>';
            }
        }

        echo '<section class="bzc-finance-panel bzc-doc-panel"><h2>📄 اسناد</h2><table class="widefat striped"><thead><tr><th>شماره</th><th>نوع</th><th>تاریخ</th><th>مبلغ</th><th>وضعیت</th><th>پرداخت</th><th>عملیات</th></tr></thead><tbody>';
        foreach($invoices as $i){$sum=bzc_doc_payment_summary((int)$i['id']);$du=add_query_arg(array_merge($detail_base,['detail_doc'=>(int)$i['id']]),admin_url('admin.php')); echo '<tr><td>'.esc_html($i['invoice_no']).'</td><td>'.esc_html(bzc_doc_label($i['type'])).'</td><td>'.esc_html(bzc_finance_date($i['issue_date'])).'</td><td>'.esc_html(bzc_finance_money($i['total'])).'</td><td>'.esc_html($i['status']).'</td><td>تسویه: '.esc_html(bzc_finance_money($sum['paid'])).' · مانده: '.esc_html(bzc_finance_money(max(0,(float)$i['total']-$sum['paid']))).'</td><td><a class="button button-small" href="'.esc_url($du).'">مشاهده جزئیات</a></td></tr>';}
        echo '</tbody></table></section>';
        echo '<section class="bzc-finance-panel bzc-doc-panel"><h2>📒 ریز گردش مالی</h2><table class="widefat striped"><thead><tr><th>تاریخ</th><th>شرح</th><th>نوع</th><th>حساب</th><th>اثر</th><th>عملیات</th></tr></thead><tbody>';
        foreach($ledger as $l){
            $e=(float)($l['party_effect']??0);
            $effect_label=$e>0?'بدهکاری طرف حساب':($e<0?'بستانکاری طرف حساب':'بدون اثر');
            $tu=add_query_arg(array_merge($detail_base,['detail_tx'=>(int)$l['id']]),admin_url('admin.php'));
            echo '<tr><td>'.esc_html(bzc_finance_date($l['transaction_date'])).'</td><td>'.esc_html($l['description']).'</td><td>'.esc_html($l['type']).'</td><td>'.esc_html($l['account_name']?:'—').'</td><td style="font-weight:bold">'.esc_html($effect_label.' · '.bzc_finance_money(abs($e))).'</td><td><a class="button button-small" href="'.esc_url($tu).'">مشاهده جزئیات</a></td></tr>';
        }
        echo '</tbody></table></section></div>'; return;
    }

    $where='1=1';$params=[];
    $balance_filter=sanitize_key($_GET['balance']??'all');
    if(!in_array($balance_filter,['all','debtor','creditor','settled'],true)) $balance_filter='all';
    if($q){$like='%'.$wpdb->esc_like($q).'%';$where.=' AND (p.name LIKE %s OR p.phone LIKE %s OR p.email LIKE %s)';$params=[$like,$like,$like];}
    $rows=$wpdb->get_results($params?$wpdb->prepare("SELECT * FROM {$pt} p WHERE {$where} ORDER BY p.name",$params):"SELECT * FROM {$pt} p WHERE {$where} ORDER BY p.name",ARRAY_A);
    $base=admin_url('admin.php');
    echo '<div class="wrap bzc-party-wrap" dir="rtl"><div class="bzc-page-head"><div><h1>👥 گزارش طرف حساب‌ها</h1><p>وضعیت بدهکاری و بستانکاری بر اساس اسناد و تسویه‌های واقعی.</p></div></div>';
    echo '<form class="bzc-party-search" method="get"><input type="hidden" name="page" value="bz-accounting-party-reports"><input type="search" name="s" value="'.esc_attr($q).'" placeholder="نام، موبایل یا ایمیل را جستجو کنید..."><select name="balance" aria-label="فیلتر مانده طرف حساب"><option value="all" '.selected($balance_filter,'all',false).'>همه طرف حساب‌ها</option><option value="debtor" '.selected($balance_filter,'debtor',false).'>بدهکاران</option><option value="creditor" '.selected($balance_filter,'creditor',false).'>بستانکاران</option><option value="settled" '.selected($balance_filter,'settled',false).'>تسویه‌شده‌ها</option></select><button class="button button-primary bzc-search-btn">🔍 اعمال فیلتر</button></form>';
    echo '<section class="bzc-finance-panel bzc-doc-panel"><table class="widefat striped"><thead><tr><th>طرف حساب</th><th>دریافتی</th><th>پرداختی</th><th>بدهکاری</th><th>بستانکاری</th><th>وضعیت</th><th></th></tr></thead><tbody>';
    $shown=0;
    foreach($rows as $p){
        $stats=$calc_party((int)$p['id']);
        if($balance_filter==='debtor' && $stats['net']<=0.005) continue;
        if($balance_filter==='creditor' && $stats['net']>=-0.005) continue;
        if($balance_filter==='settled' && abs($stats['net'])>=0.005) continue;
        $shown++;
        $url=add_query_arg(['page'=>'bz-accounting-party-reports','party_id'=>$p['id']],$base);
        echo '<tr><td><strong>'.esc_html($p['name']).'</strong></td><td>'.esc_html(bzc_finance_money($stats['received'])).'</td><td>'.esc_html(bzc_finance_money($stats['paid'])).'</td><td>'.esc_html(bzc_finance_money($stats['receivable'])).'</td><td>'.esc_html(bzc_finance_money($stats['payable'])).'</td><td><strong>'.esc_html($stats['status']).'</strong></td><td><a class="button" href="'.esc_url($url).'">مشاهده گردش</a></td></tr>';
    }
    if(!$shown) echo '<tr><td colspan="7" style="text-align:center;padding:24px">طرف حسابی با این فیلتر پیدا نشد.</td></tr>';
    echo '</tbody></table></section></div>';
}

function bzc_docs_form_page(){
    if(!current_user_can('manage_options')) wp_die('دسترسی غیرمجاز');
    $type=sanitize_key($_GET['type']??'purchase'); if(!in_array($type,['purchase','sales_return','purchase_return'],true))$type='purchase';
    $msg=bzc_docs_handle_form($type); global $wpdb; $id=absint($_GET['edit']??0); $editing=$id?$wpdb->get_row($wpdb->prepare('SELECT * FROM '.bzc_invoice_table('invoices').' WHERE id=%d AND type=%s',$id,$type),ARRAY_A):null; $items=$editing?$wpdb->get_results($wpdb->prepare('SELECT * FROM '.bzc_invoice_table('items').' WHERE invoice_id=%d ORDER BY id',$id),ARRAY_A):[]; $payments=$editing?bzc_doc_get_payments($id):[]; $accounts=bzc_finance_get_accounts(true); $label=bzc_doc_label($type);$base=admin_url('admin.php?page=bz-accounting-document-form&type='.$type);
    echo '<div class="wrap bzc-doc-form-wrap" dir="rtl"><div class="bzc-page-head"><div><h1>'.esc_html($label).'</h1><p>سند را ثبت کنید و اثر مالی آن را مستقیماً در حسابداری نگه دارید.</p></div></div>';  if($msg)echo '<div class="notice notice-success"><p>'.esc_html($msg).'</p></div>'; echo '<p><a class="button" href="'.esc_url(admin_url('admin.php?page=bz-accounting-documents')).'">← عملیات فاکتور</a></p>';
    $selected_party_id=(int)($editing['party_id']??0); $selected_party=$selected_party_id?bzc_invoice_get_party($selected_party_id):null;
    echo '<section class="bzc-finance-panel bzc-doc-form-panel"><h2>'.($editing?'ویرایش ':'ثبت ').esc_html($label).'</h2><form method="post"><input type="hidden" name="bzc_docs_action" value="save"><input type="hidden" name="bzc_docs_type" value="'.esc_attr($type).'"><input type="hidden" name="id" value="'.esc_attr($id).'">'.wp_nonce_field('bzc_docs_action','bzc_docs_nonce',true,false).'<div class="bzc-doc-meta-grid"><label>طرف حساب <select name="party_id" class="bzc-searchable-select" data-bzc-type="party" data-bzc-placeholder="نام طرف حساب را جستجو کنید" required><option value="">انتخاب کنید</option>'.($selected_party?'<option value="'.(int)$selected_party['id'].'" selected>'.esc_html($selected_party['name']).'</option>':'').'</select></label><label>تاریخ <input name="issue_date" class="bzc-persian-datepicker" value="'.esc_attr($editing?bzc_invoice_date_out($editing['issue_date']):bzc_invoice_date_out()).'"></label><label>سررسید <input name="due_date" class="bzc-persian-datepicker" value="'.esc_attr(!empty($editing['due_date'])?bzc_invoice_date_out($editing['due_date']):'').'"></label></div>'; 
    $items=$items?:[['product_id'=>0,'product_name'=>'','quantity'=>1,'unit_price'=>0,'discount'=>0]]; echo '<div class="bzc-table-wrap"><table class="widefat bzc-doc-table" id="bzc-doc-items"><thead><tr><th>محصول سایت</th><th>شرح</th><th>تعداد</th><th>قیمت واحد</th><th>تخفیف</th><th></th></tr></thead><tbody>';foreach($items as $n=>$it){$sp=!empty($it['product_id'])&&function_exists('wc_get_product')?wc_get_product((int)$it['product_id']):null; echo '<tr><td><select name="items['.$n.'][product_id]" class="bzc-searchable-select bzc-prod" data-bzc-type="product" data-bzc-placeholder="نام محصول را جستجو کنید"><option value="0">محصول دستی</option>'.($sp?'<option value="'.(int)$sp->get_id().'" data-name="'.esc_attr($sp->get_name()).'" data-price="'.esc_attr($sp->get_price()).'" selected>'.esc_html($sp->get_name()).'</option>':'').'</select></td><td><input name="items['.$n.'][product_name]" value="'.esc_attr($it['product_name']).'"></td><td><input name="items['.$n.'][quantity]" type="number" step="0.01" value="'.esc_attr($it['quantity']).'"></td><td><input name="items['.$n.'][unit_price]" type="number" step="0.01" value="'.esc_attr($it['unit_price']).'"></td><td><input name="items['.$n.'][discount]" type="number" step="0.01" value="'.esc_attr($it['discount']).'"></td><td><button type="button" class="button bzc-doc-remove">حذف</button></td></tr>'; }echo '</tbody></table></div><p><button type="button" class="button bzc-add-btn" id="bzc-doc-add">＋ افزودن ردیف کالا</button></p>'; 
    echo '<div class="bzc-totals-grid"><label>تخفیف کلی <input name="discount" type="number" step="0.01" value="'.esc_attr($editing['discount']??0).'"></label><label>مالیات <input name="tax" type="number" step="0.01" value="'.esc_attr($editing['tax']??0).'"></label></div><h3>💳 نحوه تسویه</h3><p style="color:#666">می‌توانی یک سند را همزمان با چند روش تسویه کنی؛ مثلاً بخشی نقد/بانک، بخشی چک و باقی نسیه.</p><div class="bzc-table-wrap"><table class="widefat bzc-payments-table" id="bzc-payments"><thead><tr><th>روش</th><th>مبلغ</th><th>حساب بانکی</th><th>شماره چک</th><th></th></tr></thead><tbody>';
    $payments=$payments?:[['method'=>'credit','amount'=>$editing['total']??0,'account_id'=>0,'check_number'=>'']];foreach($payments as $n=>$pay){echo '<tr><td><select name="payments['.$n.'][method]"><option value="credit" '.selected($pay['method'],'credit',false).'>نسیه</option><option value="bank" '.selected($pay['method'],'bank',false).'>حساب بانکی</option><option value="check" '.selected($pay['method'],'check',false).'>چک</option></select></td><td><input name="payments['.$n.'][amount]" type="number" step="0.01" value="'.esc_attr($pay['amount']).'"></td><td><select name="payments['.$n.'][account_id]"><option value="0">انتخاب حساب</option>';foreach($accounts as $a)if($a['type']==='bank')echo '<option value="'.$a['id'].'" '.selected($pay['account_id'],$a['id'],false).'>'.esc_html($a['name']).'</option>';echo '</select></td><td><input name="payments['.$n.'][check_number]" value="'.esc_attr($pay['check_number']).'"></td><td><button type="button" class="button bzc-pay-remove">حذف</button></td></tr>'; }echo '</tbody></table></div><p><button type="button" class="button bzc-add-btn" id="bzc-pay-add">＋ افزودن روش پرداخت</button></p><div class="bzc-notes-field"><label>توضیحات<br><textarea name="notes" rows="3">'.esc_textarea($editing['notes']??'').'</textarea></label></div><p><button class="button button-primary bzc-save-btn">💾 ذخیره سند</button></p></form></section>'; 
    // list
    $rows=$wpdb->get_results($wpdb->prepare("SELECT i.*,p.name party_name FROM ".bzc_invoice_table('invoices')." i LEFT JOIN ".bzc_finance_table('parties')." p ON p.id=i.party_id WHERE i.type=%s ORDER BY i.id DESC LIMIT 300", $type),ARRAY_A); echo '<section class="bzc-finance-panel bzc-doc-panel"><h2>اسناد ثبت‌شده</h2><table class="widefat striped"><thead><tr><th>شماره</th><th>طرف حساب</th><th>تاریخ</th><th>مبلغ</th><th>عملیات</th></tr></thead><tbody>';foreach($rows as $r){$print=function_exists('bzc_invoice_print_url')?bzc_invoice_print_url((int)$r['id'],$type):'';echo '<tr><td>'.esc_html($r['invoice_no']).'</td><td>'.esc_html($r['party_name']).'</td><td>'.esc_html(bzc_finance_date($r['issue_date'])).'</td><td>'.esc_html(bzc_finance_money($r['total'])).'</td><td>'.($print?'<a target="_blank" class="button button-small" href="'.esc_url($print).'">مشاهده/چاپ</a> ':'').'<a class="button button-small" href="'.esc_url(add_query_arg('edit',$r['id'],$base)).'">ویرایش</a></td></tr>'; }echo '</tbody></table></section></div>';
    echo '<script>jQuery(function($){$("#bzc-doc-add").on("click",function(){let n=$("#bzc-doc-items tbody tr").length,r=$("#bzc-doc-items tbody tr:first").clone();r.find(".bzc-searchable-wrap").remove();r.find("select.bzc-searchable-select").show().removeAttr("data-bzc-init").val(0);r.find("input").val("");r.find("input[name*=quantity]").val(1);r.find("input[name*=unit_price],input[name*=discount]").val(0);r.find("input,select").each(function(){let nm=$(this).attr("name");if(nm)$(this).attr("name",nm.replace(/items\\[\\d+\\]/,"items["+n+"]"));});$("#bzc-doc-items tbody").append(r);if(window.bzcInitSearchableSelects)window.bzcInitSearchableSelects(r);});$("#bzc-doc-items").on("click",".bzc-doc-remove",function(){$(this).closest("tr").remove();});$("#bzc-pay-add").on("click",function(){let n=$("#bzc-payments tbody tr").length,r=$("#bzc-payments tbody tr:first").clone();r.find("input").val("");r.find("select").first().val("credit");r.find("select").last().val(0);r.find("input[name*=amount]").val(0);r.find("input,select").each(function(){let nm=$(this).attr("name");if(nm)$(this).attr("name",nm.replace(/payments\\[\\d+\\]/,"payments["+n+"]"));});$("#bzc-payments tbody").append(r);});$("#bzc-payments").on("click",".bzc-pay-remove",function(){$(this).closest("tr").remove();});});</script>';
}

function bzc_docs_handle_form($type){
    if(empty($_POST['bzc_docs_action']))return ''; check_admin_referer('bzc_docs_action','bzc_docs_nonce'); global $wpdb; $id=absint($_POST['id']??0);$party=absint($_POST['party_id']??0);$issue=bzc_invoice_date_in($_POST['issue_date']??'');$due=bzc_invoice_date_in($_POST['due_date']??'');$items=[];
    foreach((array)($_POST['items']??[]) as $i){$pid=absint($i['product_id']??0);$name=sanitize_text_field(wp_unslash($i['product_name']??''));$qty=max(.0001,(float)($i['quantity']??1));$price=max(0,(float)($i['unit_price']??0));$disc=max(0,(float)($i['discount']??0));if(!$name&&$pid&&function_exists('wc_get_product')){$p=wc_get_product($pid);$name=$p?$p->get_name():'';}if($name)$items[]=['product_id'=>$pid,'product_name'=>$name,'sku'=>'','quantity'=>$qty,'unit_price'=>$price,'discount'=>$disc,'total'=>max(0,$qty*$price-$disc)];}
    if(!$party||!$issue||!$items)return 'طرف حساب، تاریخ و حداقل یک ردیف کالا الزامی است.';$subtotal=bzc_invoice_items_total($items);$discount=max(0,(float)($_POST['discount']??0));$tax=max(0,(float)($_POST['tax']??0));$total=max(0,$subtotal-$discount+$tax);$payments=[];$sum=0;
    foreach((array)($_POST['payments']??[]) as $p){$m=sanitize_key($p['method']??'credit');if(!in_array($m,['credit','bank','check'],true))continue;$a=max(0,(float)($p['amount']??0));if($a<=0)continue;$acc=absint($p['account_id']??0);$cn=sanitize_text_field(wp_unslash($p['check_number']??''));if($m==='bank'&&!$acc)return 'برای پرداخت بانکی، حساب بانکی را انتخاب کنید.';if($m==='check'&&!$cn)return 'برای چک، شماره چک را وارد کنید.';$payments[]=['method'=>$m,'amount'=>$a,'account_id'=>$acc,'check_number'=>$cn];$sum+=$a;}
    if(!$payments)$payments=[['method'=>'credit','amount'=>$total,'account_id'=>0,'check_number'=>'']]; if($sum>$total+0.01)return 'مجموع پرداخت‌ها نمی‌تواند بیشتر از مبلغ فاکتور باشد.';
    $ptype='credit';if(count($payments)>1)$ptype='mixed';elseif(!empty($payments[0]))$ptype=$payments[0]['method'];$acc=0;foreach($payments as $p)if($p['method']==='bank'){$acc=$p['account_id'];break;}
    $now=current_time('mysql');$table=bzc_invoice_table('invoices');$data=['type'=>$type,'status'=>'issued','party_id'=>$party,'issue_date'=>$issue,'due_date'=>$due?:null,'subtotal'=>$subtotal,'discount'=>$discount,'tax'=>$tax,'total'=>$total,'payment_type'=>$ptype,'payment_account_id'=>$acc,'notes'=>sanitize_textarea_field(wp_unslash($_POST['notes']??'')),'updated_at'=>$now];
    if($id){$old=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d AND type=%s",$id,$type),ARRAY_A);if(!$old)return 'سند پیدا نشد.';bzc_docs_delete_finance($id);$wpdb->update($table,$data,['id'=>$id]);$wpdb->delete(bzc_invoice_table('items'),['invoice_id'=>$id]);$wpdb->delete(bzc_invoice_payments_table(),['invoice_id'=>$id]);$wpdb->delete(bzc_finance_table('checks'),['id'=>(int)$old['check_id']]);$wpdb->update($table,['check_id'=>0],['id'=>$id]);}else{$data['invoice_no']=bzc_doc_next_no($type);$data['created_by']=get_current_user_id();$data['created_at']=$now;$wpdb->insert($table,$data);$id=$wpdb->insert_id;}
    foreach($items as $i)$wpdb->insert(bzc_invoice_table('items'),array_merge($i,['invoice_id'=>$id])); foreach($payments as $p)$wpdb->insert(bzc_invoice_payments_table(),['invoice_id'=>$id,'method'=>$p['method'],'amount'=>$p['amount'],'account_id'=>$p['account_id'],'check_id'=>0,'check_number'=>$p['check_number'],'created_at'=>$now]);
    if($type!=='proforma') bzc_docs_apply_finance($id,$type,$payments,$total,$party,$issue);
    return 'سند با موفقیت ذخیره شد.';
}
function bzc_docs_delete_finance($id){
    global $wpdb;
    $id=(int)$id;
    if($id<=0)return;
    $wpdb->query($wpdb->prepare("DELETE FROM ".bzc_finance_table('transactions')." WHERE source_type='invoice' AND (source_id=%s OR source_id LIKE %s OR reference=%s)",'invoice:'.$id,'invoice:'.$id.':%','invoice:'.$id));
    $checks=$wpdb->get_col($wpdb->prepare('SELECT check_id FROM '.bzc_invoice_payments_table().' WHERE invoice_id=%d AND check_id>0',$id));
    $legacy=(int)$wpdb->get_var($wpdb->prepare('SELECT check_id FROM '.bzc_invoice_table('invoices').' WHERE id=%d',$id));
    if($legacy)$checks[]=$legacy;
    $legacy_checks=$wpdb->get_col($wpdb->prepare('SELECT id FROM '.bzc_finance_table('checks').' WHERE description LIKE %s OR description LIKE %s','%#'.$id.'%','%سند #'.$id.'%'));
    $checks=array_unique(array_map('intval',array_merge($checks,$legacy_checks)));
    foreach($checks as $cid)if($cid>0)$wpdb->delete(bzc_finance_table('checks'),['id'=>$cid]);
    $wpdb->delete(bzc_invoice_payments_table(),['invoice_id'=>$id]);
}
function bzc_docs_apply_finance($id,$type,$payments,$total,$party,$date){
    global $wpdb;
    $tx=bzc_finance_table('transactions');
    $now=current_time('mysql');
    $id=(int)$id;
    $total=(float)$total;
    $party=(int)$party;

    /*
     * Cash-basis rule:
     * The document itself is NOT income/expense. Only an actual settlement
     * recorded on the document creates an income/expense transaction.
     * Credit (نسیه) creates no income/expense until it is actually settled.
     */
    $valid_types=['invoice','purchase','sales_return','purchase_return'];
    if(!in_array($type,$valid_types,true)) return;

    // The document creates a party obligation, not income/expense.
    // It is rebuilt together with the settlement rows so edits remain consistent.

    // Idempotency: rebuild only this document's financial effects.
    $wpdb->query($wpdb->prepare(
        "DELETE FROM {$tx} WHERE source_type='invoice' AND (source_id=%s OR source_id LIKE %s)",
        'invoice:'.$id,
        'invoice:'.$id.':%'
    ));

    bzc_docs_add_party_obligation($id, $type, $total, $party, $date);

    $persisted=[];
    if(function_exists('bzc_invoice_payments_table')){
        $persisted=$wpdb->get_results($wpdb->prepare(
            'SELECT * FROM '.bzc_invoice_payments_table().' WHERE invoice_id=%d ORDER BY id ASC',$id
        ),ARRAY_A);
    }

    foreach((array)$payments as $index=>$p){
        $a=(float)($p['amount']??0);
        if($a<=0) continue;
        $method=sanitize_key($p['method']??'credit');
        if($method==='credit') continue;

        $row=$persisted[$index]??null;
        $payment_id=$row?(int)$row['id']:0;
        $account_id=$row?(int)$row['account_id']:(int)($p['account_id']??0);
        $check_number=$row?(string)$row['check_number']:sanitize_text_field($p['check_number']??'');
        $source_id='invoice:'.$id.':payment:'.($payment_id?:($index+1));

        if($wpdb->get_var($wpdb->prepare("SELECT id FROM {$tx} WHERE source_type='invoice' AND source_id=%s LIMIT 1",$source_id))) continue;

        // Sales / purchase returns bring money in. Purchases / sales returns send money out.
        $money_in=in_array($type,['invoice','purchase_return'],true);
        $tx_type=$money_in?'income':'expense';
        $party_effect=$money_in ? -$a : $a;

        if($method==='bank'){
            if(!$account_id) continue;
            $wpdb->insert($tx,[
                'transaction_date'=>$date,'type'=>$tx_type,'amount'=>$a,'account_id'=>$account_id,
                'party_id'=>$party,'party_effect'=>$party_effect,
                'description'=>'تسویه '.bzc_doc_label($type).' #'.$id,
                'reference'=>'invoice:'.$id,'source_type'=>'invoice','source_id'=>$source_id,
                'status'=>'posted','created_by'=>get_current_user_id(),'created_at'=>$now,'updated_at'=>$now
            ]);
        }elseif($method==='check'){
            if(!$check_number) continue;
            $check_type=$money_in?'received':'issued';
            $wpdb->insert(bzc_finance_table('checks'),[
                'check_type'=>$check_type,'party_id'=>$party,'account_id'=>$account_id,
                'amount'=>$a,'check_number'=>$check_number,'status'=>'pending',
                'description'=>'چک بابت '.bzc_doc_label($type).' #'.$id,
                'created_at'=>$now,'updated_at'=>$now
            ]);
            $cid=(int)$wpdb->insert_id;
            if($payment_id && function_exists('bzc_invoice_payments_table')){
                $wpdb->update(bzc_invoice_payments_table(),['check_id'=>$cid],['id'=>$payment_id]);
            }
            $wpdb->update(bzc_invoice_table('invoices'),['check_id'=>$cid],['id'=>$id]);
            $wpdb->insert($tx,[
                'transaction_date'=>$date,'type'=>$tx_type,'amount'=>$a,'account_id'=>0,
                'party_id'=>$party,'party_effect'=>$party_effect,
                'description'=>'تسویه چک '.bzc_doc_label($type).' #'.$id,
                'reference'=>'invoice:'.$id,'source_type'=>'invoice','source_id'=>$source_id,
                'status'=>'posted','created_by'=>get_current_user_id(),'created_at'=>$now,'updated_at'=>$now
            ]);
        }
    }

    $paid=0;
    foreach((array)$payments as $p){
        if(sanitize_key($p['method']??'credit')!=='credit') $paid+=(float)($p['amount']??0);
    }
    $wpdb->update(bzc_invoice_table('invoices'),['status'=>($total>$paid+0.001?'partial':'issued')],['id'=>$id]);
}

