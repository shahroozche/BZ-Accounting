<?php
/**
 * Plugin Name: BZ-Accounting
 * Description: افزونه حسابداری پیشرفته وردپرس - داشبورد حرفه‌ای با گزارش‌های روزانه، ماهانه، فصلی، سالانه و کلی
 * Version: 1.75.10
 * Author: Shahrooz Chegini
 */

if (!defined('ABSPATH')) {
    exit;
}

define('BZC_VERSION', '1.75.10');
define('BZC_PLUGIN_URL', plugin_dir_url(__FILE__));
define('BZC_PLUGIN_DIR', plugin_dir_path(__FILE__));

// ماژول حسابداری مستقل؛ منطق قدیمی افزونه دست‌نخورده باقی می‌ماند.
require_once BZC_PLUGIN_DIR . 'accounting-module.php';
require_once BZC_PLUGIN_DIR . 'invoice-module.php';
require_once BZC_PLUGIN_DIR . 'accounting-documents-module.php';

// افزودن منوی ادمین
add_action('admin_menu', 'bzc_add_admin_menu');
function bzc_add_admin_menu() {
    add_menu_page(
        'BZ-Accounting',
        'BZ-Accounting',
        'manage_options',
        'bz-accounting',
        'bzc_render_dashboard_page',
        'dashicons-chart-area',
        25
    );
    add_submenu_page(
        'bz-accounting',
        'داشبورد',
        '📊 داشبورد',
        'manage_options',
        'bz-accounting',
        'bzc_render_dashboard_page'
    );
    add_submenu_page(
        'bz-accounting',
        'سفارش‌ها',
        '📋 سفارش‌ها',
        'manage_options',
        'bz-accounting-orders',
        'bzc_render_main_page'
    );
    add_submenu_page(
        'bz-accounting',
        'گزارش درگاه‌ها',
        '🏦 گزارش درگاه‌ها',
        'manage_options',
        'bz-accounting-gateway-report',
        'bzc_render_gateway_report_page'
    );
    add_submenu_page(
        'bz-accounting',
        'پرداختی درگاه‌ها',
        '💰 پرداختی درگاه‌ها',
        'manage_options',
        'bz-accounting-payments',
        'bzc_render_payments_page'
    );
    add_submenu_page(
        'bz-accounting',
        'تنظیمات',
        '⚙️ تنظیمات',
        'manage_options',
        'bz-accounting-settings',
        'bzc_render_settings_page'
    );
}

// بارگذاری JS و CSS
add_action('admin_enqueue_scripts', 'bzc_enqueue_assets');
function bzc_enqueue_assets($hook) {
    if (strpos($hook, 'bz-accounting') === false) {
        return;
    }
    
    wp_enqueue_script('jquery');
    
    wp_enqueue_style('bzc-persian-datepicker', BZC_PLUGIN_URL . 'assets/css/persian-datepicker.min.css', [], '1.2.0');
    wp_enqueue_script('persian-date', BZC_PLUGIN_URL . 'assets/js/persian-date.min.js', [], '1.1.0', true);
    wp_enqueue_script('persian-datepicker', BZC_PLUGIN_URL . 'assets/js/persian-datepicker.min.js', ['jquery', 'persian-date'], '1.2.0', true);
    
    wp_enqueue_style('bzc-styles', BZC_PLUGIN_URL . 'styles.css', [], BZC_VERSION);
    wp_enqueue_script('bzc-scripts', BZC_PLUGIN_URL . 'scripts.js', ['jquery', 'persian-date', 'persian-datepicker'], BZC_VERSION, true);
    
    wp_localize_script('bzc-scripts', 'bzc_ajax', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('bzc_nonce')
    ]);

    // Searchable party/product selectors used by the accounting and document modules.
    wp_add_inline_script('bzc-scripts', <<<'JS'
(function($){
    'use strict';
    function initSearchableSelect($select){
        if (!$select.length || $select.attr('data-bzc-init') === '1') return;
        $select.attr('data-bzc-init','1');
        var type=$select.data('bzc-type') || '';
        var $wrap=$('<div class="bzc-searchable-wrap"></div>');
        var $input=$('<input type="search" class="bzc-searchable-input" autocomplete="off">');
        var $results=$('<div class="bzc-searchable-results" role="listbox"></div>');
        var selected=$select.val() || '';
        var selectedText=$select.find('option:selected').text() || '';
        $input.attr('placeholder', $select.data('bzc-placeholder') || 'جستجو...').val(selected && selectedText && selectedText !== 'انتخاب کنید' && selectedText !== 'محصول دستی' ? selectedText : '');
        $select.addClass('bzc-searchable-native').hide();
        $select.after($wrap);
        $wrap.append($input,$results);
        var timer=null, xhr=null;
        function closeResults(){ $results.removeClass('is-open').empty(); }
        function render(items){
            $results.empty();
            if(!items.length){$results.append('<div class="bzc-searchable-empty">موردی پیدا نشد.</div>');}
            $.each(items,function(_,item){
                var $item=$('<button type="button" class="bzc-searchable-option"></button>');
                $item.attr('data-value',item.id).text(item.label);
                if(item.meta){$item.append('<small>'+item.meta+'</small>');}
                $item.on('mousedown',function(e){
                    e.preventDefault();
                    var value=String($(this).data('value'));
                    var label=item.label;
                    var $opt=$select.find('option[value="'+CSS.escape(value)+'"]');
                    if(!$opt.length){$opt=$('<option></option>').val(value).text(label);$select.append($opt);}
                    $select.val(value).trigger('change');
                    $input.val(label);
                    closeResults();
                });
                $results.append($item);
            });
            $results.addClass('is-open');
        }
        function search(){
            var term=$input.val().trim();
            if(term.length<2){$results.html('<div class="bzc-searchable-empty">حداقل ۲ حرف وارد کنید.</div>').addClass('is-open');return;}
            if(xhr && xhr.readyState!==4) xhr.abort();
            xhr=$.post(window.bzc_ajax.ajax_url,{action:'bzc_search_select_options',nonce:window.bzc_ajax.nonce,type:type,q:term},function(resp){
                if(resp && resp.success) render(resp.data.items || []); else render([]);
            }).fail(function(){render([]);});
        }
        $input.on('focus',function(){
            var term=$input.val().trim();
            if(term.length>=2) search();
            else $results.html('<div class="bzc-searchable-empty">برای جستجو نام را تایپ کنید.</div>').addClass('is-open');
        });
        $input.on('input',function(){clearTimeout(timer);timer=setTimeout(search,220);});
        $(document).on('mousedown',function(e){if(!$(e.target).closest($wrap).length) closeResults();});
        $select.on('change.bzcSearchable',function(){
            var text=$select.find('option:selected').text() || '';
            if($select.val() && text!=='انتخاب کنید' && text!=='محصول دستی') $input.val(text); else if(!$select.val() || $select.val()==='0') $input.val('');
        });
    }
    window.bzcInitSearchableSelects=function(context){
        var $ctx=context?$(context):$(document);
        $ctx.find('select.bzc-searchable-select').each(function(){initSearchableSelect($(this));});
    };
    $(function(){window.bzcInitSearchableSelects();});
})(jQuery);
JS
    );
    wp_add_inline_style('bzc-styles', <<<'CSS'
.bzc-searchable-wrap{position:relative;min-width:220px;display:inline-block;vertical-align:middle;z-index:100}.bzc-searchable-input{width:100%;min-height:36px;padding:6px 10px;border:1px solid #c3c4c7;border-radius:6px;background:#fff;box-sizing:border-box}.bzc-searchable-input:focus{border-color:#2271b1;box-shadow:0 0 0 1px #2271b1;outline:0}.bzc-searchable-results{display:none;position:absolute;z-index:99999;right:0;left:0;top:calc(100% + 3px);max-height:280px;overflow:auto;background:#fff;border:1px solid #d0d5dd;border-radius:8px;box-shadow:0 10px 30px rgba(16,24,40,.15);padding:4px}.bzc-searchable-results.is-open{display:block}.bzc-doc-form-wrap .bzc-table-wrap{overflow:visible!important}.bzc-doc-form-wrap .bzc-doc-form-panel,.bzc-doc-form-wrap .bzc-finance-panel{overflow:visible!important}.bzc-doc-form-wrap #bzc-doc-items{overflow:visible!important;border-collapse:separate;border-spacing:0}.bzc-doc-form-wrap #bzc-doc-items tbody tr{position:relative}.bzc-doc-form-wrap #bzc-doc-items tbody tr:focus-within{z-index:1001}.bzc-doc-form-wrap #bzc-doc-items tbody td:first-child{position:relative;z-index:1000}.bzc-doc-form-wrap .bzc-searchable-wrap:focus-within{z-index:100000}.bzc-doc-form-wrap .bzc-searchable-results{z-index:1000000!important}.bzc-sales-invoice-page .bzc-searchable-wrap:focus-within{z-index:100000}.bzc-sales-invoice-page .bzc-searchable-results{z-index:1000000!important}.bzc-searchable-option{display:flex;width:100%;text-align:right;align-items:flex-start;gap:5px;flex-direction:column;border:0;background:#fff;padding:9px 10px;border-radius:6px;cursor:pointer;font-size:13px}.bzc-searchable-option:hover{background:#f2f8ff}.bzc-searchable-option small{color:#667085;font-size:11px}.bzc-searchable-empty{padding:12px;color:#667085;text-align:center;font-size:12px}.bzc-searchable-native{display:none!important}
CSS
    );
}

// ==================== صفحه داشبورد جدید ====================
function bzc_render_dashboard_page() {
    $period = isset($_GET['period']) ? sanitize_text_field($_GET['period']) : 'daily';
    $custom_date = isset($_GET['custom_date']) ? sanitize_text_field($_GET['custom_date']) : '';
    
    // محاسبه بازه زمانی
    $date_range = bzc_calculate_date_range($period, $custom_date);
    $start_date = $date_range['start'];
    $end_date = $date_range['end'];
    $start_gregorian = $date_range['start_gregorian'];
    $end_gregorian = $date_range['end_gregorian'];
    
    // دریافت داده‌های گزارش
    $report_data = bzc_get_dashboard_report_data($start_gregorian, $end_gregorian);
    
    // برای دیباگ - نمایش تاریخ‌ها
    // echo "<!-- start_gregorian: $start_gregorian, end_gregorian: $end_gregorian -->";
    // echo "<!-- start_date: $start_date, end_date: $end_date -->";
    
    ?>
    <div class="wrap bzc-wrap bzc-dashboard">
        <!-- هدر داشبورد -->
        <div class="bzc-dashboard-header">
            <div class="bzc-dashboard-title">
                <h1>📊 داشبورد حسابداری</h1>
                <p class="bzc-dashboard-subtitle">گزارش جامع فروش و سودآوری فروشگاه</p>
            </div>
            <div class="bzc-dashboard-date">
                <span class="bzc-date-label">📅 امروز:</span>
                <span class="bzc-date-value" dir="rtl"><?php echo bzc_get_current_persian_date(); ?></span>
            </div>
        </div>
        
        <!-- بخش انتخاب بازه زمانی -->
        <div class="bzc-dashboard-filters">
            <div class="bzc-period-selector">
                <a href="<?php echo add_query_arg('period', 'daily'); ?>" class="bzc-period-btn <?php echo $period == 'daily' ? 'active' : ''; ?>">
                    📅 روزانه
                </a>
                <a href="<?php echo add_query_arg('period', 'monthly'); ?>" class="bzc-period-btn <?php echo $period == 'monthly' ? 'active' : ''; ?>">
                    📆 ماهانه
                </a>
                <a href="<?php echo add_query_arg('period', 'seasonal'); ?>" class="bzc-period-btn <?php echo $period == 'seasonal' ? 'active' : ''; ?>">
                    🌤️ فصلی
                </a>
                <a href="<?php echo add_query_arg('period', 'yearly'); ?>" class="bzc-period-btn <?php echo $period == 'yearly' ? 'active' : ''; ?>">
                    📅 سالانه
                </a>
                <a href="<?php echo add_query_arg('period', 'all'); ?>" class="bzc-period-btn <?php echo $period == 'all' ? 'active' : ''; ?>">
                    📊 کلی
                </a>
            </div>
            
            <div class="bzc-period-info">
                <span class="bzc-period-label">🗓️ بازه:</span>
                <span class="bzc-period-range" dir="rtl">
                    <?php echo esc_html($end_date); ?>  ➜ <?php echo esc_html($start_date); ?>
                </span>
                <span class="bzc-period-days" dir="rtl">(<?php echo $date_range['days']; ?> روز)</span>
            </div>
        </div>
        
        <!-- کارت‌های آماری اصلی -->
        <div class="bzc-dashboard-stats">
            <div class="bzc-stat-card bzc-stat-sales">
                <div class="bzc-stat-icon">💰</div>
                <div class="bzc-stat-content">
                    <span class="bzc-stat-label">جمع فروش</span>
                    <span class="bzc-stat-value"><?php echo number_format($report_data['total_sales']); ?></span>
                    <span class="bzc-stat-unit">تومان</span>
                </div>
            </div>
            
            <div class="bzc-stat-card bzc-stat-profit">
                <div class="bzc-stat-icon">📈</div>
                <div class="bzc-stat-content">
                    <span class="bzc-stat-label">سود خالص</span>
                    <span class="bzc-stat-value <?php echo $report_data['total_net_profit'] >= 0 ? 'positive' : 'negative'; ?>">
                        <?php echo number_format($report_data['total_net_profit']); ?>
                    </span>
                    <span class="bzc-stat-unit">تومان</span>
                </div>
            </div>
            
            <div class="bzc-stat-card bzc-stat-orders">
                <div class="bzc-stat-icon">📦</div>
                <div class="bzc-stat-content">
                    <span class="bzc-stat-label">تعداد سفارش‌ها</span>
                    <span class="bzc-stat-value"><?php echo number_format($report_data['order_count']); ?></span>
                    <span class="bzc-stat-unit">سفارش</span>
                </div>
            </div>
            
            <div class="bzc-stat-card bzc-stat-items">
                <div class="bzc-stat-icon">🛍️</div>
                <div class="bzc-stat-content">
                    <span class="bzc-stat-label">تعداد اقلام</span>
                    <span class="bzc-stat-value"><?php echo number_format($report_data['items_count']); ?></span>
                    <span class="bzc-stat-unit">عدد</span>
                </div>
            </div>
            
            <div class="bzc-stat-card bzc-stat-fee">
                <div class="bzc-stat-icon">💳</div>
                <div class="bzc-stat-content">
                    <span class="bzc-stat-label">کارمزد درگاه</span>
                    <span class="bzc-stat-value"><?php echo number_format($report_data['total_fee']); ?></span>
                    <span class="bzc-stat-unit">تومان</span>
                </div>
            </div>
            
            <div class="bzc-stat-card bzc-stat-profit-margin">
                <div class="bzc-stat-icon">🎯</div>
                <div class="bzc-stat-content">
                    <span class="bzc-stat-label">حاشیه سود</span>
                    <span class="bzc-stat-value"><?php echo number_format($report_data['profit_margin'], 1); ?>%</span>
                    <span class="bzc-stat-unit">درصد</span>
                </div>
            </div>
        </div>
        
        <!-- بقیه کد HTML مانند قبل -->
        <div class="bzc-dashboard-details">
            <div class="bzc-dashboard-row">
                <!-- خلاصه فروش -->
                <div class="bzc-dashboard-col bzc-col-7">
                    <div class="bzc-dashboard-card">
                        <div class="bzc-card-header">
                            <h3>📋 خلاصه فروش</h3>
                            <span class="bzc-card-badge"><?php echo $report_data['order_count']; ?> سفارش</span>
                        </div>
                        <div class="bzc-card-body">
                            <div class="bzc-sales-summary">
                                <div class="bzc-summary-item">
                                    <span class="bzc-summary-label">فروش ناخالص</span>
                                    <span class="bzc-summary-value"><?php echo number_format($report_data['total_sales']); ?></span>
                                </div>
                                <div class="bzc-summary-item">
                                    <span class="bzc-summary-label">قیمت تمام‌شده</span>
                                    <span class="bzc-summary-value"><?php echo number_format($report_data['total_cost']); ?></span>
                                </div>
                                <div class="bzc-summary-item">
                                    <span class="bzc-summary-label">کارمزد درگاه</span>
                                    <span class="bzc-summary-value"><?php echo number_format($report_data['total_fee']); ?></span>
                                </div>
                                <div class="bzc-summary-item bzc-summary-total">
                                    <span class="bzc-summary-label">💰 سود خالص</span>
                                    <span class="bzc-summary-value <?php echo $report_data['total_net_profit'] >= 0 ? 'positive' : 'negative'; ?>">
                                        <?php echo number_format($report_data['total_net_profit']); ?>
                                    </span>
                                </div>
                            </div>
                            
                            <div class="bzc-progress-bars">
                                <div class="bzc-progress-item">
                                    <span class="bzc-progress-label">💰 سود خالص</span>
                                    <div class="bzc-progress-track">
                                        <div class="bzc-progress-fill" style="width: <?php echo min(max($report_data['profit_percentage'], 0), 100); ?>%; background: <?php echo $report_data['profit_percentage'] >= 0 ? '#2ecc71' : '#e74c3c'; ?>;">
                                            <?php echo number_format($report_data['profit_percentage'], 1); ?>%
                                        </div>
                                    </div>
                                </div>
                                <div class="bzc-progress-item">
                                    <span class="bzc-progress-label">📊 حاشیه سود</span>
                                    <div class="bzc-progress-track">
                                        <div class="bzc-progress-fill" style="width: <?php echo min(max($report_data['profit_margin'], 0), 100); ?>%; background: #3498db;">
                                            <?php echo number_format($report_data['profit_margin'], 1); ?>%
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- خلاصه درگاه‌ها -->
                <div class="bzc-dashboard-col bzc-col-5">
                    <div class="bzc-dashboard-card">
                        <div class="bzc-card-header">
                            <h3>🏦 خلاصه درگاه‌ها</h3>
                            <span class="bzc-card-badge"><?php echo count($report_data['gateway_summary']); ?> درگاه</span>
                        </div>
                        <div class="bzc-card-body">
                            <?php if (!empty($report_data['gateway_summary'])): ?>
                                <?php foreach ($report_data['gateway_summary'] as $gateway): ?>
                                    <div class="bzc-gateway-item">
                                        <div class="bzc-gateway-info">
                                            <span class="bzc-gateway-name"><?php echo esc_html($gateway['name']); ?></span>
                                            <span class="bzc-gateway-amount"><?php echo number_format($gateway['total']); ?></span>
                                        </div>
                                        <div class="bzc-gateway-bar">
                                            <div class="bzc-gateway-fill" style="width: <?php echo min($gateway['percent'], 100); ?>%; background: <?php echo $gateway['color']; ?>;"></div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <p class="bzc-empty-message">هیچ داده‌ایی برای نمایش وجود ندارد</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="bzc-dashboard-row">
                <!-- شرکا -->
                <div class="bzc-dashboard-col bzc-col-6">
                    <div class="bzc-dashboard-card">
                        <div class="bzc-card-header">
                            <h3>👥 سهم شرکا</h3>
                            <span class="bzc-card-badge"><?php echo count($report_data['partners']); ?> شریک</span>
                        </div>
                        <div class="bzc-card-body">
                            <?php if (!empty($report_data['partners'])): ?>
                                <?php foreach ($report_data['partners'] as $partner): ?>
                                    <div class="bzc-partner-item">
                                        <div class="bzc-partner-info">
                                            <span class="bzc-partner-name"><?php echo esc_html($partner['name']); ?></span>
                                            <span class="bzc-partner-amount <?php echo $partner['final_share'] >= 0 ? 'positive' : 'negative'; ?>">
                                                <?php echo number_format($partner['final_share']); ?>
                                            </span>
                                        </div>
                                        <div class="bzc-partner-bar">
                                            <div class="bzc-partner-fill" style="width: <?php echo min($partner['percent'], 100); ?>%; background: <?php echo $partner['color']; ?>;"></div>
                                        </div>
                                        <div class="bzc-partner-detail">
                                            <span>سهم: <?php echo $partner['percent']; ?>%</span>
                                            <span>سود ناخالص: <?php echo number_format($partner['gross_share']); ?></span>
                                            <span>کارمزد: <?php echo number_format($partner['fee_share']); ?></span>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <p class="bzc-empty-message">هیچ شریکی تعریف نشده است</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- دسترسی سریع -->
                <div class="bzc-dashboard-col bzc-col-6">
                    <div class="bzc-dashboard-card">
                        <div class="bzc-card-header">
                            <h3>🚀 دسترسی سریع</h3>
                            <span class="bzc-card-badge">منو</span>
                        </div>
                        <div class="bzc-card-body">
                            <div class="bzc-quick-links">
                                <a href="<?php echo admin_url('admin.php?page=bz-accounting-orders'); ?>" class="bzc-quick-link bzc-link-blue">
                                    <span class="bzc-link-icon">📋</span>
                                    <div>
                                        <span class="bzc-link-title">سفارش‌ها</span>
                                        <span class="bzc-link-desc">مدیریت و ویرایش سفارش‌ها</span>
                                    </div>
                                    <span class="bzc-link-arrow">➜</span>
                                </a>
                                <a href="<?php echo admin_url('admin.php?page=bz-accounting-gateway-report'); ?>" class="bzc-quick-link bzc-link-green">
                                    <span class="bzc-link-icon">🏦</span>
                                    <div>
                                        <span class="bzc-link-title">گزارش درگاه‌ها</span>
                                        <span class="bzc-link-desc">مشاهده گزارش کامل درگاه‌ها</span>
                                    </div>
                                    <span class="bzc-link-arrow">➜</span>
                                </a>
                                <a href="<?php echo admin_url('admin.php?page=bz-accounting-payments'); ?>" class="bzc-quick-link bzc-link-orange">
                                    <span class="bzc-link-icon">💰</span>
                                    <div>
                                        <span class="bzc-link-title">پرداختی درگاه‌ها</span>
                                        <span class="bzc-link-desc">ثبت و مدیریت پرداختی‌ها</span>
                                    </div>
                                    <span class="bzc-link-arrow">➜</span>
                                </a>
                                <a href="<?php echo admin_url('admin.php?page=bz-accounting-settings'); ?>" class="bzc-quick-link bzc-link-purple">
                                    <span class="bzc-link-icon">⚙️</span>
                                    <div>
                                        <span class="bzc-link-title">تنظیمات</span>
                                        <span class="bzc-link-desc">مدیریت شرکا و کارمزدها</span>
                                    </div>
                                    <span class="bzc-link-arrow">➜</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- فوتر -->
        <div class="bzc-dashboard-footer">
            <p>BZ-Accounting v<?php echo BZC_VERSION; ?> | ساخته شده با ❤️</p>
        </div>
    </div>
    <?php
}

// ==================== توابع کمکی داشبورد ====================

function bzc_get_persian_date_parts() {
    // دریافت تاریخ میلادی امروز
    $today = date('Y-m-d');
    $parts = explode('-', $today);
    $gy = intval($parts[0]);
    $gm = intval($parts[1]);
    $gd = intval($parts[2]);
    
    // تبدیل به شمسی
    $persian = bzc_gregorian_to_persian($gy, $gm, $gd);
    
    // اگر تبدیل ناموفق بود، از تاریخ جایگزین استفاده کن
    if (!is_array($persian) || count($persian) !== 3 || $persian[0] < 1300) {
        return array(1405, 5, 31);
    }
    
    return $persian;
}


function bzc_calculate_date_range($period, $custom_date = '') {
    // دریافت تاریخ شمسی امروز
    $today_persian = bzc_get_persian_date_parts();
    $today_persian_str = sprintf('%04d-%02d-%02d', $today_persian[0], $today_persian[1], $today_persian[2]);
    
    $start_persian = '';
    $end_persian = '';
    $days = 0;
    
    switch ($period) {
        case 'daily':
            $start_persian = $today_persian_str;
            $end_persian = $today_persian_str;
            $days = 1;
            break;
            
        case 'monthly':
            $start_persian = sprintf('%04d-%02d-01', $today_persian[0], $today_persian[1]);
            $end_persian = $today_persian_str;
            $days = $today_persian[2];
            break;
            
        case 'seasonal':
            $month = $today_persian[1];
            if ($month >= 1 && $month <= 3) {
                $start_month = 1;
                $end_month = 3;
            } elseif ($month >= 4 && $month <= 6) {
                $start_month = 4;
                $end_month = 6;
            } elseif ($month >= 7 && $month <= 9) {
                $start_month = 7;
                $end_month = 9;
            } else {
                $start_month = 10;
                $end_month = 12;
            }
            $last_day = ($end_month <= 6) ? 31 : 30;
            if ($end_month == 12) $last_day = 29;
            
            $start_persian = sprintf('%04d-%02d-01', $today_persian[0], $start_month);
            $end_persian = sprintf('%04d-%02d-%02d', $today_persian[0], $end_month, $last_day);
            $days = ($month - $start_month) * 30 + $today_persian[2];
            break;
            
        case 'yearly':
            $start_persian = sprintf('%04d-01-01', $today_persian[0]);
            $end_persian = $today_persian_str;
            $days = ($today_persian[1] - 1) * 30 + $today_persian[2];
            break;
            
        case 'all':
        default:
            $start_persian = '1400-01-01';
            $end_persian = $today_persian_str;
            $days = 365 * 5;
            break;
    }
    
    // تبدیل به میلادی برای کوئری دیتابیس
    $start_gregorian = bzc_persian_to_gregorian($start_persian);
    $end_gregorian = bzc_persian_to_gregorian($end_persian);
    
    // اگر تبدیل ناموفق بود، از تاریخ پیش‌فرض استفاده کن
    if (empty($start_gregorian)) {
        $start_gregorian = date('Y-m-d', strtotime('-30 days'));
    }
    if (empty($end_gregorian)) {
        $end_gregorian = date('Y-m-d');
    }
    
    return [
        'start' => $start_persian,
        'end' => $end_persian,
        'start_gregorian' => $start_gregorian,
        'end_gregorian' => $end_gregorian,
        'days' => $days
    ];
}

// تابع ساده برای تبدیل میلادی به شمسی (فقط برای نمایش)
function bzc_convert_gregorian_to_persian_simple($date) {
    if (empty($date)) return '';
    
    $parts = explode('-', $date);
    if (count($parts) !== 3) return $date;
    
    $year = intval($parts[0]);
    $month = intval($parts[1]);
    $day = intval($parts[2]);
    
    // استفاده از تابع موجود
    $persian = bzc_gregorian_to_persian($year, $month, $day);
    
    if (is_array($persian) && count($persian) === 3) {
        return sprintf('%04d-%02d-%02d', $persian[0], $persian[1], $persian[2]);
    }
    
    return $date;
}

function bzc_gregorian_to_persian($gy, $gm, $gd) {
    // الگوریتم دقیق تبدیل تاریخ میلادی به شمسی
    $g_days_in_month = array(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
    $j_days_in_month = array(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29);
    
    // محاسبه کبیسه بودن سال میلادی
    $is_leap = ($gy % 4 == 0 && ($gy % 100 != 0 || $gy % 400 == 0));
    
    // محاسبه روزهای گذشته از ابتدای سال میلادی
    $gy_days = 0;
    for ($i = 0; $i < $gm - 1; $i++) {
        $gy_days += $g_days_in_month[$i];
    }
    $gy_days += $gd;
    
    // اصلاح برای سال کبیسه
    if ($is_leap && $gm > 2) {
        $gy_days += 1;
    }
    
    // محاسبه روزهای گذشته از 1 ژانویه
    $gy_days = $gy_days - 1;
    
    // محاسبه سال شمسی
    $jy = $gy - 621;
    
    // تعیین موقعیت در سال شمسی
    if ($gy_days >= 79) {
        $jy += 1;
        $gy_days -= 79;
    } else {
        $gy_days += 286;
    }
    
    // پیدا کردن ماه و روز شمسی
    $jm = 1;
    $jd = 1;
    for ($i = 0; $i < 12; $i++) {
        if ($gy_days < $j_days_in_month[$i]) {
            $jm = $i + 1;
            $jd = $gy_days + 1;
            break;
        }
        $gy_days -= $j_days_in_month[$i];
    }
    
    // ===== اصلاح: کم کردن یک سال از تاریخ =====
    $jy = $jy - 1;
    
    return array($jy, $jm, $jd);
}

function bzc_get_current_persian_date() {
    $persian = bzc_get_persian_date_parts();
    $persian_numbers = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    $english_numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    $date_str = sprintf('%04d-%02d-%02d', $persian[0], $persian[1], $persian[2]);
    return str_replace($english_numbers, $persian_numbers, $date_str);
}

function bzc_get_dashboard_report_data($start_date, $end_date) {
    if (!class_exists('WooCommerce')) {
        return [
            'total_sales' => 0,
            'total_cost' => 0,
            'total_fee' => 0,
            'total_net_profit' => 0,
            'order_count' => 0,
            'items_count' => 0,
            'profit_margin' => 0,
            'profit_percentage' => 0,
            'gateway_summary' => [],
            'partners' => []
        ];
    }
    
    // دریافت سفارش‌ها
    $valid_statuses = ['wc-processing', 'wc-sent', 'wc-completed'];
    $args = [
        'limit' => -1,
        'return' => 'objects',
        'status' => $valid_statuses,
        'type' => 'shop_order'
    ];
    
    if (!empty($start_date) && !empty($end_date)) {
        $args['date_created'] = $start_date . '...' . $end_date;
    }
    
    $orders = wc_get_orders($args);
    $gateways_fee = get_option('bzc_gateways_fee', []);
    $partners = get_option('bzc_partners', []);
    
    $total_sales = 0;
    $total_cost = 0;
    $total_fee = 0;
    $total_net_profit = 0;
    $order_count = 0;
    $items_count = 0;
    $gateway_summary = [];
    
    foreach ($orders as $order) {
        if (!method_exists($order, 'get_payment_method')) continue;
        
        $order_total = $order->get_total();
        $gateway_id = $order->get_payment_method();
        if (empty($gateway_id)) $gateway_id = 'manual';
        $order_created = $order->get_date_created();
        $order_date_gregorian = $order_created ? $order_created->date('Y-m-d') : '';
        
        $fee_config = $gateways_fee[$gateway_id] ?? null;
        $order_fee = bzc_calculate_gateway_fee($order_total, $fee_config, $gateway_id, $order_date_gregorian);
        
        $order_sales = 0;
        $order_cost = 0;
        $order_items = 0;
        
        foreach ($order->get_items() as $item) {
            $qty = $item->get_quantity();
            $price_sell_total = floatval($item->get_total());
            
            if ($price_sell_total == 0) {
                $product = $item->get_product();
                if ($product) {
                    $price_sell_total = floatval($product->get_price()) * $qty;
                }
            }
            
            $product_name = $item->get_name();
            $meta_key_buy = '_bzc_buy_price_' . sanitize_title($product_name);
            $meta_key_extra = '_bzc_extra_cost_' . sanitize_title($product_name);
            $buy_price = floatval(get_post_meta($order->get_id(), $meta_key_buy, true));
            $extra_cost = floatval(get_post_meta($order->get_id(), $meta_key_extra, true));
            
            $order_sales += $price_sell_total;
            $order_cost += $buy_price + $extra_cost;
            $order_items += $qty;
        }
        
        $order_net_profit = $order_sales - $order_cost - $order_fee;
        
        $total_sales += $order_sales;
        $total_cost += $order_cost;
        $total_fee += $order_fee;
        $total_net_profit += $order_net_profit;
        $order_count++;
        $items_count += $order_items;
        
        if (!isset($gateway_summary[$gateway_id])) {
            $gateway_summary[$gateway_id] = [
                'name' => bzc_get_gateway_display_name($gateway_id),
                'total' => 0,
                'count' => 0
            ];
        }
        $gateway_summary[$gateway_id]['total'] += $order_sales;
        $gateway_summary[$gateway_id]['count']++;
    }
    
    // محاسبه درصدها
    $profit_margin = $total_sales > 0 ? ($total_net_profit / $total_sales) * 100 : 0;
    $profit_percentage = $total_cost > 0 ? (($total_sales - $total_cost) / $total_cost) * 100 : 0;
    
    // مرتب‌سازی درگاه‌ها
    $gateway_summary_array = [];
    $colors = ['#3498db', '#2ecc71', '#f39c12', '#e74c3c', '#9b59b6', '#1abc9c', '#e67e22', '#34495e'];
    $i = 0;
    $max_total = !empty($gateway_summary) ? max(array_column($gateway_summary, 'total')) : 1;
    foreach ($gateway_summary as $id => $data) {
        $gateway_summary_array[] = [
            'id' => $id,
            'name' => $data['name'],
            'total' => $data['total'],
            'count' => $data['count'],
            'percent' => $max_total > 0 ? ($data['total'] / $max_total) * 100 : 0,
            'color' => $colors[$i % count($colors)]
        ];
        $i++;
    }
    usort($gateway_summary_array, function($a, $b) {
        return $b['total'] - $a['total'];
    });
    
    // محاسبه سهم شرکا
    $partners_share = [];
    $total_gross_profit = $total_sales - $total_cost;
    if ($total_gross_profit > 0 && !empty($partners)) {
        $total_partner_percent = array_sum(array_column($partners, 'percent'));
        $remaining_percent = max(0, 100 - $total_partner_percent);
        
        $partner_colors = ['#3498db', '#2ecc71', '#f39c12', '#e74c3c', '#9b59b6', '#1abc9c', '#e67e22', '#34495e'];
        $j = 0;
        
        foreach ($partners as $partner) {
            $partner_gross_share = $total_gross_profit * ($partner['percent'] / 100);
            $partner_fee_percent = isset($partner['fee_percent']) ? $partner['fee_percent'] : null;
            if ($partner_fee_percent !== null) {
                $partner_fee_share = $total_fee * ($partner_fee_percent / 100);
            } else {
                $partners_without_fee = array_filter($partners, function($p) { return !isset($p['fee_percent']) || $p['fee_percent'] === null; });
                $equal_count = count($partners_without_fee);
                $partner_fee_share = $equal_count > 0 ? $total_fee / $equal_count : 0;
            }
            $partner_final_share = $partner_gross_share - $partner_fee_share;
            
            $partners_share[] = [
                'name' => $partner['name'],
                'gross_share' => round($partner_gross_share),
                'fee_share' => round($partner_fee_share),
                'final_share' => round($partner_final_share),
                'percent' => $partner['percent'],
                'fee_percent' => $partner_fee_percent,
                'color' => $partner_colors[$j % count($partner_colors)]
            ];
            $j++;
        }
        
        if ($remaining_percent > 0) {
            $remaining_gross = $total_gross_profit * ($remaining_percent / 100);
            $remaining_fee = $total_fee * ($remaining_percent / 100);
            $partners_share[] = [
                'name' => 'سود انباشته (حساب اصلی)',
                'gross_share' => round($remaining_gross),
                'fee_share' => round($remaining_fee),
                'final_share' => round($remaining_gross - $remaining_fee),
                'percent' => $remaining_percent,
                'fee_percent' => $remaining_percent,
                'color' => '#95a5a6',
                'is_remaining' => true
            ];
        }
    }
    
    return [
        'total_sales' => round($total_sales),
        'total_cost' => round($total_cost),
        'total_fee' => round($total_fee),
        'total_net_profit' => round($total_net_profit),
        'order_count' => $order_count,
        'items_count' => $items_count,
        'profit_margin' => $profit_margin,
        'profit_percentage' => $profit_percentage,
        'gateway_summary' => $gateway_summary_array,
        'partners' => $partners_share
    ];
}

function bzc_get_dashboard_report_data_prev($start_date, $end_date) {
    if (!class_exists('WooCommerce')) {
        return ['total_sales' => 0, 'total_net_profit' => 0, 'order_count' => 0];
    }
    
    $valid_statuses = ['wc-processing', 'wc-sent', 'wc-completed'];
    $args = [
        'limit' => -1,
        'return' => 'objects',
        'status' => $valid_statuses,
        'type' => 'shop_order'
    ];
    
    if (!empty($start_date) && !empty($end_date)) {
        $args['date_created'] = $start_date . '...' . $end_date;
    }
    
    $orders = wc_get_orders($args);
    $gateways_fee = get_option('bzc_gateways_fee', []);
    
    $total_sales = 0;
    $total_net_profit = 0;
    $order_count = 0;
    
    foreach ($orders as $order) {
        if (!method_exists($order, 'get_payment_method')) continue;
        
        $order_total = $order->get_total();
        $gateway_id = $order->get_payment_method();
        if (empty($gateway_id)) $gateway_id = 'manual';
        $order_created = $order->get_date_created();
        $order_date_gregorian = $order_created ? $order_created->date('Y-m-d') : '';
        
        $fee_config = $gateways_fee[$gateway_id] ?? null;
        $order_fee = bzc_calculate_gateway_fee($order_total, $fee_config, $gateway_id, $order_date_gregorian);
        
        $order_sales = 0;
        $order_cost = 0;
        
        foreach ($order->get_items() as $item) {
            $qty = $item->get_quantity();
            $price_sell_total = floatval($item->get_total());
            
            if ($price_sell_total == 0) {
                $product = $item->get_product();
                if ($product) {
                    $price_sell_total = floatval($product->get_price()) * $qty;
                }
            }
            
            $product_name = $item->get_name();
            $meta_key_buy = '_bzc_buy_price_' . sanitize_title($product_name);
            $meta_key_extra = '_bzc_extra_cost_' . sanitize_title($product_name);
            $buy_price = floatval(get_post_meta($order->get_id(), $meta_key_buy, true));
            $extra_cost = floatval(get_post_meta($order->get_id(), $meta_key_extra, true));
            
            $order_sales += $price_sell_total;
            $order_cost += $buy_price + $extra_cost;
        }
        
        $order_net_profit = $order_sales - $order_cost - $order_fee;
        
        $total_sales += $order_sales;
        $total_net_profit += $order_net_profit;
        $order_count++;
    }
    
    return [
        'total_sales' => $total_sales,
        'total_net_profit' => $total_net_profit,
        'order_count' => $order_count
    ];
}

// ==================== صفحه اصلی (سفارش‌ها) ====================
function bzc_render_main_page() {
    ?>
    <div class="wrap bzc-wrap">
        <h1>📋 BZ-Accounting - مدیریت سفارش‌ها</h1>
        <div class="bzc-filters">
            <label>از تاریخ (شمسی):</label>
            <input type="text" id="bzc-start-date" class="bzc-persian-datepicker" placeholder="۱۴۰۴-۰۱-۰۱" autocomplete="off">
            <label>تا تاریخ (شمسی):</label>
            <input type="text" id="bzc-end-date" class="bzc-persian-datepicker" placeholder="۱۴۰۴-۱۲-۲۹" autocomplete="off">
            <input type="text" id="bzc-search" placeholder="جستجو در سفارش‌ها (شماره/محصول)...">
            <button id="bzc-refresh" class="button button-primary">🔍 نمایش سفارش‌ها</button>
            <button id="bzc-save-all-prices" class="button button-primary">💾 ذخیره همه قیمت‌ها</button>
            <button id="bzc-export-csv" class="button button-primary">📥 خروجی CSV</button>
        </div>
        <div id="bzc-orders-table-container">
            <div class="loading">لطفاً روی دکمه "نمایش سفارش‌ها" کلیک کنید...</div>
        </div>
        <div id="bzc-summary"></div>
        <div id="bzc-gateway-summary"></div>
        <div id="bzc-partners-share"></div>
    </div>
    <?php
}

// ==================== صفحه پرداختی درگاه‌ها ====================
function bzc_render_payments_page() {
    // ذخیره پرداختی جدید
    if (isset($_POST['bzc_save_payment']) && check_admin_referer('bzc_payment_nonce')) {
        $gateway_id = sanitize_text_field($_POST['payment_gateway']);
        $payment_date = sanitize_text_field($_POST['payment_date']);
        $payment_amount = floatval($_POST['payment_amount']);
        $payment_type = isset($_POST['payment_type']) ? sanitize_text_field($_POST['payment_type']) : 'payment';
        
        $bank_account_id = absint($_POST['settlement_bank_account'] ?? 0);
        $settlement_fee = abs((float) ($_POST['settlement_fee'] ?? 0));
        if (!empty($gateway_id) && !empty($payment_date) && $payment_amount > 0) {
            $payments = get_option('bzc_gateway_payments', []);
            $payment_id = uniqid('gst_', true);
            $payment = [
                'id' => $payment_id,
                'gateway_id' => $gateway_id,
                'date' => $payment_date,
                'amount' => $payment_amount,
                'gross_amount' => $payment_amount,
                'fee_amount' => $settlement_fee,
                'net_amount' => max(0, $payment_amount - $settlement_fee),
                'bank_account_id' => $bank_account_id,
                'type' => $payment_type,
                'note' => isset($_POST['payment_note']) ? sanitize_text_field($_POST['payment_note']) : '',
                'created_at' => current_time('mysql')
            ];
            if ($payment_type === 'payment') {
                $gateway_account_id = 0;
                foreach (bzc_get_all_payment_gateways() as $gw) {
                    if ($gw['id'] === $gateway_id) break;
                }
                global $wpdb;
                $gateway_account_id = (int) $wpdb->get_var($wpdb->prepare("SELECT id FROM " . $wpdb->prefix . "bzc_finance_accounts WHERE type='gateway' AND gateway_id=%s LIMIT 1", $gateway_id));
                if (!$gateway_account_id) {
                    echo '<div class="notice notice-error"><p>❌ ابتدا حساب این درگاه را در بخش حسابداری بسازید.</p></div>';
                } elseif (!$bank_account_id) {
                    echo '<div class="notice notice-error"><p>❌ حساب بانکی مقصد تسویه را انتخاب کنید.</p></div>';
                } else {
                    $bank_type = $wpdb->get_var($wpdb->prepare("SELECT type FROM " . $wpdb->prefix . "bzc_finance_accounts WHERE id=%d", $bank_account_id));
                    if ($bank_type !== 'bank') {
                        echo '<div class="notice notice-error"><p>❌ مقصد تسویه باید یک حساب بانکی باشد.</p></div>';
                    } else {
                        $date_g = function_exists('bzc_persian_to_gregorian') ? bzc_persian_to_gregorian($payment_date) : $payment_date;
                        $now = current_time('mysql');
                        // Clear the gross gateway receivable. The bank records the gross transfer and a separate fee expense, so its net balance change equals gross minus fee.
                        $wpdb->insert($wpdb->prefix . 'bzc_finance_transactions', [
                            'transaction_date'=>$date_g, 'type'=>'transfer_out', 'amount'=>$payment_amount,
                            'account_id'=>$gateway_account_id, 'destination_account_id'=>$bank_account_id,
                            'description'=>'تسویه درگاه ' . bzc_get_gateway_display_name($gateway_id), 'reference'=>$payment_id,
                            'source_type'=>'gateway_settlement', 'source_id'=>$payment_id, 'status'=>'posted',
                            'created_by'=>get_current_user_id(), 'created_at'=>$now, 'updated_at'=>$now
                        ]);
                        $wpdb->insert($wpdb->prefix . 'bzc_finance_transactions', [
                            'transaction_date'=>$date_g, 'type'=>'transfer_in', 'amount'=>$payment_amount,
                            'account_id'=>$bank_account_id, 'destination_account_id'=>$gateway_account_id,
                            'description'=>'دریافت تسویه از ' . bzc_get_gateway_display_name($gateway_id), 'reference'=>$payment_id,
                            'source_type'=>'gateway_settlement', 'source_id'=>$payment_id, 'status'=>'posted',
                            'created_by'=>get_current_user_id(), 'created_at'=>$now, 'updated_at'=>$now
                        ]);
                        if ($settlement_fee > 0) {
                            $fee_category = (int) $wpdb->get_var($wpdb->prepare("SELECT id FROM " . $wpdb->prefix . "bzc_finance_categories WHERE name=%s AND type='expense' LIMIT 1", 'کارمزد درگاه'));
                            $wpdb->insert($wpdb->prefix . 'bzc_finance_transactions', [
                                'transaction_date'=>$date_g, 'type'=>'expense', 'amount'=>$settlement_fee,
                                'account_id'=>$bank_account_id, 'destination_account_id'=>0, 'category_id'=>$fee_category,
                                'description'=>'کارمزد تسویه ' . bzc_get_gateway_display_name($gateway_id), 'reference'=>$payment_id,
                                'source_type'=>'gateway_settlement', 'source_id'=>$payment_id, 'status'=>'posted',
                                'created_by'=>get_current_user_id(), 'created_at'=>$now, 'updated_at'=>$now
                            ]);
                        }
                        $payments[] = $payment;
                        update_option('bzc_gateway_payments', $payments);
                        echo '<div class="notice notice-success"><p>✅ تسویه درگاه ثبت شد؛ طلب درگاه کاهش یافت و مبلغ به بانک منتقل شد.</p></div>';
                    }
                }
            } else {
                $payments[] = $payment;
                update_option('bzc_gateway_payments', $payments);
                echo '<div class="notice notice-success"><p>✅ تعدیل کارمزد با موفقیت ثبت شد.</p></div>';
            }
        } else {
            echo '<div class="notice notice-error"><p>❌ لطفاً تمام فیلدها را به درستی پر کنید. مبلغ نمی‌تواند صفر باشد.</p></div>';
        }
    }
    
    // حذف پرداختی
    if (isset($_GET['delete_payment']) && isset($_GET['payment_id']) && check_admin_referer('delete_payment_' . $_GET['payment_id'])) {
        $payments = get_option('bzc_gateway_payments', []);
        $payment_id = sanitize_text_field($_GET['payment_id']);
        $payments = array_filter($payments, function($p) use ($payment_id) {
            return $p['id'] !== $payment_id;
        });
        global $wpdb;
        $wpdb->query($wpdb->prepare('DELETE FROM ' . $wpdb->prefix . 'bzc_finance_transactions WHERE source_type=%s AND source_id=%s', 'gateway_settlement', $payment_id));
        update_option('bzc_gateway_payments', array_values($payments));
        echo '<div class="notice notice-success"><p>✅ پرداختی با موفقیت حذف شد.</p></div>';
    }
    
    $payments = get_option('bzc_gateway_payments', []);
    $all_gateways = bzc_get_all_payment_gateways();
    
    $gateway_list = [];
    foreach ($all_gateways as $gateway) {
        $gateway_list[$gateway['id']] = $gateway['title'] . ($gateway['is_active'] ? '' : ' (غیرفعال)');
    }
    ?>
    <div class="wrap bzc-wrap">
        <h1>💰 پرداختی و تعدیل کارمزد درگاه‌های پرداخت</h1>
        
        <div style="background: white; padding: 20px; border-radius: 12px; margin-bottom: 25px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
            <h3>➕ افزودن تراکنش جدید</h3>
            <form method="post" style="display: flex; gap: 15px; align-items: flex-end; flex-wrap: wrap;">
                <?php wp_nonce_field('bzc_payment_nonce'); ?>
                <div>
                    <label><strong>نوع تراکنش:</strong></label>
                    <select name="payment_type" style="padding: 8px; border-radius: 6px; border: 1px solid #ccc;">
                        <option value="payment">💰 دریافت / تسویه از درگاه</option>
                        <option value="fee_adjustment">⚖️ تعدیل کارمزد</option>
                    </select>
                </div>
                <div>
                    <label><strong>درگاه پرداخت:</strong></label>
                    <select name="payment_gateway" style="padding: 8px; border-radius: 6px; border: 1px solid #ccc;">
                        <?php foreach ($gateway_list as $id => $title): ?>
                            <option value="<?php echo esc_attr($id); ?>"><?php echo esc_html($title); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label><strong>تاریخ (شمسی):</strong></label>
                    <input type="text" name="payment_date" class="bzc-persian-datepicker" placeholder="۱۴۰۴-۰۱-۰۱" autocomplete="off" required>
                </div>
                <div>
                    <label><strong>مبلغ ناخالص تسویه (تومان):</strong></label>
                    <input type="number" name="payment_amount" placeholder="۰" step="1" style="padding: 8px; border-radius: 6px; border: 1px solid #ccc; width: 170px;" required>
                    <br><small style="color: #666;">مبلغی که از طلب درگاه تسویه می‌شود.</small>
                </div>
                <div>
                    <label><strong>کارمزد کسرشده:</strong></label>
                    <input type="number" name="settlement_fee" value="0" min="0" step="1" style="padding: 8px; border-radius: 6px; border: 1px solid #ccc; width: 150px;">
                </div>
                <div style="background:#f0f7ff;border:1px solid #cfe3fb;border-radius:8px;padding:10px 14px;min-width:190px;">
                    <div style="font-size:12px;color:#475569;margin-bottom:5px;">💰 مبلغ خالص واریزی</div>
                    <strong id="bzc-settlement-net-preview" style="font-size:18px;color:#087443;">۰ تومان</strong>
                    <div id="bzc-settlement-preview-note" style="font-size:11px;color:#64748b;margin-top:4px;">ناخالص منهای کارمزد</div>
                </div>
                <div>
                    <label><strong>واریز به حساب بانکی:</strong></label>
                    <select name="settlement_bank_account" style="padding: 8px; border-radius: 6px; border: 1px solid #ccc; min-width: 180px;">
                        <option value="0">انتخاب بانک</option>
                        <?php
                        global $wpdb;
                        $bank_accounts_for_settlement = $wpdb->get_results("SELECT id,name FROM {$wpdb->prefix}bzc_finance_accounts WHERE type='bank' AND is_active=1 ORDER BY name", ARRAY_A);
                        foreach ($bank_accounts_for_settlement as $bank_account):
                        ?>
                            <option value="<?php echo esc_attr($bank_account['id']); ?>"><?php echo esc_html($bank_account['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label><strong>توضیحات (اختیاری):</strong></label>
                    <input type="text" name="payment_note" placeholder="توضیحات..." style="padding: 8px; border-radius: 6px; border: 1px solid #ccc; width: 200px;">
                </div>
                <button type="submit" name="bzc_save_payment" class="button button-primary">💾 ثبت تراکنش</button>
            </form>
            <p style="font-size: 12px; color: #666; margin-top: 10px;">
                💡 <strong>نکات:</strong>
                <br>- <strong>تسویه درگاه:</strong> طلب شما از درگاه را کم می‌کند و مبلغ ناخالص را به بانک می‌آورد؛ کارمزد جداگانه از بانک کم می‌شود.
                <br>- <strong>تعدیل کارمزد:</strong> برای تصحیح اختلاف کارمزد (منفی = کارمزد اضافی، مثبت = کارمزد کمتر محاسبه شده)
            </p>
        </div>
        
        <div style="background: white; padding: 20px; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); overflow-x: auto;">
            <h3>📋 تاریخچه تراکنش‌ها</h3>
            <table class="widefat" style="direction: rtl;">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>نوع</th>
                        <th>درگاه پرداخت</th>
                        <th>وضعیت</th>
                        <th>تاریخ</th>
                        <th>مبلغ ناخالص (تومان)</th>
                        <th>کارمزد (تومان)</th>
                        <th>پرداختی خالص (تومان)</th>
                        <th>توضیحات</th>
                        <th>تاریخ ثبت</th>
                        <th>عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($payments)): ?>
                        <tr><td colspan="11" style="text-align: center; padding: 20px; color: #666;">هیچ تراکنشی ثبت نشده است.</td></tr>
                    <?php else: 
                        $counter = 1;
                        foreach (array_reverse($payments) as $payment):
                            $is_active = false;
                            foreach ($all_gateways as $gateway) {
                                if ($gateway['id'] == $payment['gateway_id']) {
                                    $is_active = $gateway['is_active'];
                                    break;
                                }
                            }
                            $is_fee_adjustment = isset($payment['type']) && $payment['type'] == 'fee_adjustment';
                            $type_label = $is_fee_adjustment ? '⚖️ تعدیل کارمزد' : '💳 پرداختی';
                            $amount_color = $payment['amount'] >= 0 ? '#2c7a2c' : '#dc3232';
                            $amount_display = number_format($payment['amount']);
                            if ($payment['amount'] < 0) {
                                $amount_display = '-' . number_format(abs($payment['amount']));
                            }
                    ?>
                            <tr>
                                <td><?php echo $counter++; ?></td>
                                <td><?php echo $type_label; ?></td>
                                <td><?php echo bzc_get_gateway_display_name($payment['gateway_id']); ?></td>
                                <td>
                                    <?php if ($is_active): ?>
                                        <span style="color: #2c7a2c;">✅ فعال</span>
                                    <?php else: ?>
                                        <span style="color: #ff9800;">⏸️ غیرفعال</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo esc_html($payment['date']); ?></td>
                                <td style="direction:ltr;text-align:left;color:<?php echo $amount_color; ?>;font-weight:bold;">
                                    <?php echo $amount_display; ?>
                                </td>
                                <td><?php echo $is_fee_adjustment ? '—' : number_format((float)($payment['fee_amount'] ?? 0)); ?></td>
                                <td style="color:#087443;font-weight:700;"><?php echo $is_fee_adjustment ? '—' : number_format((float)($payment['net_amount'] ?? max(0, (float)($payment['gross_amount'] ?? $payment['amount']) - (float)($payment['fee_amount'] ?? 0)))); ?></td>
                                <td><?php echo isset($payment['note']) ? esc_html($payment['note']) : '-'; ?></td>
                                <td><?php echo esc_html($payment['created_at']); ?></td>
                                <td>
                                    <a href="<?php echo wp_nonce_url(add_query_arg(['delete_payment' => '1', 'payment_id' => $payment['id']]), 'delete_payment_' . $payment['id']); ?>" 
                                       class="button button-small" 
                                       style="background: #dc3232; color: white; border: none;"
                                       onclick="return confirm('آیا از حذف این تراکنش اطمینان دارید؟')">
                                        🗑️ حذف
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; 
                    endif; ?>
                </tbody>
            </table>
        </div>
        
        <script>
        (function(){
            var form = document.querySelector('.bzc-wrap form');
            if (!form) return;
            var gross = form.querySelector('[name="payment_amount"]');
            var fee = form.querySelector('[name="settlement_fee"]');
            var type = form.querySelector('[name="payment_type"]');
            var output = document.getElementById('bzc-settlement-net-preview');
            var note = document.getElementById('bzc-settlement-preview-note');
            function formatNumber(n){ return Math.max(0, n).toLocaleString('fa-IR') + ' تومان'; }
            function update(){
                var g = parseFloat(gross && gross.value) || 0;
                var f = parseFloat(fee && fee.value) || 0;
                if (output) output.textContent = formatNumber(g - f);
                if (note) note.textContent = 'ناخالص: ' + formatNumber(g) + ' · کارمزد: ' + formatNumber(f);
                var adjustment = type && type.value === 'fee_adjustment';
                if (output) output.parentElement.style.opacity = adjustment ? '.45' : '1';
            }
            if (gross) gross.addEventListener('input', update);
            if (fee) fee.addEventListener('input', update);
            if (type) type.addEventListener('change', update);
            update();
        })();
        </script>

        <!-- ===== بخش خلاصه تعدیل کارمزدها ===== -->
        <?php 
        $fee_adjustments = array_filter($payments, function($p) {
            return isset($p['type']) && $p['type'] == 'fee_adjustment';
        });
        if (!empty($fee_adjustments)):
        ?>
        <div style="background: white; padding: 20px; border-radius: 12px; margin-top: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
            <h3 style="margin-top: 0; color: #ff9800;">⚖️ خلاصه تعدیل کارمزدها</h3>
            <div style="overflow-x: auto;">
                <table class="widefat" style="direction: rtl;">
                    <thead>
                        <tr>
                            <th>درگاه</th>
                            <th>تعداد تعدیل</th>
                            <th>مجموع تعدیل (تومان)</th>
                            <th>توضیحات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $fee_adj_summary = [];
                        foreach ($fee_adjustments as $adj) {
                            $gateway_id = $adj['gateway_id'];
                            if (!isset($fee_adj_summary[$gateway_id])) {
                                $fee_adj_summary[$gateway_id] = [
                                    'count' => 0,
                                    'total' => 0,
                                    'notes' => []
                                ];
                            }
                            $fee_adj_summary[$gateway_id]['count']++;
                            $fee_adj_summary[$gateway_id]['total'] += $adj['amount'];
                            if (!empty($adj['note'])) {
                                $fee_adj_summary[$gateway_id]['notes'][] = $adj['note'];
                            }
                        }
                        foreach ($fee_adj_summary as $gateway_id => $data):
                            $color = $data['total'] >= 0 ? '#2c7a2c' : '#dc3232';
                            $sign = $data['total'] >= 0 ? '+' : '';
                        ?>
                            <tr>
                                <td><strong><?php echo bzc_get_gateway_display_name($gateway_id); ?></strong></td>
                                <td style="text-align: center;"><?php echo $data['count']; ?></td>
                                <td style="direction: ltr; text-align: left; color: <?php echo $color; ?>; font-weight: bold;">
                                    <?php echo $sign . number_format($data['total']); ?>
                                </td>
                                <td><?php echo !empty($data['notes']) ? esc_html(implode(' - ', $data['notes'])) : '-'; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <p style="font-size: 12px; color: #666; margin-top: 10px;">
                💡 <strong>نکته:</strong> مبلغ مثبت = کارمزد کمتر از حد محاسبه شده (بدهکار)، مبلغ منفی = کارمزد اضافی (طلبکار)
            </p>
        </div>
        <?php endif; ?>
    </div>
    <?php
}

// ==================== تابع محاسبه سهم شرکا برای گزارش درگاه ====================
function bzc_calculate_partners_share_for_gateway($total_sales, $total_gateway_fee, $total_cost = 0) {
    $partners = get_option('bzc_partners', []);
    $partners_share_details = [];
    
    $total_gross_profit = $total_sales - $total_cost;
    
    if ($total_gross_profit <= 0) {
        foreach ($partners as $partner) {
            $partners_share_details[] = [
                'name' => $partner['name'],
                'gross_share' => 0,
                'fee_share' => 0,
                'final_share' => 0,
                'percent' => $partner['percent'],
                'fee_percent' => isset($partner['fee_percent']) ? $partner['fee_percent'] : null
            ];
        }
        return $partners_share_details;
    }
    
    $total_partner_percent = array_sum(array_column($partners, 'percent'));
    $remaining_percent = max(0, 100 - $total_partner_percent);
    
    foreach ($partners as $partner) {
        $partner_gross_share = $total_gross_profit * ($partner['percent'] / 100);
        
        $partner_fee_percent = isset($partner['fee_percent']) ? $partner['fee_percent'] : null;
        if ($partner_fee_percent !== null) {
            $partner_fee_share = $total_gateway_fee * ($partner_fee_percent / 100);
        } else {
            $partners_without_fee = array_filter($partners, function($p) { return !isset($p['fee_percent']) || $p['fee_percent'] === null; });
            $equal_count = count($partners_without_fee);
            $partner_fee_share = $equal_count > 0 ? $total_gateway_fee / $equal_count : 0;
        }
        
        $partner_final_share = $partner_gross_share - $partner_fee_share;
        
        $partners_share_details[] = [
            'name' => $partner['name'],
            'gross_share' => round($partner_gross_share),
            'fee_share' => round($partner_fee_share),
            'final_share' => round($partner_final_share),
            'percent' => $partner['percent'],
            'fee_percent' => $partner_fee_percent
        ];
    }
    
    if ($remaining_percent > 0) {
        $remaining_gross = $total_gross_profit * ($remaining_percent / 100);
        $remaining_fee = $total_gateway_fee * ($remaining_percent / 100);
        $partners_share_details[] = [
            'name' => 'سود انباشته (حساب اصلی)',
            'gross_share' => round($remaining_gross),
            'fee_share' => round($remaining_fee),
            'final_share' => round($remaining_gross - $remaining_fee),
            'percent' => $remaining_percent,
            'fee_percent' => $remaining_percent,
            'is_remaining' => true
        ];
    }
    
    return $partners_share_details;
}

// ==================== صفحه گزارش درگاه‌ها ====================
function bzc_render_gateway_report_page() {
    $selected_gateway = isset($_GET['gateway']) ? sanitize_text_field($_GET['gateway']) : '';
    $start_date = isset($_GET['start_date']) ? sanitize_text_field($_GET['start_date']) : '';
    $end_date = isset($_GET['end_date']) ? sanitize_text_field($_GET['end_date']) : '';
    
    $start_date_gregorian = !empty($start_date) ? bzc_persian_to_gregorian($start_date) : '';
    $end_date_gregorian = !empty($end_date) ? bzc_persian_to_gregorian($end_date) : '';
    
    $active_gateways = bzc_get_active_payment_gateways();
    $payments = get_option('bzc_gateway_payments', []);
    $gateways_fee = get_option('bzc_gateways_fee', []);
    
    $orders_data = bzc_get_orders_by_gateway($start_date_gregorian, $end_date_gregorian, $gateways_fee);
    
    $all_gateway_ids = [];
    foreach ($orders_data as $order) {
        if (!empty($order['gateway']) && !in_array($order['gateway'], $all_gateway_ids)) {
            $all_gateway_ids[] = $order['gateway'];
        }
    }
    
    foreach ($payments as $payment) {
        if (!empty($payment['gateway_id']) && !in_array($payment['gateway_id'], $all_gateway_ids)) {
            $all_gateway_ids[] = $payment['gateway_id'];
        }
    }
    
    foreach ($active_gateways as $gateway_id => $title) {
        if (!in_array($gateway_id, $all_gateway_ids)) {
            $all_gateway_ids[] = $gateway_id;
        }
    }
    
    $all_gateways = [];
    foreach ($all_gateway_ids as $gateway_id) {
        if (isset($active_gateways[$gateway_id])) {
            $all_gateways[$gateway_id] = $active_gateways[$gateway_id];
        } else {
            $all_gateways[$gateway_id] = bzc_get_gateway_display_name($gateway_id);
        }
    }
    
    $gateway_reports = [];
    foreach ($all_gateways as $gateway_id => $gateway_title) {
        $gateway_orders = array_filter($orders_data, function($order) use ($gateway_id) {
            return $order['gateway'] === $gateway_id;
        });
        
        $total_sales = array_sum(array_column($gateway_orders, 'total_sell'));
        $total_buy = array_sum(array_column($gateway_orders, 'total_buy'));
        $total_extra = array_sum(array_column($gateway_orders, 'extra_cost'));
        $total_cost_price = array_sum(array_column($gateway_orders, 'total_cost_price'));
        $total_fee = array_sum(array_column($gateway_orders, 'gateway_fee'));
        $total_items = array_sum(array_column($gateway_orders, 'qty'));
        $total_net_profit = array_sum(array_column($gateway_orders, 'net_profit'));
        
        $profit_percentage = 0;
        if ($total_sales > 0) {
            $profit_percentage = ($total_net_profit / $total_sales) * 100;
        }
        
        $gateway_payments = array_filter($payments, function($p) use ($gateway_id) {
            return $p['gateway_id'] === $gateway_id;
        });
        
        if (!empty($start_date) && !empty($end_date)) {
            $gateway_payments = array_filter($gateway_payments, function($p) use ($start_date, $end_date) {
                return $p['date'] >= $start_date && $p['date'] <= $end_date;
            });
        }
        
        $payment_amounts = array_filter($gateway_payments, function($p) {
            return !isset($p['type']) || $p['type'] !== 'fee_adjustment';
        });
        $fee_adjustments = array_filter($gateway_payments, function($p) {
            return isset($p['type']) && $p['type'] == 'fee_adjustment';
        });
        
        $total_payments = array_sum(array_column($payment_amounts, 'amount'));
        $total_fee_adjustments = array_sum(array_column($fee_adjustments, 'amount'));
        
        $final_fee = $total_fee + $total_fee_adjustments;
        // Settlements are entered as GROSS amounts and clear the same GROSS receivable.
        // Fees affect expected net payout/profit, not the amount of receivable cleared.
        $debt = $total_sales - $total_payments;
        $amount_due = $total_sales - $final_fee;
        $adjusted_net_profit = $total_net_profit - $total_fee_adjustments;
        
        $all_items = [];
        
        foreach ($gateway_orders as $order) {
            $all_items[] = [
                'date' => $order['order_date'],
                'type' => 'sale',
                'type_label' => '✅ فروش',
                'description' => 'سفارش #' . $order['order_id'] . ' - ' . $order['product'] . ' (' . $order['qty'] . ' عدد)',
                'amount_sell' => $order['total_sell'],
                'amount_buy' => $order['total_buy'],
                'extra_cost' => $order['extra_cost'],
                'total_cost_price' => $order['total_cost_price'],
                'gateway_fee' => $order['gateway_fee'],
                'net_profit' => $order['net_profit'],
                'payment_amount' => 0,
                'sort_date' => $order['order_date'] . ' ' . $order['order_time']
            ];
        }
        
        foreach ($payment_amounts as $payment) {
            $all_items[] = [
                'date' => $payment['date'],
                'type' => 'payment',
                'type_label' => '💳 پرداختی',
                'description' => 'پرداخت به درگاه' . (!empty($payment['note']) ? ' (' . $payment['note'] . ')' : ''),
                'amount_sell' => 0,
                'amount_buy' => 0,
                'extra_cost' => 0,
                'total_cost_price' => 0,
                // Show the actual settlement fee and net bank deposit in the gateway report.
                // Older saved payments may not contain these fields, so calculate safe fallbacks.
                'gateway_fee' => isset($payment['fee_amount']) ? (float) $payment['fee_amount'] : 0,
                'net_profit' => 0,
                'payment_amount' => isset($payment['gross_amount']) ? (float) $payment['gross_amount'] : (float) $payment['amount'],
                'net_payment_amount' => isset($payment['net_amount']) ? (float) $payment['net_amount'] : max(0, (float) (isset($payment['gross_amount']) ? $payment['gross_amount'] : $payment['amount']) - (float) (isset($payment['fee_amount']) ? $payment['fee_amount'] : 0)),
                'sort_date' => $payment['date'] . ' 00:00:00'
            ];
        }
        
        foreach ($fee_adjustments as $adjustment) {
            $all_items[] = [
                'date' => $adjustment['date'],
                'type' => 'fee_adjustment',
                'type_label' => '⚖️ تعدیل کارمزد',
                'description' => 'تعدیل کارمزد' . (!empty($adjustment['note']) ? ' (' . $adjustment['note'] . ')' : ''),
                'amount_sell' => 0,
                'amount_buy' => 0,
                'extra_cost' => 0,
                'total_cost_price' => 0,
                'gateway_fee' => $adjustment['amount'],
                'net_profit' => -$adjustment['amount'],
                'payment_amount' => 0,
                'sort_date' => $adjustment['date'] . ' 00:00:00'
            ];
        }
        
        usort($all_items, function($a, $b) {
            return strcmp($a['sort_date'], $b['sort_date']);
        });
        
        if (count($gateway_orders) > 0 || count($gateway_payments) > 0) {
            $partners_share = bzc_calculate_partners_share_for_gateway($total_sales, $final_fee, $total_cost_price);
            
            $gateway_reports[$gateway_id] = [
                'id' => $gateway_id,
                'name' => $gateway_title,
                'total_sales' => $total_sales,
                'total_buy' => $total_buy,
                'total_extra' => $total_extra,
                'total_cost_price' => $total_cost_price,
                'total_fee' => $total_fee,
                'total_fee_adjustments' => $total_fee_adjustments,
                'final_fee' => $final_fee,
                'total_items' => $total_items,
                'total_payments' => $total_payments,
                'total_net_profit' => $total_net_profit,
                'adjusted_net_profit' => $adjusted_net_profit,
                'profit_percentage' => $profit_percentage,
                'amount_due' => $amount_due,
                'debt' => $debt,
                'all_items' => $all_items,
                'order_count' => count($gateway_orders),
                'payment_count' => count($payment_amounts),
                'adjustment_count' => count($fee_adjustments),
                'is_active' => isset($active_gateways[$gateway_id]),
                'partners_share' => $partners_share
            ];
        }
    }
    
    if (!empty($selected_gateway) && isset($gateway_reports[$selected_gateway])) {
        $gateway_reports = [$selected_gateway => $gateway_reports[$selected_gateway]];
    }
    
    uasort($gateway_reports, function($a, $b) {
        return $b['total_sales'] - $a['total_sales'];
    });
    ?>
    <div class="wrap bzc-wrap">
        <h1>📊 گزارش کامل درگاه‌های پرداخت</h1>
        
        <div style="background: white; padding: 20px; border-radius: 12px; margin-bottom: 25px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
            <h3>🔍 فیلتر گزارش</h3>
            <form method="get" style="display: flex; gap: 15px; align-items: center; flex-wrap: wrap;">
                <input type="hidden" name="page" value="bz-accounting-gateway-report">
                <div>
                    <label><strong>درگاه پرداخت:</strong></label>
                    <select name="gateway" style="padding: 8px; border-radius: 6px; border: 1px solid #ccc;">
                        <option value="">همه درگاه‌ها</option>
                        <?php foreach ($all_gateways as $id => $title): ?>
                            <option value="<?php echo esc_attr($id); ?>" <?php selected($selected_gateway, $id); ?>>
                                <?php echo esc_html($title); ?>
                                <?php if (!isset($active_gateways[$id])): ?>
                                    (غیرفعال)
                                <?php endif; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label><strong>از تاریخ (شمسی):</strong></label>
                    <input type="text" name="start_date" class="bzc-persian-datepicker" value="<?php echo esc_attr($start_date); ?>" placeholder="۱۴۰۴-۰۱-۰۱" autocomplete="off">
                </div>
                <div>
                    <label><strong>تا تاریخ (شمسی):</strong></label>
                    <input type="text" name="end_date" class="bzc-persian-datepicker" value="<?php echo esc_attr($end_date); ?>" placeholder="۱۴۰۴-۱۲-۲۹" autocomplete="off">
                </div>
                <button type="submit" class="button button-primary">🔍 نمایش گزارش</button>
                <a href="<?php echo admin_url('admin.php?page=bz-accounting-gateway-report'); ?>" class="button">🔄 حذف فیلترها</a>
            </form>
        </div>
        
        <?php if (!empty($gateway_reports)): ?>
            <?php foreach ($gateway_reports as $gateway_id => $report): ?>
                <div style="background: white; padding: 20px; border-radius: 12px; margin-bottom: 25px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                    <h3 style="margin-top: 0; color: #2271b1; border-bottom: 2px solid #2271b1; padding-bottom: 10px;">
                        🏦 <?php echo esc_html($report['name']); ?>
                        <?php if (!$report['is_active']): ?>
                            <span style="font-size: 14px; color: #ff9800; font-weight: normal;">(غیرفعال)</span>
                        <?php endif; ?>
                        <span style="font-size: 14px; color: #666; font-weight: normal;">
                            (<?php echo $report['order_count']; ?> سفارش - <?php echo $report['payment_count']; ?> پرداختی - <?php echo $report['adjustment_count']; ?> تعدیل)
                        </span>
                    </h3>
                    
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 15px; margin: 15px 0;">
                        <div style="background: #e8f0fe; padding: 15px; border-radius: 8px;">
                            <strong>📦 فروش کل:</strong><br>
                            <span style="font-size: 20px; color: #2c7a2c;"><?php echo number_format($report['total_sales']); ?></span> تومان
                        </div>
                        <div style="background: #fff3e0; padding: 15px; border-radius: 8px;">
                            <strong>🛒 قیمت خرید کل:</strong><br>
                            <span style="font-size: 20px; color: #e65100;"><?php echo number_format($report['total_buy']); ?></span> تومان
                        </div>
                        <div style="background: #ffccbc; padding: 15px; border-radius: 8px;">
                            <strong>💰 هزینه‌های جانبی کل:</strong><br>
                            <span style="font-size: 20px; color: #bf360c;"><?php echo number_format($report['total_extra']); ?></span> تومان
                        </div>
                        <div style="background: #d7ccc8; padding: 15px; border-radius: 8px;">
                            <strong>📦 قیمت تمام‌شده کل:</strong><br>
                            <span style="font-size: 20px; color: #4e342e;"><?php echo number_format($report['total_cost_price']); ?></span> تومان
                        </div>
                        <div style="background: #ffebee; padding: 15px; border-radius: 8px;">
                            <strong>💸 کارمزد درگاه کل:</strong><br>
                            <span style="font-size: 20px; color: #c62828;"><?php echo number_format($report['total_fee']); ?></span> تومان
                        </div>
                        <?php if ($report['total_fee_adjustments'] != 0): ?>
                            <div style="background: <?php echo $report['total_fee_adjustments'] >= 0 ? '#fff3e0' : '#ffebee'; ?>; padding: 15px; border-radius: 8px; border: 2px solid #ff9800;">
                                <strong>⚖️ تعدیل کارمزد:</strong><br>
                                <span style="font-size: 20px; font-weight: bold; color: <?php echo $report['total_fee_adjustments'] >= 0 ? '#e65100' : '#c62828'; ?>;">
                                    <?php echo ($report['total_fee_adjustments'] >= 0 ? '+' : '') . number_format($report['total_fee_adjustments']); ?>
                                </span> تومان
                                <br><small style="font-size: 11px;">کارمزد نهایی: <?php echo number_format($report['final_fee']); ?> تومان</small>
                            </div>
                        <?php endif; ?>
                        <div style="background: #e3f2fd; padding: 15px; border-radius: 8px;">
                            <strong>💰 مبلغ قابل پرداخت:</strong><br>
                            <span style="font-size: 20px; color: #1565c0;"><?php echo number_format($report['amount_due']); ?></span> تومان
                            <br><small style="font-size: 11px;">(فروش - کارمزد نهایی؛ برآورد خالص قابل تسویه)</small>
                        </div>
                        <div style="background: <?php echo $report['adjusted_net_profit'] >= 0 ? '#e8f5e9' : '#ffebee'; ?>; padding: 15px; border-radius: 8px;">
                            <strong>💰 سود خالص نهایی:</strong><br>
                            <span style="font-size: 20px; font-weight: bold; color: <?php echo $report['adjusted_net_profit'] >= 0 ? '#2e7d32' : '#c62828'; ?>;">
                                <?php echo number_format($report['adjusted_net_profit']); ?>
                            </span> تومان
                            <?php if ($report['total_fee_adjustments'] != 0): ?>
                                <br><small style="font-size: 11px;">(اصلاح شده با تعدیلات)</small>
                            <?php endif; ?>
                        </div>
                        <div style="background: #f3e5f5; padding: 15px; border-radius: 8px;">
                            <strong>📊 درصد سود:</strong><br>
                            <span style="font-size: 20px; font-weight: bold; color: #6a1b9a;">
                                <?php echo number_format($report['profit_percentage'], 2); ?>%
                            </span>
                        </div>
                        <div style="background: #e3f2fd; padding: 15px; border-radius: 8px;">
                            <strong>💳 پرداختی به ما:</strong><br>
                            <span style="font-size: 20px; color: #1565c0;"><?php echo number_format($report['total_payments']); ?></span> تومان
                        </div>
                        <div style="background: <?php echo $report['debt'] >= 0 ? '#e8f5e9' : '#ffebee'; ?>; padding: 15px; border-radius: 8px;">
                            <strong>💰 مانده طلب از درگاه:</strong><br>
                            <span style="font-size: 24px; font-weight: bold; color: <?php echo $report['debt'] >= 0 ? '#2e7d32' : '#c62828'; ?>;">
                                <?php echo number_format($report['debt']); ?>
                            </span> تومان
                        </div>
                    </div>
                    
                    <button class="button button-secondary toggle-details" data-gateway="<?php echo esc_attr($gateway_id); ?>">
                        📋 مشاهده جزئیات کامل
                    </button>
                    
                    <div id="details-<?php echo esc_attr($gateway_id); ?>" style="display: none; margin-top: 15px;">
                        <h4>📋 ریز صورت حساب‌ها (مرتب شده بر اساس تاریخ)</h4>
                        <p style="font-size: 12px; color: #666; margin-bottom: 10px;">
                            📊 درصد سود کلی: <strong><?php echo number_format($report['profit_percentage'], 2); ?>%</strong>
                            <?php if ($report['total_fee_adjustments'] != 0): ?>
                                | ⚖️ تعدیل کارمزد: <strong style="color: #ff9800;"><?php echo ($report['total_fee_adjustments'] >= 0 ? '+' : '') . number_format($report['total_fee_adjustments']); ?></strong> تومان
                            <?php endif; ?>
                        </p>
                        
                        <?php if (!empty($report['all_items'])): ?>
                            <div style="overflow-x: auto;">
                                <table class="widefat" style="direction: rtl;">
                                    <thead>
                                        <tr>
                                            <th>تاریخ</th>
                                            <th>نوع</th>
                                            <th>شماره/توضیحات</th>
                                            <th>مبلغ فروش (تومان)</th>
                                            <th>قیمت خرید (تومان)</th>
                                            <th>هزینه جانبی (تومان)</th>
                                            <th>قیمت تمام‌شده (تومان)</th>
                                            <th>کارمزد درگاه (تومان)</th>
                                            <th>سود خالص / خالص واریزی (تومان)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        foreach ($report['all_items'] as $item):
                                            if ($item['type'] == 'sale') {
                                                $profit_color = $item['net_profit'] >= 0 ? '#2c7a2c' : '#dc3232';
                                                $bg_color = '#f0f8ff';
                                            } elseif ($item['type'] == 'fee_adjustment') {
                                                $profit_color = $item['gateway_fee'] >= 0 ? '#ff9800' : '#dc3232';
                                                $bg_color = '#fff3e0';
                                            } else {
                                                $profit_color = '#999';
                                                $bg_color = '#f5f5f5';
                                            }
                                        ?>
                                            <tr style="background: <?php echo $bg_color; ?>;">
                                                <td><?php echo esc_html($item['date']); ?></td>
                                                <td><?php echo $item['type_label']; ?></td>
                                                <td><?php echo $item['description']; ?></td>
                                                <td style="direction: ltr; text-align: left; <?php echo $item['type'] == 'sale' ? 'color: #2c7a2c;' : 'color: #999;'; ?>">
                                                    <?php echo $item['type'] == 'sale' ? number_format($item['amount_sell']) : '-'; ?>
                                                </td>
                                                <td style="direction: ltr; text-align: left; <?php echo $item['type'] == 'sale' ? 'color: #e65100;' : 'color: #999;'; ?>">
                                                    <?php echo $item['type'] == 'sale' ? number_format($item['amount_buy']) : '-'; ?>
                                                </td>
                                                <td style="direction: ltr; text-align: left; <?php echo $item['type'] == 'sale' ? 'color: #bf360c;' : 'color: #999;'; ?>">
                                                    <?php echo $item['type'] == 'sale' ? number_format($item['extra_cost']) : '-'; ?>
                                                </td>
                                                <td style="direction: ltr; text-align: left; <?php echo $item['type'] == 'sale' ? 'color: #4e342e; font-weight: bold;' : 'color: #999;'; ?>">
                                                    <?php echo $item['type'] == 'sale' ? number_format($item['total_cost_price']) : '-'; ?>
                                                </td>
                                                <td style="direction: ltr; text-align: left; <?php echo $item['type'] == 'sale' ? 'color: #c62828;' : ($item['type'] == 'fee_adjustment' ? 'color: #ff9800; font-weight: bold;' : 'color: #999;'); ?>">
                                                    <?php 
                                                    if ($item['type'] == 'sale') {
                                                        echo number_format($item['gateway_fee']);
                                                    } elseif ($item['type'] == 'fee_adjustment') {
                                                        echo ($item['gateway_fee'] >= 0 ? '+' : '') . number_format($item['gateway_fee']);
                                                    } elseif ($item['type'] == 'payment') {
                                                        echo number_format($item['gateway_fee']);
                                                    } else {
                                                        echo '-';
                                                    }
                                                    ?>
                                                </td>
                                                <td style="direction: ltr; text-align: left; font-weight: bold; color: <?php echo $profit_color; ?>;">
                                                    <?php 
                                                    if ($item['type'] == 'sale') {
                                                        echo number_format($item['net_profit']);
                                                    } elseif ($item['type'] == 'fee_adjustment') {
                                                        echo ($item['net_profit'] >= 0 ? '+' : '') . number_format($item['net_profit']);
                                                    } else {
                                                        $net_payment_display = isset($item['net_payment_amount']) ? $item['net_payment_amount'] : $item['payment_amount'];
                                                        echo '<span style="color: #1565c0; font-weight: bold;">' . number_format($net_payment_display) . '</span>';
                                                    }
                                                    ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                    <?php 
                                    $total_sales_sum = $report['total_sales'];
                                    $total_buy_sum = $report['total_buy'];
                                    $total_extra_sum = $report['total_extra'];
                                    $total_cost_price_sum = $report['total_cost_price'];
                                    $total_fee_sum = $report['total_fee'];
                                    $total_fee_adj_sum = $report['total_fee_adjustments'];
                                    $final_fee_sum = $report['final_fee'];
                                    $total_net_sum = $report['total_net_profit'];
                                    $adjusted_net_sum = $report['adjusted_net_profit'];
                                    $total_payments_sum = $report['total_payments'];
                                    $amount_due_sum = $report['amount_due'];
                                    $debt_sum = $report['debt'];
                                    ?>
                                    <tfoot style="background: #f5f5f5; font-weight: bold; border-top: 2px solid #2271b1;">
                                        <tr>
                                            <td colspan="3" style="text-align: left;">جمع کل:</td>
                                            <td style="direction: ltr; text-align: left; color: #2c7a2c;"><?php echo number_format($total_sales_sum); ?></td>
                                            <td style="direction: ltr; text-align: left; color: #e65100;"><?php echo number_format($total_buy_sum); ?></td>
                                            <td style="direction: ltr; text-align: left; color: #bf360c;"><?php echo number_format($total_extra_sum); ?></td>
                                            <td style="direction: ltr; text-align: left; color: #4e342e; font-weight: bold;"><?php echo number_format($total_cost_price_sum); ?></td>
                                            <td style="direction: ltr; text-align: left; color: #c62828;"><?php echo number_format($total_fee_sum); ?></td>
                                            <td style="direction: ltr; text-align: left; color: <?php echo $total_net_sum >= 0 ? '#2e7d32' : '#c62828'; ?>;">
                                                <?php echo number_format($total_net_sum); ?>
                                            </td>
                                        </tr>
                                        <?php if ($total_fee_adj_sum != 0): ?>
                                            <tr style="background: #fff3e0;">
                                                <td colspan="3" style="text-align: left; color: #ff9800;">⚖️ تعدیل کارمزد:</td>
                                                <td colspan="6" style="direction: ltr; text-align: left; color: #ff9800; font-weight: bold;">
                                                    <?php echo ($total_fee_adj_sum >= 0 ? '+' : '') . number_format($total_fee_adj_sum); ?>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                        <tr>
                                            <td colspan="3" style="text-align: left; font-size: 14px;">💰 کارمزد نهایی (با تعدیل):</td>
                                            <td colspan="6" style="direction: ltr; text-align: left; font-size: 14px; color: #c62828; font-weight: bold;">
                                                <?php echo number_format($final_fee_sum); ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="text-align: left; font-size: 14px;">💰 سود خالص نهایی (با تعدیل):</td>
                                            <td colspan="6" style="direction: ltr; text-align: left; font-size: 14px; font-weight: bold; color: <?php echo $adjusted_net_sum >= 0 ? '#2e7d32' : '#c62828'; ?>;">
                                                <?php echo number_format($adjusted_net_sum); ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="text-align: left; font-size: 14px;">💰 مبلغ قابل پرداخت (فروش - کارمزد نهایی؛ برآورد خالص قابل تسویه):</td>
                                            <td colspan="6" style="direction: ltr; text-align: left; font-size: 14px; color: #1565c0;">
                                                <?php echo number_format($amount_due_sum); ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="text-align: left; font-size: 14px;">💳 مجموع پرداختی‌ها:</td>
                                            <td colspan="6" style="direction: ltr; text-align: left; font-size: 14px; color: #1565c0;">
                                                <?php echo number_format($total_payments_sum); ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" style="text-align: left; font-size: 16px; font-weight: bold;">💰 بدهی نهایی درگاه:</td>
                                            <td colspan="6" style="direction: ltr; text-align: left; font-size: 16px; font-weight: bold; color: <?php echo $debt_sum >= 0 ? '#2e7d32' : '#c62828'; ?>;">
                                                <?php echo number_format($debt_sum); ?>
                                            </td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        <?php else: ?>
                            <p style="color: #666; padding: 15px;">هیچ آیتمی برای نمایش وجود ندارد.</p>
                        <?php endif; ?>
                        
                        <!-- ===== بخش سهم شرکا برای این درگاه ===== -->
                        <?php if (!empty($report['partners_share'])): ?>
                            <div style="margin-top: 20px; border-top: 2px dashed #ccc; padding-top: 15px;">
                                <h4 style="color: #2271b1;">👥 سهم شرکا از این درگاه (بر اساس مبلغ دریافتی از درگاه)</h4>
                                <div style="background: #e8f0fe; padding: 10px; border-radius: 8px; margin-bottom: 15px;">
                                    📌 سود ناخالص کل در این درگاه: <?php echo number_format($report['total_sales'] - $report['total_cost_price']); ?> تومان 
                                    | 💳 کل کارمزد نهایی: <?php echo number_format($report['final_fee']); ?> تومان 
                                    | 💰 سود خالص نهایی: <?php echo number_format($report['adjusted_net_profit']); ?> تومان
                                    <?php if ($report['total_fee_adjustments'] != 0): ?>
                                        <br>⚖️ تعدیل کارمزد اعمال شده: <?php echo ($report['total_fee_adjustments'] >= 0 ? '+' : '') . number_format($report['total_fee_adjustments']); ?> تومان
                                    <?php endif; ?>
                                </div>
                                
                                <?php foreach ($report['partners_share'] as $p): ?>
                                    <?php 
                                    $feeText = isset($p['fee_percent']) && $p['fee_percent'] !== null ? "{$p['fee_percent']}%" : 'مساوی';
                                    $isRemaining = isset($p['is_remaining']) && $p['is_remaining'] === true;
                                    $bgColor = $isRemaining ? '#fff8e1' : '#f0f8ff';
                                    $borderColor = $isRemaining ? '#ff9800' : '#2271b1';
                                    ?>
                                    <div style="background: <?php echo $bgColor; ?>; padding: 15px; border-radius: 8px; margin-bottom: 15px; border-right: 4px solid <?php echo $borderColor; ?>;">
                                        <h4 style="margin-top: 0; color: <?php echo $borderColor; ?>;"><?php echo esc_html($p['name']); ?></h4>
                                        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px;">
                                            <div>📊 سهم از سود ناخالص (<?php echo $p['percent']; ?>%): <?php echo number_format($p['gross_share']); ?> تومان</div>
                                            <div>💳 سهم از کارمزد نهایی (<?php echo $feeText; ?>): <?php echo number_format($p['fee_share']); ?> تومان</div>
                                            <div>💰 <strong>سهم نهایی <?php echo esc_html($p['name']); ?>:</strong> <?php echo number_format($p['final_share']); ?> تومان</div>
                                        </div>
                                        <div style="margin-top: 8px; font-size: 11px; color: #666; background: rgba(0,0,0,0.03); padding: 5px; border-radius: 4px;">
                                            محاسبه: (<?php echo number_format($report['total_sales'] - $report['total_cost_price']); ?> × <?php echo $p['percent']; ?>%) - (<?php echo number_format($report['final_fee']); ?> × <?php echo $feeText; ?>) = <?php echo number_format($p['final_share']); ?> تومان
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div style="background: white; padding: 30px; border-radius: 12px; text-align: center; color: #666;">
                هیچ داده‌ایی برای نمایش وجود ندارد. لطفاً بازه زمانی را تغییر دهید یا مطمئن شوید که سفارش‌هایی در سیستم وجود دارند.
            </div>
        <?php endif; ?>
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        $('.toggle-details').on('click', function() {
            var gatewayId = $(this).data('gateway');
            var detailsDiv = $('#details-' + gatewayId);
            if (detailsDiv.is(':visible')) {
                detailsDiv.slideUp();
                $(this).text('📋 مشاهده جزئیات کامل');
            } else {
                detailsDiv.slideDown();
                $(this).text('📋 مخفی کردن جزئیات');
            }
        });
    });
    </script>
    <?php
}

// ==================== توابع کمکی ====================

function bzc_get_all_payment_gateways() {
    $all_gateways = [];
    
    if (class_exists('WC_Payment_Gateways')) {
        $gateways = WC_Payment_Gateways::instance()->get_available_payment_gateways();
        foreach ($gateways as $id => $gateway) {
            $all_gateways[$id] = [
                'id' => $id,
                'title' => $gateway->get_title(),
                'is_active' => true
            ];
        }
    }
    
    $inactive_gateways = bzc_get_inactive_gateways_from_orders();
    foreach ($inactive_gateways as $gateway_id) {
        if (!isset($all_gateways[$gateway_id])) {
            $all_gateways[$gateway_id] = [
                'id' => $gateway_id,
                'title' => bzc_get_gateway_display_name($gateway_id),
                'is_active' => false
            ];
        }
    }
    
    $payments = get_option('bzc_gateway_payments', []);
    foreach ($payments as $payment) {
        $gateway_id = $payment['gateway_id'];
        if (!isset($all_gateways[$gateway_id])) {
            $all_gateways[$gateway_id] = [
                'id' => $gateway_id,
                'title' => bzc_get_gateway_display_name($gateway_id),
                'is_active' => false
            ];
        }
    }
    
    usort($all_gateways, function($a, $b) {
        return strcmp($a['title'], $b['title']);
    });
    
    return $all_gateways;
}

function bzc_get_inactive_gateways_from_orders() {
    $gateways = [];
    
    if (!class_exists('WooCommerce')) {
        return $gateways;
    }
    
    $args = [
        'limit' => -1,
        'return' => 'objects',
        'type' => 'shop_order',
        'status' => ['wc-processing', 'wc-sent', 'wc-completed']
    ];
    
    $orders = wc_get_orders($args);
    
    foreach ($orders as $order) {
        if (!method_exists($order, 'get_payment_method')) {
            continue;
        }
        
        $gateway_id = $order->get_payment_method();
        if (!empty($gateway_id) && !in_array($gateway_id, $gateways)) {
            $gateways[] = $gateway_id;
        }
    }
    
    return $gateways;
}

function bzc_get_active_payment_gateways() {
    $all_gateways = bzc_get_all_payment_gateways();
    $active = [];
    foreach ($all_gateways as $gateway) {
        if ($gateway['is_active']) {
            $active[$gateway['id']] = $gateway['title'];
        }
    }
    return $active;
}

function bzc_get_orders_by_gateway($start_date = '', $end_date = '', $gateways_fee = []) {
    if (!class_exists('WooCommerce')) {
        return [];
    }
    
    $valid_statuses = ['wc-processing', 'wc-sent', 'wc-completed'];
    
    $args = [
        'limit' => -1,
        'return' => 'objects',
        'status' => $valid_statuses,
        'type' => 'shop_order'
    ];
    
    if (!empty($start_date) && !empty($end_date)) {
        $args['date_created'] = $start_date . '...' . $end_date;
    }
    
    $orders = wc_get_orders($args);
    $result = [];
    
    if (empty($orders)) {
        return $result;
    }
    
    foreach ($orders as $order) {
        if (!method_exists($order, 'get_payment_method')) {
            continue;
        }
        
        $gateway_id = $order->get_payment_method();
        if (empty($gateway_id)) {
            $gateway_id = 'manual';
        }
        
        $order_date = $order->get_date_created();
        $order_date_gregorian = $order_date ? $order_date->date('Y-m-d') : '';
        $order_date_formatted = $order_date_gregorian ? bzc_convert_gregorian_to_persian_simple($order_date_gregorian) : '';
        $order_time_formatted = $order_date ? $order_date->date_i18n('H:i:s') : '';
        
        $order_total = $order->get_total();
        $fee_config = $gateways_fee[$gateway_id] ?? null;
        $order_gateway_fee = bzc_calculate_gateway_fee($order_total, $fee_config, $gateway_id, $order_date_gregorian);
        
        foreach ($order->get_items() as $item) {
            $qty = $item->get_quantity();
            $price_sell_total = floatval($item->get_total());
            
            if ($price_sell_total == 0) {
                $product = $item->get_product();
                if ($product) {
                    $price_sell_total = floatval($product->get_price()) * $qty;
                }
            }
            
            $product_name = $item->get_name();
            
            $meta_key_buy = '_bzc_buy_price_' . sanitize_title($product_name);
            $saved_buy_price_total = floatval(get_post_meta($order->get_id(), $meta_key_buy, true));
            
            $meta_key_extra = '_bzc_extra_cost_' . sanitize_title($product_name);
            $extra_cost_total = floatval(get_post_meta($order->get_id(), $meta_key_extra, true));
            
            $total_cost_price = $saved_buy_price_total + $extra_cost_total;
            
            if ($saved_buy_price_total == 0 && $extra_cost_total == 0) {
                if ($price_sell_total > 0) {
                    $total_cost_price = 0;
                } else {
                    $product = $item->get_product();
                    if ($product) {
                        $product_price = floatval($product->get_price());
                        $price_sell_total = $product_price * $qty;
                        $total_cost_price = 0;
                    }
                }
            }
            
            $item_fee_share = 0;
            if ($order_total > 0 && $order_gateway_fee > 0) {
                $item_fee_share = ($price_sell_total / $order_total) * $order_gateway_fee;
            }
            
            $gross_profit = $price_sell_total - $saved_buy_price_total;
            $net_profit = $gross_profit - $item_fee_share - $extra_cost_total;
            
            $result[] = [
                'order_id' => $order->get_id(),
                'order_date' => $order_date_formatted,
                'order_time' => $order_time_formatted,
                'product' => $product_name,
                'qty' => $qty,
                'total_sell' => $price_sell_total,
                'total_buy' => $saved_buy_price_total,
                'extra_cost' => $extra_cost_total,
                'total_cost_price' => $total_cost_price,
                'gateway_fee' => $item_fee_share,
                'net_profit' => $net_profit,
                'gateway' => $gateway_id
            ];
        }
    }
    
    return $result;
}

function bzc_persian_to_gregorian($persian_date) {
    if (empty($persian_date)) return '';
    
    $persian_date = trim($persian_date);
    $persian_date = str_replace('/', '-', $persian_date);
    
    $parts = explode('-', $persian_date);
    if (count($parts) !== 3) return '';
    
    // حذف کاراکترهای غیر عددی
    $jy = intval(preg_replace('/[^0-9]/', '', $parts[0]));
    $jm = intval(preg_replace('/[^0-9]/', '', $parts[1]));
    $jd = intval(preg_replace('/[^0-9]/', '', $parts[2]));
    
    // اعتبارسنجی
    if ($jy < 1300 || $jy > 1500 || $jm < 1 || $jm > 12 || $jd < 1 || $jd > 31) {
        return '';
    }
    
    // روزهای ماه‌های شمسی
    $j_days_in_month = array(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29);
    
    // محاسبه روزهای گذشته از ابتدای سال شمسی (از 1 فروردین)
    $jy_days = $jd;
    for ($i = 0; $i < $jm - 1; $i++) {
        $jy_days += $j_days_in_month[$i];
    }
    
    // محاسبه سال میلادی
    $gy = $jy + 621;
    
    // تعیین موقعیت در سال میلادی
    if ($jy_days > 286) {
        $gy += 1;
        $jy_days -= 286;
    } else {
        $jy_days += 79;
    }
    
    // روزهای ماه‌های میلادی
    $g_days_in_month = array(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
    
    // محاسبه کبیسه بودن سال میلادی
    $is_leap = ($gy % 4 == 0 && ($gy % 100 != 0 || $gy % 400 == 0));
    if ($is_leap) {
        $g_days_in_month[1] = 29;
    }
    
    // پیدا کردن ماه و روز میلادی
    $gm = 1;
    $gd = 1;
    for ($i = 0; $i < 12; $i++) {
        if ($jy_days <= $g_days_in_month[$i]) {
            $gm = $i + 1;
            $gd = $jy_days;
            break;
        }
        $jy_days -= $g_days_in_month[$i];
    }
    
    return sprintf('%04d-%02d-%02d', $gy, $gm, $gd);
}

function bzc_jalali_to_gregorian($jy, $jm, $jd) {
    $jy += 1595;
    $days = -355668 + (365 * $jy) + (floor($jy / 33) * 8) + (floor((($jy % 33) + 3) / 4)) + $jd;
    if ($jm < 7) {
        $days += ($jm - 1) * 31;
    } else {
        $days += (($jm - 7) * 30) + 186;
    }
    $gy = 400 * floor($days / 146097);
    $days %= 146097;
    if ($days > 36524) {
        $gy += 100 * floor(--$days / 36524);
        $days %= 36524;
        if ($days >= 365) $days++;
    }
    $gy += 4 * floor($days / 1461);
    $days %= 1461;
    if ($days > 365) {
        $gy += floor(($days - 1) / 365);
        $days = ($days - 1) % 365;
    }
    $gd = $days + 1;
    $sal_a = [0, 31, (($gy % 4 == 0 && $gy % 100 != 0) || ($gy % 400 == 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    for ($gm = 1; $gm <= 12; $gm++) {
        if ($gd <= $sal_a[$gm]) break;
        $gd -= $sal_a[$gm];
    }
    return [$gy, $gm, $gd];
}

/**
 * Return the fee configuration that was effective on a given Gregorian date.
 * Historical rates are stored separately so changing the current rate never
 * rewrites the rate used by older orders.
 */
function bzc_get_gateway_fee_config_for_date($gateway_id, $date = '', $fallback = null) {
    $history = get_option('bzc_gateway_fee_history', []);
    if (!is_array($history) || empty($gateway_id) || empty($history[$gateway_id])) {
        return $fallback;
    }

    $date = substr((string) $date, 0, 10);
    if (!$date || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
        return $fallback;
    }

    $versions = $history[$gateway_id];
    usort($versions, function($a, $b) {
        return strcmp($a['start_date'] ?? '', $b['start_date'] ?? '');
    });

    $selected = null;
    foreach ($versions as $version) {
        if (empty($version['start_date']) || $version['start_date'] <= $date) {
            $selected = $version['config'] ?? null;
        } else {
            break;
        }
    }

    return is_array($selected) ? $selected : $fallback;
}

function bzc_normalize_gateway_fee_history() {
    $history = get_option('bzc_gateway_fee_history', []);
    return is_array($history) ? $history : [];
}

function bzc_add_gateway_fee_history_version($gateway_id, $start_date, $config) {
    $gateway_id = sanitize_text_field($gateway_id);
    $start_date = substr(sanitize_text_field($start_date), 0, 10);
    if (!$gateway_id || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $start_date) || !is_array($config)) {
        return false;
    }

    $history = bzc_normalize_gateway_fee_history();
    if (!isset($history[$gateway_id]) || !is_array($history[$gateway_id])) {
        $history[$gateway_id] = [];
    }

    $updated = false;
    foreach ($history[$gateway_id] as &$version) {
        if (($version['start_date'] ?? '') === $start_date) {
            $version['config'] = $config;
            $version['updated_at'] = current_time('mysql');
            $updated = true;
            break;
        }
    }
    unset($version);

    if (!$updated) {
        $history[$gateway_id][] = [
            'start_date' => $start_date,
            'config' => $config,
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql'),
        ];
    }

    usort($history[$gateway_id], function($a, $b) {
        return strcmp($a['start_date'] ?? '', $b['start_date'] ?? '');
    });
    update_option('bzc_gateway_fee_history', $history, false);
    return true;
}

function bzc_get_gateway_fee_history_display($gateway_id) {
    $history = bzc_normalize_gateway_fee_history();
    $versions = isset($history[$gateway_id]) && is_array($history[$gateway_id]) ? $history[$gateway_id] : [];
    usort($versions, function($a, $b) {
        return strcmp($a['start_date'] ?? '', $b['start_date'] ?? '');
    });
    return $versions;
}

function bzc_calculate_gateway_fee($amount, $config, $gateway_id = '', $date = '') {
    if ($gateway_id && $date) {
        $config = bzc_get_gateway_fee_config_for_date($gateway_id, $date, $config);
    }
    if (!$config) return 0;
    if ($config['type'] == 'fixed') return floatval($config['value']);
    if ($config['type'] == 'percent') return $amount * (floatval($config['value']) / 100);
    if ($config['type'] == 'equation' && isset($config['ranges'])) {
        foreach ($config['ranges'] as $range) {
            $min = floatval($range['min'] ?? 0);
            $max = (isset($range['max']) && $range['max'] !== '' && $range['max'] !== '0') ? floatval($range['max']) : PHP_FLOAT_MAX;
            if ($amount >= $min && $amount <= $max) {
                $value = floatval($range['value']);
                if ($range['value_type'] == 'percent') return $amount * ($value / 100);
                else return $value;
            }
        }
    }
    return 0;
}

function bzc_get_gateway_display_name($gateway_id) {
    $gateways = [
        'cod' => 'پرداخت در محل',
        'zarinpal' => 'زرین پال',
        'payir' => 'پی آیر',
        'idpay' => 'آیدی پی',
        'nextpay' => 'نکست پی',
        'saman' => 'سامان',
        'mellat' => 'ملت',
        'manual' => '📝 ثبت دستی',
        'WC_Gateway_TorobPay' => 'ترب پی',
        'WC_Domino_Zibal_Gateway' => 'زیبال',
        'wc_zibal' => 'زیبال',
        'WCDigiPay' => 'دیجی پی',
        'bank_transfer' => 'انتقال بانکی',
        'check_payment' => 'پرداخت با چک',
        'cash_on_delivery' => 'پرداخت در محل',
        'paypal' => 'پی پال',
        'stripe' => 'استرایپ',
        'bacs' => 'انتقال بانکی (BACS)',
        'cheque' => 'پرداخت با چک',
        'paystack' => 'پی استک',
        'razorpay' => 'ریزر پی',
        'instamojo' => 'اینستا موجو',
        'phonepe' => 'فون پی',
        'paytm' => 'پی تی ام',
        'gpay' => 'جی پی',
        'applepay' => 'اپل پی'
    ];
    
    if (!isset($gateways[$gateway_id])) {
        $name = str_replace(['_', '-'], ' ', $gateway_id);
        $name = str_replace(['wc', 'gateway'], '', $name);
        $name = ucwords($name);
        return trim($name);
    }
    
    return $gateways[$gateway_id];
}

// ==================== AJAX برای دریافت داده‌های سفارش‌ها ====================
add_action('wp_ajax_bzc_get_orders_data', 'bzc_ajax_get_orders_data');
function bzc_ajax_get_orders_data() {
    check_ajax_referer('bzc_nonce', 'nonce');
    
    $start_date_persian = sanitize_text_field($_POST['start_date']);
    $end_date_persian = sanitize_text_field($_POST['end_date']);
    $search = sanitize_text_field($_POST['search']);
    
    $start_date = bzc_persian_to_gregorian($start_date_persian);
    $end_date = bzc_persian_to_gregorian($end_date_persian);
    
    if (empty($start_date) || empty($end_date)) {
        wp_send_json_error('تاریخ وارد شده نامعتبر است');
        return;
    }
    
    $valid_statuses = ['wc-processing', 'wc-sent'];
    
    $args = [
        'limit' => -1,
        'return' => 'objects',
        'date_created' => $start_date . '...' . $end_date,
        'status' => $valid_statuses,
        'type' => 'shop_order'
    ];
    
    $orders = wc_get_orders($args);
    
    if (empty($orders)) {
        wp_send_json([
            'orders' => [],
            'summary' => [
                'total_sales' => 0,
                'total_items' => 0,
                'total_cost' => 0,
                'total_gross_profit' => 0,
                'total_gateway_fee' => 0,
                'total_net_profit' => 0
            ],
            'gateway_summary' => [],
            'partners' => []
        ]);
        return;
    }
    
    $partners = get_option('bzc_partners', []);
    $gateways_fee = get_option('bzc_gateways_fee', []);
    
    $total_sales = 0;
    $total_items = 0;
    $total_cost = 0;
    $total_gross_profit = 0;
    $total_gateway_fee = 0;
    $total_net_profit = 0;
    $orders_data = [];
    $gateway_summary = [];
    
    foreach ($orders as $order) {
        if (!method_exists($order, 'get_payment_method')) {
            continue;
        }
        
        $order_status = 'wc-' . $order->get_status();
        if (!in_array($order_status, $valid_statuses)) continue;
        
        if (!empty($search)) {
            $match = false;
            if (strpos(strval($order->get_id()), $search) !== false) $match = true;
            foreach ($order->get_items() as $item) {
                if (strpos($item->get_name(), $search) !== false) $match = true;
            }
            if (!$match) continue;
        }
        
        $order_total = $order->get_total();
        $gateway_id = $order->get_payment_method();
        
        $order_date = $order->get_date_created();
        $order_date_gregorian = $order_date ? $order_date->date('Y-m-d') : '';
        $order_date_formatted = $order_date_gregorian ? bzc_convert_gregorian_to_persian_simple($order_date_gregorian) : '';
        if ($order_date_formatted && $order_date) {
            $order_date_formatted .= ' ' . $order_date->date('H:i');
        }
        
        if (empty($gateway_id)) {
            $gateway_id = 'manual';
        }
        
        if (!isset($gateway_summary[$gateway_id])) {
            $gateway_summary[$gateway_id] = [
                'name' => $gateway_id,
                'total_sales' => 0,
                'total_fee' => 0,
                'total_net_profit' => 0,
                'order_count' => 0,
                'items_count' => 0
            ];
        }
        
        $fee_config = $gateways_fee[$gateway_id] ?? null;
        $order_gateway_fee = bzc_calculate_gateway_fee($order_total, $fee_config, $gateway_id, $order_date_gregorian);
        
        if ($gateway_id == 'manual' && $order_gateway_fee == 0 && $fee_config === null) {
            $order_gateway_fee = 0;
        }
        
        $order_total_sales = 0;
        $order_total_cost = 0;
        $order_gross_profit = 0;
        $order_gateway_fee_total = 0;
        $order_net_profit_total = 0;
        
        foreach ($order->get_items() as $item) {
            $qty = $item->get_quantity();
            $price_sell_total = floatval($item->get_total());
            
            if ($price_sell_total == 0) {
                $product = $item->get_product();
                if ($product) {
                    $price_sell_total = floatval($product->get_price()) * $qty;
                }
            }
            
            $unit_sell_price = $price_sell_total / $qty;
            $product_name = $item->get_name();
            
            $meta_key_buy = '_bzc_buy_price_' . sanitize_title($product_name);
            $saved_buy_price_total = floatval(get_post_meta($order->get_id(), $meta_key_buy, true));
            
            $meta_key_extra = '_bzc_extra_cost_' . sanitize_title($product_name);
            $extra_cost_total = floatval(get_post_meta($order->get_id(), $meta_key_extra, true));
            
            $total_cost_price = $saved_buy_price_total + $extra_cost_total;
            
            if ($saved_buy_price_total == 0 && $extra_cost_total == 0) {
                if ($price_sell_total > 0) {
                    $total_cost_price = 0;
                } else {
                    $product = $item->get_product();
                    if ($product) {
                        $product_price = floatval($product->get_price());
                        $price_sell_total = $product_price * $qty;
                        $unit_sell_price = $product_price;
                        $total_cost_price = 0;
                    }
                }
            }
            
            // قیمت خرید فی باید فقط از قیمت خرید ثبت‌شده محاسبه شود؛ هزینه جانبی جداست.
            $unit_buy_price = $qty > 0 ? $saved_buy_price_total / $qty : 0;
            
            $item_fee_share = 0;
            if ($order_total > 0 && $order_gateway_fee > 0) {
                $item_fee_share = ($price_sell_total / $order_total) * $order_gateway_fee;
            }
            
            $gross_profit = $price_sell_total - $saved_buy_price_total;
            $net_profit = $gross_profit - $item_fee_share - $extra_cost_total;
            
            $profit_percent = 0;
            if ($price_sell_total > 0) {
                $profit_percent = ($net_profit / $price_sell_total) * 100;
            }
            
            $orders_data[] = [
                'order_id' => $order->get_id(),
                'order_date' => $order_date_formatted,
                'product' => $product_name,
                'qty' => $qty,
                'unit_sell_price' => round($unit_sell_price),
                'total_sell' => round($price_sell_total),
                'unit_buy_price' => round($unit_buy_price),
                'total_buy' => round($saved_buy_price_total),
                'extra_cost' => round($extra_cost_total),
                'total_cost_price' => round($total_cost_price),
                'gateway' => ($gateway_id == 'manual') ? 'ثبت دستی' : $gateway_id,
                'fee_share' => round($item_fee_share),
                'gross_profit' => round($gross_profit),
                'net_profit' => round($net_profit),
                'status' => $order_status,
                'profit_percent' => round($profit_percent, 2)
            ];
            
            $order_total_sales += $price_sell_total;
            $order_total_cost += $total_cost_price;
            $order_gross_profit += $gross_profit;
            $order_gateway_fee_total += $item_fee_share;
            $order_net_profit_total += $net_profit;
            
            $total_sales += $price_sell_total;
            $total_items += $qty;
            $total_cost += $total_cost_price;
            $total_gross_profit += $gross_profit;
            $total_gateway_fee += $item_fee_share;
            $total_net_profit += $net_profit;
        }
        
        $gateway_summary[$gateway_id]['total_sales'] += $order_total_sales;
        $gateway_summary[$gateway_id]['total_fee'] += $order_gateway_fee_total;
        $gateway_summary[$gateway_id]['total_net_profit'] += $order_net_profit_total;
        $gateway_summary[$gateway_id]['order_count'] += 1;
        $gateway_summary[$gateway_id]['items_count'] += $order->get_item_count();
    }
    
    set_transient('bzc_last_orders_data', $orders_data, HOUR_IN_SECONDS);
    
    $gateway_summary_output = [];
    foreach ($gateway_summary as $gateway_id => $data) {
        $gateway_summary_output[] = [
            'gateway_id' => $gateway_id,
            'gateway_name' => bzc_get_gateway_display_name($gateway_id),
            'total_sales' => round($data['total_sales']),
            'total_fee' => round($data['total_fee']),
            'net_sales' => round($data['total_sales'] - $data['total_fee']),
            'total_net_profit' => round($data['total_net_profit']),
            'order_count' => $data['order_count'],
            'items_count' => $data['items_count']
        ];
    }
    
    usort($gateway_summary_output, function($a, $b) {
        return $b['total_sales'] - $a['total_sales'];
    });
    
    $partners_share_details = [];
    $total_partner_percent = array_sum(array_column($partners, 'percent'));
    $remaining_percent = max(0, 100 - $total_partner_percent);
    
    foreach ($partners as $partner) {
        $partner_gross_share = $total_gross_profit * ($partner['percent'] / 100);
        
        $partner_fee_percent = isset($partner['fee_percent']) ? $partner['fee_percent'] : null;
        if ($partner_fee_percent !== null) {
            $partner_fee_share = $total_gateway_fee * ($partner_fee_percent / 100);
        } else {
            $partners_without_fee = array_filter($partners, function($p) { return !isset($p['fee_percent']) || $p['fee_percent'] === null; });
            $equal_count = count($partners_without_fee);
            $partner_fee_share = $equal_count > 0 ? $total_gateway_fee / $equal_count : 0;
        }
        
        $partner_final_share = $partner_gross_share - $partner_fee_share;
        
        $partners_share_details[] = [
            'name' => $partner['name'],
            'gross_share' => round($partner_gross_share),
            'fee_share' => round($partner_fee_share),
            'final_share' => round($partner_final_share),
            'percent' => $partner['percent'],
            'fee_percent' => $partner_fee_percent
        ];
    }
    
    if ($remaining_percent > 0) {
        $remaining_gross = $total_gross_profit * ($remaining_percent / 100);
        $remaining_fee = $total_gateway_fee * ($remaining_percent / 100);
        $partners_share_details[] = [
            'name' => 'سود انباشته (حساب اصلی)',
            'gross_share' => round($remaining_gross),
            'fee_share' => round($remaining_fee),
            'final_share' => round($remaining_gross - $remaining_fee),
            'percent' => $remaining_percent,
            'fee_percent' => $remaining_percent,
            'is_remaining' => true
        ];
    }
    
    wp_send_json([
        'orders' => $orders_data,
        'summary' => [
            'total_sales' => round($total_sales),
            'total_items' => $total_items,
            'total_cost' => round($total_cost),
            'total_gross_profit' => round($total_gross_profit),
            'total_gateway_fee' => round($total_gateway_fee),
            'total_net_profit' => round($total_net_profit)
        ],
        'gateway_summary' => $gateway_summary_output,
        'partners' => $partners_share_details
    ]);
}

// ==================== AJAX برای ذخیره قیمت خرید و هزینه‌های جانبی ====================

add_action('wp_ajax_bzc_save_buy_price', 'bzc_ajax_save_buy_price');
function bzc_ajax_save_buy_price() {
    check_ajax_referer('bzc_nonce', 'nonce');
    $order_id = intval($_POST['order_id']);
    $product_name = sanitize_text_field($_POST['product_name']);
    $buy_price = floatval($_POST['buy_price']);
    $extra_cost = floatval($_POST['extra_cost'] ?? 0);
    
    update_post_meta($order_id, '_bzc_buy_price_' . sanitize_title($product_name), $buy_price);
    update_post_meta($order_id, '_bzc_extra_cost_' . sanitize_title($product_name), $extra_cost);
    
    wp_send_json_success(['message' => 'قیمت با موفقیت ذخیره شد']);
}

add_action('wp_ajax_bzc_save_all_buy_prices', 'bzc_ajax_save_all_buy_prices');
function bzc_ajax_save_all_buy_prices() {
    check_ajax_referer('bzc_nonce', 'nonce');
    $prices = $_POST['prices'];
    $saved_count = 0;
    foreach ($prices as $price_data) {
        update_post_meta(intval($price_data['order_id']), '_bzc_buy_price_' . sanitize_title($price_data['product_name']), floatval($price_data['buy_price']));
        update_post_meta(intval($price_data['order_id']), '_bzc_extra_cost_' . sanitize_title($price_data['product_name']), floatval($price_data['extra_cost'] ?? 0));
        $saved_count++;
    }
    wp_send_json_success(['message' => $saved_count . ' قیمت با موفقیت ذخیره شد']);
}

// ==================== بخش جدید: هشدار سود کم ====================

add_action('admin_notices', 'bzc_check_low_profit_warning');
function bzc_check_low_profit_warning() {
    $screen = get_current_screen();
    if (strpos($screen->id, 'bz-accounting') === false) return;
    
    $low_profit_threshold = get_option('bzc_low_profit_threshold', 10);
    $orders_data = get_transient('bzc_last_orders_data');
    
    if (!$orders_data) return;
    
    $low_profit_orders = [];
    foreach ($orders_data as $order) {
        if (isset($order['profit_percent']) && $order['profit_percent'] < $low_profit_threshold && $order['profit_percent'] >= 0) {
            $low_profit_orders[] = $order;
        }
    }
    
    if (!empty($low_profit_orders)) {
        ?>
        <div class="notice notice-warning is-dismissible" style="border-right: 4px solid #f39c12;">
            <p>
                <strong>⚠️ هشدار سود کم!</strong>
                تعداد <?php echo count($low_profit_orders); ?> سفارش با سود کمتر از <?php echo $low_profit_threshold; ?>% 
                شناسایی شدند.
                <br><small style="color: #666;">برای مشاهده، لیست سفارش‌ها را بررسی کنید.</small>
            </p>
        </div>
        <?php
    }
}

// ==================== بخش جدید: تنظیمات پیشرفته ====================

add_action('admin_post_bzc_save_advanced_settings', 'bzc_save_advanced_settings');
function bzc_save_advanced_settings() {
    if (!current_user_can('manage_options')) {
        wp_die('دسترسی غیرمجاز');
    }
    check_admin_referer('bzc_advanced_settings');
    
    update_option('bzc_low_profit_threshold', floatval($_POST['low_profit_threshold']));
    update_option('bzc_auto_calculate_profit', isset($_POST['auto_calculate_profit']) ? 1 : 0);
    update_option('bzc_show_profit_in_order_list', isset($_POST['show_profit_in_order_list']) ? 1 : 0);
    
    wp_redirect(add_query_arg('settings_saved', '1', wp_get_referer()));
    exit;
}

// ==================== صفحه تنظیمات ====================
function bzc_render_settings_page() {
    if (isset($_POST['bzc_save_partners']) && check_admin_referer('bzc_settings')) {
        $partners = [];
        if (isset($_POST['partner_name']) && is_array($_POST['partner_name'])) {
            foreach ($_POST['partner_name'] as $i => $name) {
                if (!empty($name)) {
                    $partners[] = [
                        'name' => sanitize_text_field($name),
                        'percent' => floatval($_POST['partner_percent'][$i]),
                        'fee_percent' => isset($_POST['partner_fee_percent'][$i]) && $_POST['partner_fee_percent'][$i] !== '' ? floatval($_POST['partner_fee_percent'][$i]) : null
                    ];
                }
            }
        }
        update_option('bzc_partners', $partners);
        echo '<div class="notice notice-success"><p>شرکا با موفقیت ذخیره شدند.</p></div>';
    }

    if (isset($_POST['bzc_save_gateways']) && check_admin_referer('bzc_settings')) {
        $gateways_fee = [];
        
        if (isset($_POST['gateway_id']) && is_array($_POST['gateway_id'])) {
            foreach ($_POST['gateway_id'] as $index => $gateway_id) {
                $type = $_POST['gateway_fee_type'][$gateway_id] ?? 'percent';
                
                if ($type == 'percent') {
                    $gateways_fee[$gateway_id] = [
                        'type' => 'percent',
                        'value' => floatval($_POST['gateway_percent'][$gateway_id] ?? 0)
                    ];
                } 
                elseif ($type == 'fixed') {
                    $gateways_fee[$gateway_id] = [
                        'type' => 'fixed',
                        'value' => floatval($_POST['gateway_fixed'][$gateway_id] ?? 0)
                    ];
                }
                elseif ($type == 'equation') {
                    $ranges = [];
                    if (isset($_POST['gateway_ranges'][$gateway_id]) && is_array($_POST['gateway_ranges'][$gateway_id])) {
                        foreach ($_POST['gateway_ranges'][$gateway_id] as $range) {
                            if (!empty($range['value']) || $range['value'] == '0') {
                                $ranges[] = [
                                    'min' => !empty($range['min']) ? floatval($range['min']) : 0,
                                    'max' => (!empty($range['max']) || $range['max'] == '0') ? floatval($range['max']) : '',
                                    'value_type' => $range['value_type'],
                                    'value' => floatval($range['value'])
                                ];
                            }
                        }
                    }
                    $gateways_fee[$gateway_id] = [
                        'type' => 'equation',
                        'ranges' => $ranges
                    ];
                }
            }
        }
        
        // Keep the existing current-rate option for backward compatibility,
        // while also recording dated versions for historical order calculations.
        // IMPORTANT: capture the OLD option before it is overwritten below.
        $previous_gateway_fees = get_option('bzc_gateways_fee', []);
        $fee_history = bzc_normalize_gateway_fee_history();
        $effective_dates = isset($_POST['gateway_fee_effective_date']) && is_array($_POST['gateway_fee_effective_date'])
            ? $_POST['gateway_fee_effective_date'] : [];

        foreach ($gateways_fee as $gateway_id => $config) {
            $input_date = $effective_dates[$gateway_id] ?? '';
            $effective_date = bzc_finance_normalize_date_input($input_date, true);
            if (!$effective_date) {
                $effective_date = current_time('Y-m-d');
            }

            $versions = (isset($fee_history[$gateway_id]) && is_array($fee_history[$gateway_id]))
                ? $fee_history[$gateway_id] : [];

            $has_same_date = false;
            $has_earlier_version = false;
            foreach ($versions as $version) {
                $version_date = (string) ($version['start_date'] ?? '');
                if ($version_date === $effective_date) {
                    $has_same_date = true;
                } elseif ($version_date !== '' && $version_date < $effective_date) {
                    $has_earlier_version = true;
                }
            }

            // Preserve the rate that was active before this change. The old code
            // only modified a local array, then bzc_add_gateway_fee_history_version()
            // reloaded the option from the database and lost that baseline.
            if (!$has_same_date && !$has_earlier_version
                && isset($previous_gateway_fees[$gateway_id])
                && is_array($previous_gateway_fees[$gateway_id])) {

                $has_baseline = false;
                foreach ($versions as $version) {
                    if (($version['start_date'] ?? '') === '1970-01-01') {
                        $has_baseline = true;
                        break;
                    }
                }

                if (!$has_baseline) {
                    $versions[] = [
                        'start_date' => '1970-01-01',
                        'config' => $previous_gateway_fees[$gateway_id],
                        'created_at' => current_time('mysql'),
                        'updated_at' => current_time('mysql'),
                    ];
                    $fee_history[$gateway_id] = $versions;
                    update_option('bzc_gateway_fee_history', $fee_history, false);
                }
            }

            bzc_add_gateway_fee_history_version($gateway_id, $effective_date, $config);
            // Keep the in-memory copy in sync for subsequent gateways in this request.
            $fee_history = bzc_normalize_gateway_fee_history();
        }
        update_option('bzc_gateways_fee', $gateways_fee);
        echo '<div class="notice notice-success"><p>کارمزد درگاه‌ها با موفقیت ذخیره شد و تاریخچه نرخ‌ها ثبت گردید.</p></div>';
    }

    $partners = get_option('bzc_partners', []);
    $gateways_fee = get_option('bzc_gateways_fee', []);
    $gateway_fee_history = bzc_normalize_gateway_fee_history();
    $all_gateways = bzc_get_all_payment_gateways();
    ?>
    <div class="wrap bzc-settings-wrap">
        <h1>تنظیمات BZ-Accounting</h1>
        
        <form method="post">
            <?php wp_nonce_field('bzc_settings'); ?>
            <h2>👥 مدیریت شرکا</h2>
            <p><small>درصد سود: درصد از سود ناخالص | درصد کارمزد: درصد از کارمزد درگاه (خالی = مساوی)</small></p>
            <div id="partners-list">
                <?php foreach ($partners as $idx => $partner): ?>
                    <div class="partner-row">
                        <input type="text" name="partner_name[]" value="<?php echo esc_attr($partner['name']); ?>" placeholder="نام شریک" style="width: 150px;">
                        <input type="number" step="0.1" name="partner_percent[]" value="<?php echo esc_attr($partner['percent']); ?>" placeholder="درصد سود" style="width: 100px;">
                        <input type="number" step="0.1" name="partner_fee_percent[]" value="<?php echo isset($partner['fee_percent']) ? esc_attr($partner['fee_percent']) : ''; ?>" placeholder="درصد کارمزد (اختیاری)" style="width: 150px;">
                        <button type="button" class="remove-partner">حذف</button>
                    </div>
                <?php endforeach; ?>
                <div class="partner-row template" style="display:none;">
                    <input type="text" name="partner_name[]" placeholder="نام شریک" style="width: 150px;">
                    <input type="number" step="0.1" name="partner_percent[]" placeholder="درصد سود" style="width: 100px;">
                    <input type="number" step="0.1" name="partner_fee_percent[]" placeholder="درصد کارمزد (اختیاری)" style="width: 150px;">
                    <button type="button" class="remove-partner">حذف</button>
                </div>
            </div>
            <button type="button" id="add-partner" class="button">افزودن شریک جدید</button>
            <input type="submit" name="bzc_save_partners" class="button button-primary" value="ذخیره شرکا">
        </form>

        <h2>💰 تنظیم کارمزد درگاه‌های پرداخت</h2>
        <p><small>تنظیم کارمزد برای تمام درگاه‌های فعال و غیرفعال (درگاه‌هایی که قبلاً استفاده شده‌اند)</small></p>
        <form method="post">
            <?php wp_nonce_field('bzc_settings'); ?>
            <table class="widefat">
                <thead>
                    <tr>
                        <th>درگاه</th>
                        <th>وضعیت</th>
                        <th>نوع کارمزد</th>
                        <th>تنظیمات</th>
                        <th>تاریخ شروع این نرخ</th>
                        <th>تاریخچه</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($all_gateways as $gateway): 
                        $id = $gateway['id'];
                        $title = $gateway['title'];
                        $is_active = $gateway['is_active'];
                        $fee = $gateways_fee[$id] ?? ['type' => 'percent', 'value' => 0, 'ranges' => []];
                    ?>
                        <tr class="gateway-row">
                            <td><?php echo esc_html($title); ?><input type="hidden" name="gateway_id[]" value="<?php echo esc_attr($id); ?>"></td>
                            <td>
                                <?php if ($is_active): ?>
                                    <span style="color: #2c7a2c;">✅ فعال</span>
                                <?php else: ?>
                                    <span style="color: #ff9800;">⏸️ غیرفعال</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <select name="gateway_fee_type[<?php echo esc_attr($id); ?>]" class="fee-type" data-gateway="<?php echo esc_attr($id); ?>">
                                    <option value="percent" <?php selected($fee['type'], 'percent'); ?>>درصدی</option>
                                    <option value="fixed" <?php selected($fee['type'], 'fixed'); ?>>ثابت (تومان)</option>
                                    <option value="equation" <?php selected($fee['type'], 'equation'); ?>>رنجی (پلکانی)</option>
                                </select>
                             </td>
                             <td>
                                <div class="fee-percent-section" id="percent-<?php echo esc_attr($id); ?>" style="display: <?php echo ($fee['type'] == 'percent') ? 'block' : 'none'; ?>">
                                    <input type="number" step="0.01" name="gateway_percent[<?php echo esc_attr($id); ?>]" value="<?php echo ($fee['type']=='percent') ? esc_attr($fee['value']) : '0'; ?>" style="width: 150px;"> درصد
                                </div>
                                <div class="fee-fixed-section" id="fixed-<?php echo esc_attr($id); ?>" style="display: <?php echo ($fee['type'] == 'fixed') ? 'block' : 'none'; ?>">
                                    <input type="number" name="gateway_fixed[<?php echo esc_attr($id); ?>]" value="<?php echo ($fee['type']=='fixed') ? esc_attr($fee['value']) : '0'; ?>" style="width: 150px;"> تومان
                                </div>
                                <div class="fee-equation-section" id="equation-<?php echo esc_attr($id); ?>" style="display: <?php echo ($fee['type'] == 'equation') ? 'block' : 'none'; ?>">
                                    <div class="ranges-container" data-gateway="<?php echo esc_attr($id); ?>">
                                        <?php 
                                        $ranges = ($fee['type'] == 'equation' && isset($fee['ranges'])) ? $fee['ranges'] : [];
                                        if (empty($ranges)) $ranges = [['min' => '', 'max' => '', 'value_type' => 'percent', 'value' => '']];
                                        foreach ($ranges as $idx => $range): ?>
                                            <div class="range-row">
                                                <input type="number" name="gateway_ranges[<?php echo esc_attr($id); ?>][<?php echo $idx; ?>][min]" value="<?php echo esc_attr($range['min']); ?>" placeholder="حداقل" style="width:100px">
                                                <input type="number" name="gateway_ranges[<?php echo esc_attr($id); ?>][<?php echo $idx; ?>][max]" value="<?php echo esc_attr($range['max']); ?>" placeholder="حداکثر" style="width:100px">
                                                <select name="gateway_ranges[<?php echo esc_attr($id); ?>][<?php echo $idx; ?>][value_type]">
                                                    <option value="percent" <?php selected($range['value_type'], 'percent'); ?>>درصدی</option>
                                                    <option value="fixed" <?php selected($range['value_type'], 'fixed'); ?>>ثابت</option>
                                                </select>
                                                <input type="number" step="0.01" name="gateway_ranges[<?php echo esc_attr($id); ?>][<?php echo $idx; ?>][value]" value="<?php echo esc_attr($range['value']); ?>" placeholder="مقدار" style="width:100px">
                                                <button type="button" class="remove-range button button-small">❌</button>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                    <button type="button" class="add-range button button-secondary" data-gateway="<?php echo esc_attr($id); ?>">+ افزودن رنج</button>
                                </div>
                             </td>
                             <td>
                                <?php
                                $history_versions = isset($gateway_fee_history[$id]) && is_array($gateway_fee_history[$id]) ? $gateway_fee_history[$id] : [];
                                $latest_history_date = '';
                                if (!empty($history_versions)) {
                                    usort($history_versions, function($a, $b) { return strcmp($a['start_date'] ?? '', $b['start_date'] ?? ''); });
                                    $last_version = end($history_versions);
                                    $latest_history_date = $last_version['start_date'] ?? '';
                                }
                                $effective_display = $latest_history_date ? bzc_convert_gregorian_to_persian_simple($latest_history_date) : bzc_convert_gregorian_to_persian_simple(current_time('Y-m-d'));
                                ?>
                                <input type="text" class="bzc-finance-persian-date" name="gateway_fee_effective_date[<?php echo esc_attr($id); ?>]" value="<?php echo esc_attr($effective_display); ?>" placeholder="تاریخ شروع" style="width:125px;" autocomplete="off">
                             </td>
                             <td style="min-width:220px;">
                                <?php if (!empty($history_versions)): ?>
                                    <?php foreach (array_reverse($history_versions) as $version): ?>
                                        <div style="font-size:12px; margin-bottom:3px;">
                                            <strong><?php echo esc_html(bzc_convert_gregorian_to_persian_simple($version['start_date'] ?? '')); ?></strong>
                                            — <?php
                                            $vc = $version['config'] ?? [];
                                            if (($vc['type'] ?? '') === 'percent') echo esc_html($vc['value'] ?? 0) . '%';
                                            elseif (($vc['type'] ?? '') === 'fixed') echo number_format((float)($vc['value'] ?? 0)) . ' تومان';
                                            else echo 'رنجی';
                                            ?>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <span style="color:#888;font-size:12px;">هنوز تاریخچه‌ای ثبت نشده</span>
                                <?php endif; ?>
                             </td>
                         </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <p style="margin-top: 10px; font-size: 12px; color: #666;">
                💡 <strong>نکته:</strong> درگاه‌های غیرفعال نیز نمایش داده می‌شوند تا بتوانید کارمزد آنها را برای گزارش‌های قبلی تنظیم کنید.
            </p>
            <input type="submit" name="bzc_save_gateways" class="button button-primary" value="ذخیره کارمزد درگاه‌ها">
        </form>

        <!-- ===== بخش تنظیمات پیشرفته ===== -->
        <h2>⚙️ تنظیمات پیشرفته</h2>
        <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
            <?php wp_nonce_field('bzc_advanced_settings'); ?>
            <input type="hidden" name="action" value="bzc_save_advanced_settings">
            
            <table class="form-table">
                <tr>
                    <th><label for="low_profit_threshold">درصد هشدار سود کم</label></th>
                    <td>
                        <input type="number" id="low_profit_threshold" name="low_profit_threshold" 
                               value="<?php echo get_option('bzc_low_profit_threshold', 10); ?>" 
                               step="0.5" min="0" max="100" style="width: 100px;">
                        <span>درصد</span>
                        <p class="description">اگر سود سفارشی کمتر از این درصد باشد، هشدار نمایش داده می‌شود.</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="auto_calculate_profit">محاسبه خودکار سود</label></th>
                    <td>
                        <input type="checkbox" id="auto_calculate_profit" name="auto_calculate_profit" 
                               value="1" <?php checked(get_option('bzc_auto_calculate_profit', 0), 1); ?>>
                        <label for="auto_calculate_profit">محاسبه خودکار سود هنگام مشاهده سفارش‌ها</label>
                    </td>
                </tr>
                <tr>
                    <th><label for="show_profit_in_order_list">نمایش سود در لیست سفارش‌ها</label></th>
                    <td>
                        <input type="checkbox" id="show_profit_in_order_list" name="show_profit_in_order_list" 
                               value="1" <?php checked(get_option('bzc_show_profit_in_order_list', 1), 1); ?>>
                        <label for="show_profit_in_order_list">نمایش ستون سود در لیست سفارش‌های ووکامرس</label>
                    </td>
                </tr>
            </table>
            
            <input type="submit" class="button button-primary" value="💾 ذخیره تنظیمات پیشرفته">
        </form>
        
        <?php if (isset($_GET['settings_saved'])): ?>
            <div class="notice notice-success"><p>✅ تنظیمات پیشرفته با موفقیت ذخیره شدند.</p></div>
        <?php endif; ?>
    </div>
    <?php
}

// ==================== بخش جدید: بهبودهای ظاهری و UX ====================

// ===== اضافه کردن متا باکس به صفحه سفارش ووکامرس =====
add_action('add_meta_boxes', 'bzc_add_order_meta_box');
function bzc_add_order_meta_box() {
    add_meta_box(
        'bzc_order_accounting',
        '📊 حسابداری BZ',
        'bzc_render_order_meta_box',
        'shop_order',
        'side',
        'high'
    );
}

function bzc_render_order_meta_box($post) {
    if (!class_exists('WooCommerce')) {
        echo '<p style="color: #666;">ووکامرس فعال نیست.</p>';
        return;
    }
    
    $order = wc_get_order($post->ID);
    if (!$order) {
        echo '<p style="color: #666;">سفارش یافت نشد.</p>';
        return;
    }
    
    $total = $order->get_total();
    $gateway = $order->get_payment_method();
    $gateway_name = bzc_get_gateway_display_name($gateway);
    
    $total_buy = 0;
    $total_extra = 0;
    foreach ($order->get_items() as $item) {
        $product_name = $item->get_name();
        $meta_key_buy = '_bzc_buy_price_' . sanitize_title($product_name);
        $meta_key_extra = '_bzc_extra_cost_' . sanitize_title($product_name);
        $buy_price = floatval(get_post_meta($post->ID, $meta_key_buy, true));
        $extra_cost = floatval(get_post_meta($post->ID, $meta_key_extra, true));
        $total_buy += $buy_price;
        $total_extra += $extra_cost;
    }
    
    $gateways_fee = get_option('bzc_gateways_fee', []);
    $fee_config = $gateways_fee[$gateway] ?? null;
    $fee = bzc_calculate_gateway_fee($total, $fee_config, $gateway, $order->get_date_created() ? $order->get_date_created()->date('Y-m-d') : '');
    $total_cost = $total_buy + $total_extra;
    $net_profit = $total - $total_cost - $fee;
    $profit_color = $net_profit >= 0 ? '#2c7a2c' : '#dc3232';
    
    ?>
    <div style="padding: 10px 0;">
        <p><strong>💳 درگاه:</strong> <?php echo esc_html($gateway_name); ?></p>
        <p><strong>💰 مبلغ کل:</strong> <?php echo number_format($total); ?> تومان</p>
        <p><strong>📦 قیمت خرید کل:</strong> <?php echo number_format($total_buy); ?> تومان</p>
        <p><strong>💰 هزینه‌های جانبی:</strong> <?php echo number_format($total_extra); ?> تومان</p>
        <p><strong>📦 قیمت تمام‌شده کل:</strong> <?php echo number_format($total_cost); ?> تومان</p>
        <p><strong>💸 کارمزد درگاه:</strong> <?php echo number_format($fee); ?> تومان</p>
        <hr style="margin: 10px 0; border: none; border-top: 1px solid #eee;">
        <p style="font-size: 16px; font-weight: bold; color: <?php echo $profit_color; ?>;">
            💰 سود خالص: <?php echo number_format($net_profit); ?> تومان
        </p>
        <hr style="margin: 10px 0; border: none; border-top: 1px solid #eee;">
        <p style="font-size: 12px; color: #666; margin: 8px 0;">
            💡 برای ویرایش قیمت خرید و هزینه‌های جانبی، به صفحه اصلی BZ-Accounting بروید.
        </p>
        <a href="<?php echo admin_url('admin.php?page=bz-accounting-orders'); ?>" class="button button-small" style="display: block; text-align: center;">
            🔍 مشاهده در حسابداری
        </a>
    </div>
    <?php
}

// ===== اضافه کردن ستون‌های سفارشی به لیست سفارش‌ها =====
add_filter('manage_edit-shop_order_columns', 'bzc_add_order_list_columns');
function bzc_add_order_list_columns($columns) {
    $new_columns = [];
    foreach ($columns as $key => $value) {
        $new_columns[$key] = $value;
        if ($key === 'order_total') {
            $new_columns['bzc_net_profit'] = '💰 سود خالص';
        }
    }
    return $new_columns;
}

add_action('manage_shop_order_posts_custom_column', 'bzc_render_order_list_columns', 10, 2);
function bzc_render_order_list_columns($column, $post_id) {
    if ($column === 'bzc_net_profit') {
        $order = wc_get_order($post_id);
        if (!$order) return;
        
        $total = $order->get_total();
        $gateway = $order->get_payment_method();
        $gateways_fee = get_option('bzc_gateways_fee', []);
        $fee_config = $gateways_fee[$gateway] ?? null;
        $fee = bzc_calculate_gateway_fee($total, $fee_config, $gateway, $order->get_date_created() ? $order->get_date_created()->date('Y-m-d') : '');
        
        $total_buy = 0;
        $total_extra = 0;
        foreach ($order->get_items() as $item) {
            $product_name = $item->get_name();
            $meta_key_buy = '_bzc_buy_price_' . sanitize_title($product_name);
            $meta_key_extra = '_bzc_extra_cost_' . sanitize_title($product_name);
            $buy_price = floatval(get_post_meta($post_id, $meta_key_buy, true));
            $extra_cost = floatval(get_post_meta($post_id, $meta_key_extra, true));
            $total_buy += $buy_price;
            $total_extra += $extra_cost;
        }
        
        $total_cost = $total_buy + $total_extra;
        $net_profit = $total - $total_cost - $fee;
        $color = $net_profit >= 0 ? '#2c7a2c' : '#dc3232';
        echo '<span style="color: ' . $color . '; font-weight: bold; direction: ltr; display: inline-block;">' . number_format($net_profit) . '</span>';
    }
}

// ===== اضافه کردن فیلترهای سریع به صفحه سفارش‌ها =====
add_action('restrict_manage_posts', 'bzc_add_order_filters');
function bzc_add_order_filters() {
    global $typenow;
    if ($typenow !== 'shop_order') return;
    
    $gateways = bzc_get_all_payment_gateways();
    if (empty($gateways)) return;
    
    $selected = isset($_GET['bzc_gateway_filter']) ? $_GET['bzc_gateway_filter'] : '';
    ?>
    <select name="bzc_gateway_filter">
        <option value="">🏦 همه درگاه‌ها</option>
        <?php foreach ($gateways as $gateway): ?>
            <option value="<?php echo esc_attr($gateway['id']); ?>" <?php selected($selected, $gateway['id']); ?>>
                <?php echo esc_html($gateway['title']); ?>
                <?php echo $gateway['is_active'] ? '' : ' (غیرفعال)'; ?>
            </option>
        <?php endforeach; ?>
    </select>
    <?php
}

add_filter('parse_query', 'bzc_filter_orders_by_gateway');
function bzc_filter_orders_by_gateway($query) {
    global $pagenow, $typenow;
    if ($pagenow !== 'edit.php' || $typenow !== 'shop_order') return $query;
    
    if (!empty($_GET['bzc_gateway_filter'])) {
        $gateway_id = sanitize_text_field($_GET['bzc_gateway_filter']);
        $meta_query = $query->get('meta_query') ?: [];
        $meta_query[] = [
            'key' => '_payment_method',
            'value' => $gateway_id,
            'compare' => '='
        ];
        $query->set('meta_query', $meta_query);
    }
    
    return $query;
}

// ===== اضافه کردن اکشن به پایین صفحه برای راهنمایی کاربر =====
add_action('admin_footer', 'bzc_add_footer_help');
function bzc_add_footer_help() {
    $screen = get_current_screen();
    if (strpos($screen->id, 'bz-accounting') === false) return;
    ?>
    <div style="margin-top: 30px; padding: 20px; background: #f8f9fc; border-radius: 12px; border: 1px solid #e8ecf1; text-align: center; font-size: 13px; color: #666;">
        <p style="margin: 5px 0;">
            💡 <strong>راهنمای سریع:</strong>
            Ctrl+Enter برای جستجو | Esc برای پاک کردن جستجو | دابل کلیک روی شماره سفارش برای کپی
        </p>
        <p style="margin: 5px 0; font-size: 12px; color: #8892b0;">
            BZ-Accounting v<?php echo BZC_VERSION; ?> | ساخته شده با ❤️
        </p>
    </div>
    <?php
}
?>