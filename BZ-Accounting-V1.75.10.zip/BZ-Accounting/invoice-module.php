<?php
if (!defined('ABSPATH')) exit;

if (!defined('BZC_INVOICE_VERSION')) define('BZC_INVOICE_VERSION','1.0.0');
function bzc_invoice_table($name){ global $wpdb; return $wpdb->prefix.'bzc_invoices_'.$name; }
function bzc_invoice_install(){
 global $wpdb; require_once ABSPATH.'wp-admin/includes/upgrade.php'; $charset=$wpdb->get_charset_collate();
 $invoices=bzc_invoice_table('invoices'); $items=bzc_invoice_table('items');
 dbDelta("CREATE TABLE {$invoices} (
 id bigint(20) unsigned NOT NULL AUTO_INCREMENT, invoice_no varchar(50) NOT NULL, type varchar(20) NOT NULL DEFAULT 'invoice', status varchar(30) NOT NULL DEFAULT 'issued', party_id bigint(20) unsigned NOT NULL DEFAULT 0, order_id bigint(20) unsigned NOT NULL DEFAULT 0, issue_date date NOT NULL, due_date date DEFAULT NULL, subtotal decimal(20,2) NOT NULL DEFAULT 0, discount decimal(20,2) NOT NULL DEFAULT 0, tax decimal(20,2) NOT NULL DEFAULT 0, total decimal(20,2) NOT NULL DEFAULT 0, payment_type varchar(20) NOT NULL DEFAULT 'credit', payment_account_id bigint(20) unsigned NOT NULL DEFAULT 0, check_id bigint(20) unsigned NOT NULL DEFAULT 0, notes text NULL, converted_from bigint(20) unsigned NOT NULL DEFAULT 0, created_by bigint(20) unsigned NOT NULL DEFAULT 0, created_at datetime NOT NULL, updated_at datetime NOT NULL, PRIMARY KEY(id), UNIQUE KEY invoice_no(invoice_no), KEY type(type), KEY party_id(party_id), KEY order_id(order_id), KEY status(status) ) {$charset};");
 dbDelta("CREATE TABLE {$items} (
 id bigint(20) unsigned NOT NULL AUTO_INCREMENT, invoice_id bigint(20) unsigned NOT NULL, product_id bigint(20) unsigned NOT NULL DEFAULT 0, product_name varchar(255) NOT NULL, sku varchar(190) NOT NULL DEFAULT '', quantity decimal(20,4) NOT NULL DEFAULT 1, unit_price decimal(20,2) NOT NULL DEFAULT 0, discount decimal(20,2) NOT NULL DEFAULT 0, total decimal(20,2) NOT NULL DEFAULT 0, PRIMARY KEY(id), KEY invoice_id(invoice_id), KEY product_id(product_id) ) {$charset};");
 // Add a party-only effect column to the existing finance ledger. Existing rows remain neutral.
 $ft=bzc_finance_table('transactions');
 $col=$wpdb->get_var("SHOW COLUMNS FROM {$ft} LIKE 'party_effect'"); if(!$col) $wpdb->query("ALTER TABLE {$ft} ADD party_effect decimal(20,2) NOT NULL DEFAULT 0 AFTER party_id");
 update_option('bzc_invoice_db_version',BZC_INVOICE_VERSION); flush_rewrite_rules(false);
}
add_action('plugins_loaded','bzc_invoice_maybe_install',30); function bzc_invoice_maybe_install(){ if(get_option('bzc_invoice_db_version')!==BZC_INVOICE_VERSION) bzc_invoice_install(); }

function bzc_invoice_next_no($type='invoice'){
 global $wpdb; $prefix=$type==='proforma'?'P':'F'; $like=$prefix.'-%'; $max=$wpdb->get_var($wpdb->prepare("SELECT invoice_no FROM ".bzc_invoice_table('invoices')." WHERE invoice_no LIKE %s ORDER BY id DESC LIMIT 1",$like)); $n=1; if($max && preg_match('/-(\d+)$/',$max,$m)) $n=((int)$m[1])+1; return $prefix.'-'.str_pad($n,6,'0',STR_PAD_LEFT);
}
function bzc_invoice_date_in($d){ return function_exists('bzc_finance_normalize_date_input')?bzc_finance_normalize_date_input($d,false):sanitize_text_field($d); }
function bzc_invoice_date_out($d=null){ $d=$d?:current_time('Y-m-d'); return function_exists('bzc_finance_display_input_date')?bzc_finance_display_input_date($d):$d; }
function bzc_invoice_items_total($items){ $s=0; foreach($items as $i) $s += ((float)$i['quantity']*(float)$i['unit_price'])-(float)$i['discount']; return max(0,$s); }
function bzc_invoice_get_party($id){ global $wpdb; return $id? $wpdb->get_row($wpdb->prepare('SELECT * FROM '.bzc_finance_table('parties').' WHERE id=%d',$id),ARRAY_A):null; }
function bzc_invoice_order_items($order){ $out=[]; foreach($order->get_items() as $item){ $p=$item->get_product(); $qty=(float)$item->get_quantity(); $total=(float)$item->get_total(); $out[]=['product_id'=>$p?(int)$p->get_id():0,'product_name'=>$item->get_name(),'sku'=>$p?(string)$p->get_sku():'','quantity'=>$qty,'unit_price'=>$qty?$total/$qty:0,'discount'=>0,'total'=>$total]; } return $out; }
function bzc_invoice_create_from_order($order_id){
 global $wpdb; if(!$order_id || !function_exists('wc_get_order')) return 0; $order=wc_get_order($order_id); if(!$order) return 0; $t=bzc_invoice_table('invoices'); $existing=$wpdb->get_var($wpdb->prepare("SELECT id FROM {$t} WHERE order_id=%d AND type='invoice' LIMIT 1",$order_id)); if($existing) return (int)$existing;
 $name=trim((string)$order->get_formatted_billing_full_name()); $party=0; if($name){ $party=(int)$wpdb->get_var($wpdb->prepare('SELECT id FROM '.bzc_finance_table('parties').' WHERE name=%s LIMIT 1',$name)); if(!$party){$now=current_time('mysql');$wpdb->insert(bzc_finance_table('parties'),['name'=>$name,'type'=>'customer','phone'=>(string)$order->get_billing_phone(),'email'=>(string)$order->get_billing_email(),'created_at'=>$now,'updated_at'=>$now]);$party=(int)$wpdb->insert_id;} }
 $created=$order->get_date_created(); $date=$created?$created->date('Y-m-d'):current_time('Y-m-d'); $items=bzc_invoice_order_items($order); $subtotal=bzc_invoice_items_total($items); $discount=max(0,$subtotal-(float)$order->get_total()); $now=current_time('mysql'); $wpdb->insert($t,['invoice_no'=>bzc_invoice_next_no('invoice'),'type'=>'invoice','status'=>'issued','party_id'=>$party,'order_id'=>$order_id,'issue_date'=>$date,'subtotal'=>$subtotal,'discount'=>$discount,'total'=>(float)$order->get_total(),'payment_type'=>'credit','created_by'=>0,'created_at'=>$now,'updated_at'=>$now]); $id=(int)$wpdb->insert_id; foreach($items as $i){$wpdb->insert(bzc_invoice_table('items'),array_merge($i,['invoice_id'=>$id]));}
 return $id;
}
add_action('woocommerce_checkout_order_processed',function($order_id){ bzc_invoice_create_from_order($order_id); },20);
add_action('woocommerce_payment_complete',function($order_id){ bzc_invoice_create_from_order($order_id); },20);

// Customer account endpoint
add_action('init',function(){ add_rewrite_endpoint('bz-invoices',EP_ROOT|EP_PAGES); });
add_filter('woocommerce_account_menu_items',function($items){ if(!isset($items['bz-invoices'])) $items['bz-invoices']='فاکتورهای من'; return $items; });
add_action('woocommerce_account_bz-invoices_endpoint',function(){ bzc_invoice_customer_page(); });
function bzc_invoice_customer_page(){ if(!is_user_logged_in()) return; global $wpdb; $uid=get_current_user_id(); $email=wp_get_current_user()->user_email; $order_ids=function_exists('wc_get_orders')?wc_get_orders(['customer_id'=>$uid,'limit'=>-1,'return'=>'ids']):[]; $where="i.party_id IN (SELECT id FROM ".bzc_finance_table('parties')." WHERE email=%s)"; $params=[$email]; if($order_ids){$ph=implode(',',array_fill(0,count($order_ids),'%d'));$where.=" OR i.order_id IN ($ph)";foreach($order_ids as $oid)$params[]=(int)$oid;} $sql="SELECT i.*,p.name party_name FROM ".bzc_invoice_table('invoices')." i LEFT JOIN ".bzc_finance_table('parties')." p ON p.id=i.party_id WHERE ($where) AND i.type='invoice' ORDER BY i.id DESC"; $rows=$wpdb->get_results($wpdb->prepare($sql,$params),ARRAY_A); echo '<h2>فاکتورهای من</h2>'; if(!$rows){echo '<p>هنوز فاکتوری برای شما ثبت نشده است.</p>';return;} echo '<table class="shop_table shop_table_responsive"><thead><tr><th>شماره</th><th>تاریخ</th><th>مبلغ</th><th>وضعیت</th><th></th></tr></thead><tbody>'; foreach($rows as $r){$url=add_query_arg('bz_invoice_id',(int)$r['id'],wc_get_account_endpoint_url('bz-invoices')); echo '<tr><td>'.esc_html($r['invoice_no']).'</td><td>'.esc_html(bzc_finance_date($r['issue_date'])).'</td><td>'.esc_html(bzc_finance_money($r['total'])).'</td><td>'.esc_html($r['status']).'</td><td><a class="button" href="'.esc_url($url).'">مشاهده</a></td></tr>';} echo '</tbody></table>'; $id=absint($_GET['bz_invoice_id']??0); if($id) bzc_invoice_customer_detail($id,$uid); }
function bzc_invoice_customer_detail($id,$uid){ global $wpdb; $r=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.bzc_invoice_table('invoices').' WHERE id=%d',$id),ARRAY_A); if(!$r)return; if($r['order_id'] && function_exists('wc_get_order')){$o=wc_get_order($r['order_id']); if(!$o||((int)$o->get_user_id()!==$uid)) return;} elseif(!current_user_can('manage_options')) return; $items=$wpdb->get_results($wpdb->prepare('SELECT * FROM '.bzc_invoice_table('items').' WHERE invoice_id=%d ORDER BY id',$id),ARRAY_A); echo '<div style="margin-top:30px"><h2>فاکتور '.esc_html($r['invoice_no']).'</h2><table class="shop_table"><thead><tr><th>محصول</th><th>تعداد</th><th>قیمت واحد</th><th>جمع</th></tr></thead><tbody>'; foreach($items as $i)echo '<tr><td>'.esc_html($i['product_name']).'</td><td>'.esc_html($i['quantity']).'</td><td>'.esc_html(bzc_finance_money($i['unit_price'])).'</td><td>'.esc_html(bzc_finance_money($i['total'])).'</td></tr>'; echo '</tbody></table><p><strong>مبلغ نهایی: '.esc_html(bzc_finance_money($r['total'])).'</strong></p></div>'; }

// فاکتور و پیش‌فاکتور فقط از مرکز «عملیات فاکتور» در دسترس هستند.
// عمداً منوی جداگانه برای جلوگیری از شلوغی منوی اصلی ساخته نمی‌شود.
add_action('admin_enqueue_scripts',function($hook){ if(strpos($hook,'bz-accounting-invoices')===false && strpos($hook,'bz-accounting-proformas')===false)return; wp_enqueue_script('jquery'); });

// خروجی چاپ/مشاهده در یک صفحه کاملاً مستقل در سایت؛ بدون پوسته، سایدبار و نوار مدیریت وردپرس.
add_action('template_redirect',function(){
    if(empty($_GET['bz_invoice_print'])) return;
    if(!is_user_logged_in() || !current_user_can('manage_options')) wp_die('دسترسی غیرمجاز');
    $id=absint($_GET['invoice_id']??0);
    $type=sanitize_key($_GET['invoice_type']??'invoice');
    if(!in_array($type,['invoice','proforma','purchase','sales_return','purchase_return'],true) || !$id) wp_die('سند نامعتبر است.');
    $nonce=sanitize_text_field(wp_unslash($_GET['_wpnonce']??''));
    if(!$nonce || !wp_verify_nonce($nonce,'bzc_invoice_print_'.$id.'_'.$type)) wp_die('لینک چاپ نامعتبر یا منقضی شده است.');
    nocache_headers();
    bzc_invoice_render_print($id,$type);
    exit;
},1);

function bzc_invoice_print_url($id,$type){
    $url=add_query_arg([
        'bz_invoice_print'=>'1',
        'invoice_id'=>(int)$id,
        'invoice_type'=>$type,
    ],home_url('/'));
    return wp_nonce_url($url,'bzc_invoice_print_'.(int)$id.'_'.$type);
}

function bzc_invoice_render_print($id,$type){
    if(!current_user_can('manage_options')) wp_die('دسترسی غیرمجاز');
    global $wpdb;
    $r=$wpdb->get_row($wpdb->prepare('SELECT i.*,p.name party_name,p.phone party_phone,p.email party_email FROM '.bzc_invoice_table('invoices').' i LEFT JOIN '.bzc_finance_table('parties').' p ON p.id=i.party_id WHERE i.id=%d AND i.type=%s',$id,$type),ARRAY_A);
    if(!$r) wp_die('سند پیدا نشد.');
    $items=$wpdb->get_results($wpdb->prepare('SELECT * FROM '.bzc_invoice_table('items').' WHERE invoice_id=%d ORDER BY id',$id),ARRAY_A);
    $title=function_exists('bzc_doc_label')?bzc_doc_label($type):($type==='invoice'?'فاکتور فروش':'پیش‌فاکتور');
    $payment_labels=['credit'=>'نسیه','bank'=>'حساب بانکی','check'=>'چک','mixed'=>'ترکیبی'];
    $payment=$payment_labels[$r['payment_type']]??$r['payment_type'];
    if(function_exists('bzc_doc_payment_summary')){ $ps=bzc_doc_payment_summary($id); $parts=[]; foreach($ps['rows'] as $pr){$parts[]=($payment_labels[$pr['method']]??$pr['method']).': '.bzc_finance_money($pr['amount']);} if($parts)$payment=implode(' · ',$parts); }
    $back=admin_url('admin.php?page='.($type==='invoice'?'bz-accounting-invoices':($type==='proforma'?'bz-accounting-proformas':'bz-accounting-documents')));
    $logo='';
    $custom_logo_id=(int)get_theme_mod('custom_logo');
    if($custom_logo_id){
        $src=wp_get_attachment_image_src($custom_logo_id,'medium');
        if($src && !empty($src[0])) $logo=$src[0];
    }
    if(!$logo && function_exists('get_site_icon_url')) $logo=(string)get_site_icon_url(128);
    $store_name=get_bloginfo('name');
    $store_desc=get_bloginfo('description');
    $store_phone=function_exists('WC') && WC() ? (string)get_option('woocommerce_store_phone','') : '';
    $store_address=[];
    if(function_exists('WC') && WC()){
        $store_address=array_filter([(string)get_option('woocommerce_store_address',''),(string)get_option('woocommerce_store_city',''),(string)get_option('woocommerce_store_postcode','')]);
    }
    $store_address=implode('، ',$store_address);
    ?>
    <!doctype html><html <?php language_attributes(); ?>><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?php echo esc_html($title.' '.$r['invoice_no']); ?></title>
    <style>
    :root{--accent:#1687d9;--accent-dark:#0b6fb8;--ink:#17212b;--muted:#6f7b86;--line:#dfe6eb;--soft:#f4f8fb}
    *{box-sizing:border-box}html,body{margin:0;padding:0}body{font-family:Tahoma,"Vazirmatn",Arial,sans-serif;background:#edf2f6;color:var(--ink);direction:rtl;font-size:13px;line-height:1.8}
    .print-actions{max-width:930px;margin:18px auto 12px;display:flex;gap:8px;justify-content:flex-start}.print-actions a,.print-actions button{font:inherit;padding:9px 16px;border:1px solid #c9d2da;border-radius:8px;background:#fff;color:var(--ink);text-decoration:none;cursor:pointer}.print-actions .primary{background:var(--accent);border-color:var(--accent);color:#fff;font-weight:700}
    .paper{width:210mm;max-width:210mm;min-height:270mm;margin:0 auto 30px;background:#fff;padding:12mm 12mm;box-shadow:0 5px 25px rgba(23,33,43,.10);position:relative;overflow:visible;page-break-after:avoid;break-after:avoid}
    .paper:before{content:"";position:absolute;right:0;top:0;width:7px;height:100%;background:linear-gradient(var(--accent),var(--accent-dark));}
    .header{display:flex;align-items:center;justify-content:space-between;gap:18px;padding-bottom:14px;border-bottom:2px solid var(--accent)}
    .brand{display:flex;align-items:center;gap:14px;min-width:0}.brand-logo{width:76px;height:76px;border:1px solid var(--line);border-radius:14px;object-fit:contain;padding:7px;background:#fff}.brand-name{font-size:22px;font-weight:800;color:var(--ink)}.brand-desc{font-size:11px;color:var(--muted);margin-top:2px}.brand-contact{font-size:11px;color:var(--muted);margin-top:4px}
    .doc-head{text-align:left;min-width:190px}.doc-title{font-size:26px;font-weight:900;color:var(--accent-dark);margin-bottom:4px}.doc-badge{display:inline-block;background:var(--soft);border:1px solid #cfe4f3;border-radius:999px;padding:2px 10px;color:var(--accent-dark);font-size:11px}.doc-meta{margin-top:7px;font-size:12px;line-height:1.9}.doc-meta strong{font-weight:800}
    .party-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:12px 0}.party-box{border:1px solid var(--line);border-radius:10px;padding:12px 14px;background:linear-gradient(180deg,#fff,var(--soft))}.party-box .label{font-size:11px;color:var(--accent-dark);font-weight:800;margin-bottom:4px}.party-box .name{font-size:15px;font-weight:800}.party-box p{margin:2px 0;color:#49545d;font-size:11px}
    .items{width:100%;border-collapse:separate;border-spacing:0;border:1px solid var(--line);border-radius:10px;overflow:hidden}.items th{background:var(--accent-dark);color:#fff;font-weight:700;padding:9px 7px;border-left:1px solid rgba(255,255,255,.2);white-space:nowrap}.items td{padding:8px 7px;text-align:center;border-left:1px solid var(--line);border-top:1px solid var(--line);font-size:11px}.items tr:nth-child(even) td{background:#fafcfd}.items th:last-child,.items td:last-child{border-left:0}.items td.name{text-align:right;font-weight:600}.items .num{direction:ltr}
    .bottom{display:grid;grid-template-columns:1fr 270px;gap:12px;margin-top:12px;align-items:start}.payment-box,.notes{border:1px solid var(--line);border-radius:10px;padding:12px;background:var(--soft);min-height:70px}.section-title{font-size:11px;color:var(--accent-dark);font-weight:800;margin-bottom:5px}.notes p{margin:0;color:#4c5862;font-size:11px}.summary{border:1px solid var(--line);border-radius:10px;overflow:hidden}.summary-row{display:flex;justify-content:space-between;padding:7px 12px;border-bottom:1px solid var(--line);font-size:11px}.summary-row:last-child{border-bottom:0}.summary-row.total{background:var(--accent-dark);color:#fff;font-size:15px;font-weight:900;padding:11px 12px}.footer{margin-top:18px;padding-top:10px;border-top:1px dashed #cbd5dc;display:flex;justify-content:space-between;gap:20px;color:var(--muted);font-size:10px}.footer strong{color:var(--ink)}
    .watermark{position:absolute;left:28px;bottom:24px;font-size:52px;font-weight:900;color:rgba(22,135,217,.035);transform:rotate(-18deg);pointer-events:none}
    @media(max-width:800px){body{background:#fff}.paper{width:100%;min-height:auto;margin:0;padding:20px;box-shadow:none}.bottom{grid-template-columns:1fr}.header{align-items:flex-start}.brand-logo{width:62px;height:62px}.doc-title{font-size:21px}.print-actions{padding:0 15px}.party-grid{grid-template-columns:1fr}}
    @media print{html,body{width:210mm;margin:0;padding:0;background:#fff}body{font-size:11px;line-height:1.55}.print-actions{display:none!important}.paper{display:block;width:210mm;max-width:210mm;min-height:270mm;height:auto;margin:0;padding:10mm 11mm;box-shadow:none;overflow:visible;page-break-after:avoid;break-after:avoid;page-break-inside:avoid;break-inside:avoid}.paper:before{print-color-adjust:exact;-webkit-print-color-adjust:exact}.header{gap:14px;padding-bottom:10px}.brand-logo{width:64px;height:64px}.brand-name{font-size:19px}.brand-desc,.brand-contact{font-size:9px}.doc-title{font-size:22px}.doc-meta{font-size:10px}.party-grid{gap:8px;margin:10px 0}.party-box{padding:9px 11px}.party-box .name{font-size:13px}.party-box p{font-size:9px}.items th{padding:6px 5px;font-size:9px}.items td{padding:5px;font-size:9px}.bottom{gap:10px;margin-top:10px;grid-template-columns:1fr 250px}.payment-box,.notes{padding:9px}.summary-row{padding:5px 9px;font-size:9px}.summary-row.total{font-size:12px;padding:8px 9px}.footer{margin-top:12px;padding-top:8px;font-size:8px}.items,.party-box,.payment-box,.notes,.summary{page-break-inside:avoid;break-inside:avoid}.items th,.summary-row.total,.party-box{print-color-adjust:exact;-webkit-print-color-adjust:exact}@page{size:A4 portrait;margin:0}}
    </style></head><body>
    <div class="print-actions"><button class="primary" onclick="window.print()">🖨 چاپ / ذخیره PDF</button><a href="<?php echo esc_url($back); ?>">بازگشت به لیست</a></div>
    <main class="paper">
      <header class="header">
        <div class="brand">
          <?php if($logo): ?><img class="brand-logo" src="<?php echo esc_url($logo); ?>" alt="<?php echo esc_attr($store_name); ?>"><?php endif; ?>
          <div><div class="brand-name"><?php echo esc_html($store_name); ?></div><?php if($store_desc): ?><div class="brand-desc"><?php echo esc_html($store_desc); ?></div><?php endif; ?><?php if($store_phone): ?><div class="brand-contact">تلفن: <?php echo esc_html($store_phone); ?></div><?php endif; ?><?php if($store_address): ?><div class="brand-contact"><?php echo esc_html($store_address); ?></div><?php endif; ?></div>
        </div>
        <div class="doc-head"><div class="doc-title"><?php echo esc_html($title); ?></div><span class="doc-badge"><?php echo $type==='invoice'?'سند فروش':'سند پیش از فروش'; ?></span><div class="doc-meta"><div>شماره: <strong><?php echo esc_html($r['invoice_no']); ?></strong></div><div>تاریخ: <strong><?php echo esc_html(bzc_finance_date($r['issue_date'])); ?></strong></div><?php if(!empty($r['due_date'])): ?><div>سررسید: <strong><?php echo esc_html(bzc_finance_date($r['due_date'])); ?></strong></div><?php endif; ?></div></div>
      </header>
      <section class="party-grid">
        <div class="party-box"><div class="label">فروشنده</div><div class="name"><?php echo esc_html($store_name); ?></div><?php if($store_phone): ?><p>تلفن: <?php echo esc_html($store_phone); ?></p><?php endif; ?><?php if($store_address): ?><p>نشانی: <?php echo esc_html($store_address); ?></p><?php endif; ?></div>
        <div class="party-box"><div class="label">خریدار / طرف حساب</div><div class="name"><?php echo esc_html($r['party_name']?:'—'); ?></div><?php if($r['party_phone']): ?><p>تلفن: <?php echo esc_html($r['party_phone']); ?></p><?php endif; ?><?php if($r['party_email']): ?><p>ایمیل: <?php echo esc_html($r['party_email']); ?></p><?php endif; ?></div>
      </section>
      <table class="items"><thead><tr><th>ردیف</th><th>شرح کالا / خدمت</th><th>تعداد</th><th>قیمت واحد</th><th>تخفیف</th><th>مبلغ</th></tr></thead><tbody><?php foreach($items as $n=>$i): ?><tr><td><?php echo $n+1; ?></td><td class="name"><?php echo esc_html($i['product_name']); ?><?php if(!empty($i['sku'])): ?><div style="font-size:9px;color:#89949d">SKU: <?php echo esc_html($i['sku']); ?></div><?php endif; ?></td><td><?php echo esc_html(rtrim(rtrim((string)$i['quantity'],'0'),'.')); ?></td><td><?php echo esc_html(bzc_finance_money($i['unit_price'])); ?></td><td><?php echo esc_html(bzc_finance_money($i['discount'])); ?></td><td><strong><?php echo esc_html(bzc_finance_money($i['total'])); ?></strong></td></tr><?php endforeach; ?></tbody></table>
      <div class="bottom"><div><div class="payment-box"><div class="section-title">نحوه پرداخت</div><strong><?php echo esc_html($payment); ?></strong></div><?php if(!empty($r['notes'])): ?><div class="notes" style="margin-top:10px"><div class="section-title">توضیحات</div><p><?php echo nl2br(esc_html($r['notes'])); ?></p></div><?php endif; ?></div><div class="summary"><div class="summary-row"><span>جمع کالاها</span><strong><?php echo esc_html(bzc_finance_money($r['subtotal'])); ?></strong></div><div class="summary-row"><span>تخفیف</span><strong><?php echo esc_html(bzc_finance_money($r['discount'])); ?></strong></div><div class="summary-row"><span>مالیات</span><strong><?php echo esc_html(bzc_finance_money($r['tax'])); ?></strong></div><div class="summary-row total"><span>مبلغ نهایی</span><strong><?php echo esc_html(bzc_finance_money($r['total'])); ?></strong></div><?php if(function_exists('bzc_doc_payment_summary') && $type==='invoice'): $ps=bzc_doc_payment_summary((int)$r['id']); $remain=max(0,(float)$r['total']-(float)$ps['paid']); ?><div class="summary-row"><span>پرداخت شده</span><strong><?php echo esc_html(bzc_finance_money($ps['paid'])); ?></strong></div><div class="summary-row" style="font-weight:800"><span>مانده بدهی</span><strong><?php echo esc_html(bzc_finance_money($remain)); ?></strong></div><?php endif; ?></div></div>
      <footer class="footer"><div>این سند توسط <strong><?php echo esc_html($store_name); ?></strong> صادر شده است.</div><div><?php echo $type==='invoice'?'فاکتور فروش معتبر':'پیش‌فاکتور'; ?> · <?php echo esc_html($r['invoice_no']); ?></div></footer>
      <div class="watermark"><?php echo esc_html($store_name); ?></div>
    </main></body></html><?php
}

function bzc_invoice_admin_page($type){
    if(!current_user_can('manage_options')) wp_die('دسترسی غیرمجاز');
    $msg=bzc_invoice_admin_action($type);
    global $wpdb;
    $view=absint($_GET['view']??0);
    if($view){ bzc_invoice_render_print($view,$type); return; }
    $search=sanitize_text_field(wp_unslash($_GET['s']??''));
    $date_from=bzc_invoice_date_in($_GET['date_from']??'');
    $date_to=bzc_invoice_date_in($_GET['date_to']??'');
    $where='i.type=%s'; $params=[$type];
    if($search!==''){ $like='%'.$wpdb->esc_like($search).'%'; $where.=' AND (i.invoice_no LIKE %s OR p.name LIKE %s OR CAST(i.order_id AS CHAR) LIKE %s)'; array_push($params,$like,$like,$like); }
    if($date_from){$where.=' AND i.issue_date >= %s';$params[]=$date_from;}
    if($date_to){$where.=' AND i.issue_date <= %s';$params[]=$date_to;}
    $rows=$wpdb->get_results($wpdb->prepare("SELECT i.*,p.name party_name FROM ".bzc_invoice_table('invoices')." i LEFT JOIN ".bzc_finance_table('parties')." p ON p.id=i.party_id WHERE {$where} ORDER BY i.id DESC LIMIT 500",$params),ARRAY_A);
    $edit=absint($_GET['edit']??0); $editing=$edit?$wpdb->get_row($wpdb->prepare('SELECT * FROM '.bzc_invoice_table('invoices').' WHERE id=%d AND type=%s',$edit,$type),ARRAY_A):null;
    $items=$editing?$wpdb->get_results($wpdb->prepare('SELECT * FROM '.bzc_invoice_table('items').' WHERE invoice_id=%d ORDER BY id',$edit),ARRAY_A):[];
    $accounts=bzc_finance_get_accounts(true);
    $base=admin_url('admin.php?page=bz-accounting-documents&doc_view='.$type);
    ?>
    <div class="wrap bzc-invoice-admin-wrap bzc-sales-invoice-page" dir="rtl"><div class="bzc-page-head"><div><span class="bzc-hero-kicker">مرکز اسناد فروش</span><h1><?php echo $type==='invoice'?'🧾 فاکتورها':'📄 پیش‌فاکتورها'; ?></h1><p>مدیریت فاکتورها و پیش‌فاکتورها با همان محیط حرفه‌ای بخش عملیات فاکتور</p></div></div>
    <?php if($msg)echo '<div class="notice notice-success"><p>'.esc_html($msg).'</p></div>'; ?>
    <section class="postbox" style="padding:20px;margin-top:18px"><h2>جستجو و فیلتر</h2><form method="get" style="display:flex;gap:10px;align-items:end;flex-wrap:wrap"><input type="hidden" name="page" value="bz-accounting-documents"><input type="hidden" name="doc_view" value="<?php echo esc_attr($type); ?>"><label>شماره / طرف حساب / سفارش<br><input type="search" name="s" value="<?php echo esc_attr($search); ?>" placeholder="مثلاً F-000001 یا نام مشتری"></label><label>از تاریخ<br><input class="bzc-persian-datepicker" name="date_from" value="<?php echo esc_attr($date_from?bzc_invoice_date_out($date_from):''); ?>"></label><label>تا تاریخ<br><input class="bzc-persian-datepicker" name="date_to" value="<?php echo esc_attr($date_to?bzc_invoice_date_out($date_to):''); ?>"></label><button class="button button-primary">🔍 جستجو</button><a class="button" href="<?php echo esc_url($base); ?>">پاک کردن</a></form></section>
    <section class="postbox" style="padding:20px"><h2><?php echo $editing?'ویرایش':'ثبت'; ?> <?php echo $type==='invoice'?'فاکتور':'پیش‌فاکتور'; ?></h2><form method="post"><input type="hidden" name="bzc_invoice_action" value="save"><input type="hidden" name="bzc_invoice_type" value="<?php echo esc_attr($type); ?>"><input type="hidden" name="id" value="<?php echo esc_attr($editing['id']??0); ?>"><?php wp_nonce_field('bzc_invoice_action','bzc_invoice_nonce'); ?><p><label>طرف حساب <?php $selected_party_id=(int)($editing['party_id']??0); $selected_party=$selected_party_id?bzc_invoice_get_party($selected_party_id):null; ?><select name="party_id" class="bzc-searchable-select" data-bzc-type="party" data-bzc-placeholder="نام طرف حساب را جستجو کنید" required><option value="">انتخاب کنید</option><?php if($selected_party)echo '<option value="'.(int)$selected_party['id'].'" selected>'.esc_html($selected_party['name']).'</option>'; ?></select></label> &nbsp; <label>تاریخ <input name="issue_date" class="bzc-persian-datepicker" value="<?php echo esc_attr($editing?bzc_invoice_date_out($editing['issue_date']):bzc_invoice_date_out()); ?>"></label> &nbsp; <label>سررسید <input name="due_date" class="bzc-persian-datepicker" value="<?php echo esc_attr(!empty($editing['due_date'])?bzc_invoice_date_out($editing['due_date']):''); ?>"></label></p>
    <table class="widefat" id="bzc-invoice-items"><thead><tr><th>محصول سایت</th><th>شرح</th><th>تعداد</th><th>قیمت واحد</th><th>تخفیف</th><th>جمع</th><th></th></tr></thead><tbody><?php $items=$items?:[['product_id'=>0,'product_name'=>'','sku'=>'','quantity'=>1,'unit_price'=>0,'discount'=>0,'total'=>0]]; foreach($items as $idx=>$it): ?><tr><td><select name="items[<?php echo $idx; ?>][product_id]" class="bzc-prod bzc-searchable-select" data-bzc-type="product" data-bzc-placeholder="نام محصول را جستجو کنید"><option value="0">محصول دستی</option><?php if(!empty($it['product_id'])&&function_exists('wc_get_product')&&($sp=wc_get_product((int)$it['product_id'])))echo '<option value="'.(int)$sp->get_id().'" data-name="'.esc_attr($sp->get_name()).'" data-price="'.esc_attr($sp->get_price()).'" selected>'.esc_html($sp->get_name()).'</option>'; ?></select></td><td><input name="items[<?php echo $idx; ?>][product_name]" value="<?php echo esc_attr($it['product_name']); ?>"></td><td><input class="bzc-qty" type="number" step="0.01" name="items[<?php echo $idx; ?>][quantity]" value="<?php echo esc_attr($it['quantity']); ?>"></td><td><input class="bzc-price" type="number" step="0.01" name="items[<?php echo $idx; ?>][unit_price]" value="<?php echo esc_attr($it['unit_price']); ?>"></td><td><input class="bzc-discount" type="number" step="0.01" name="items[<?php echo $idx; ?>][discount]" value="<?php echo esc_attr($it['discount']); ?>"></td><td class="bzc-line-total">0</td><td><button type="button" class="button bzc-remove">حذف</button></td></tr><?php endforeach; ?></tbody></table><p><button type="button" class="button" id="bzc-add-item">+ افزودن ردیف</button></p>
    <p><strong>جمع کالاها: <span id="bzc-subtotal">0</span> تومان</strong></p><p><label>تخفیف کلی <input type="number" step="0.01" name="discount" value="<?php echo esc_attr($editing['discount']??0); ?>"></label> <label>مالیات <input type="number" step="0.01" name="tax" value="<?php echo esc_attr($editing['tax']??0); ?>"></label></p>
    <?php $bzc_payments=$editing && function_exists('bzc_doc_get_payments')?bzc_doc_get_payments((int)$editing['id']):[['method'=>'credit','amount'=>$editing['total']??0,'account_id'=>0,'check_number'=>'']]; ?>
    <h3>💳 نحوه تسویه</h3><p style="color:#666">می‌توانید مبلغ فاکتور را بین چند روش تقسیم کنید؛ مثلاً بخشی بانکی، بخشی چک و باقی نسیه.</p><table class="widefat" id="bzc-invoice-payments"><thead><tr><th>روش</th><th>مبلغ</th><th>حساب بانکی</th><th>شماره چک</th><th></th></tr></thead><tbody><?php foreach($bzc_payments as $pi=>$pay): ?><tr><td><select name="payments[<?php echo $pi; ?>][method]"><option value="credit" <?php selected($pay['method'],'credit'); ?>>نسیه</option><option value="bank" <?php selected($pay['method'],'bank'); ?>>حساب بانکی</option><option value="check" <?php selected($pay['method'],'check'); ?>>چک</option></select></td><td><input name="payments[<?php echo $pi; ?>][amount]" type="number" step="0.01" value="<?php echo esc_attr($pay['amount']); ?>"></td><td><select name="payments[<?php echo $pi; ?>][account_id]"><option value="0">انتخاب حساب</option><?php foreach($accounts as $a)if($a['type']==='bank')echo '<option value="'.$a['id'].'" '.selected($pay['account_id'],$a['id'],false).'>'.esc_html($a['name']).'</option>'; ?></select></td><td><input name="payments[<?php echo $pi; ?>][check_number]" value="<?php echo esc_attr($pay['check_number']); ?>"></td><td><button type="button" class="button bzc-pay-remove">حذف</button></td></tr><?php endforeach; ?></tbody></table><p><button type="button" class="button" id="bzc-pay-add">+ افزودن روش پرداخت</button></p><p><label>توضیحات<br><textarea name="notes" style="width:70%" rows="3"><?php echo esc_textarea($editing['notes']??''); ?></textarea></label></p><p><button class="button button-primary">💾 ذخیره</button><?php if($editing)echo ' <a class="button" href="'.esc_url($base).'">انصراف</a>'; ?></p></form></section>
    <section class="postbox" style="padding:20px"><h2>لیست <?php echo $type==='invoice'?'فاکتورها':'پیش‌فاکتورها'; ?> <span style="font-size:13px;color:#777">(<?php echo count($rows); ?> مورد)</span></h2><table class="widefat striped"><thead><tr><th>شماره</th><th>طرف حساب</th><th>تاریخ</th><th>مبلغ</th><th>پرداخت</th><th>عملیات</th></tr></thead><tbody><?php if(!$rows): ?><tr><td colspan="6">موردی پیدا نشد.</td></tr><?php endif; foreach($rows as $r){$print=bzc_invoice_print_url((int)$r['id'],$type); echo '<tr><td><strong>'.esc_html($r['invoice_no']).'</strong></td><td>'.esc_html($r['party_name']?:'—').'</td><td>'.esc_html(bzc_finance_date($r['issue_date'])).'</td><td>'.esc_html(bzc_finance_money($r['total'])).'</td><td>'.esc_html(['credit'=>'نسیه','bank'=>'حساب بانکی','check'=>'چک'][$r['payment_type']]??$r['payment_type']).'</td><td><a class="button button-small button-primary" target="_blank" href="'.esc_url($print).'">👁 مشاهده / چاپ</a> <a class="button button-small" href="'.esc_url(add_query_arg('edit',$r['id'],$base)).'">ویرایش</a> '; if($type==='proforma')echo '<form method="post" style="display:inline"><input type="hidden" name="bzc_invoice_action" value="convert"><input type="hidden" name="id" value="'.$r['id'].'">'.wp_nonce_field('bzc_invoice_action','bzc_invoice_nonce',true,false).'<button class="button button-small">تبدیل به فاکتور</button></form> '; echo '<form method="post" style="display:inline" onsubmit="return confirm(\'حذف شود؟\')"><input type="hidden" name="bzc_invoice_action" value="delete"><input type="hidden" name="id" value="'.$r['id'].'">'.wp_nonce_field('bzc_invoice_action','bzc_invoice_nonce',true,false).'<button class="button button-small">حذف</button></form></td></tr>'; } ?></tbody></table></section></div>
    <script>jQuery(function($){function calc(){let s=0;$('#bzc-invoice-items tbody tr').each(function(){let q=parseFloat($('.bzc-qty',this).val())||0,p=parseFloat($('.bzc-price',this).val())||0,d=parseFloat($('.bzc-discount',this).val())||0,t=Math.max(0,q*p-d);$('.bzc-line-total',this).text(t.toLocaleString());s+=t;});$('#bzc-subtotal').text(s.toLocaleString());}$('#bzc-invoice-items').on('input','.bzc-qty,.bzc-price,.bzc-discount',calc).on('change','.bzc-prod',function(){let o=$(this).find(':selected');let r=$(this).closest('tr');if(o.val()){r.find('input[name*="product_name"]').val(o.data('name'));r.find('.bzc-price').val(o.data('price'));}calc();}).on('click','.bzc-remove',function(){$(this).closest('tr').remove();calc();});$('#bzc-add-item').on('click',function(){let n=$('#bzc-invoice-items tbody tr').length,html=$('#bzc-invoice-items tbody tr:first').clone();html.find('.bzc-searchable-wrap').remove();html.find('select.bzc-searchable-select').show().removeAttr('data-bzc-init').val(0);html.find('input,select').each(function(){let name=$(this).attr('name');if(name)$(this).attr('name',name.replace(/items\[\d+\]/,'items['+n+']'));$(this).val($(this).is('.bzc-qty')?1:0);});html.find('.bzc-prod').val(0);html.find('.bzc-line-total').text('0');$('#bzc-invoice-items tbody').append(html);if(window.bzcInitSearchableSelects)window.bzcInitSearchableSelects(html);});$('#bzc-pay-add').on('click',function(){let n=$('#bzc-invoice-payments tbody tr').length,r=$('#bzc-invoice-payments tbody tr:first').clone();r.find('input').val('');r.find('input[name*=amount]').val(0);r.find('select').first().val('credit');r.find('select').last().val(0);r.find('input,select').each(function(){let name=$(this).attr('name');if(name)$(this).attr('name',name.replace(/payments\[\d+\]/,'payments['+n+']'));});$('#bzc-invoice-payments tbody').append(r);});$('#bzc-invoice-payments').on('click','.bzc-pay-remove',function(){$(this).closest('tr').remove();});calc();});</script><?php
}

function bzc_invoice_admin_action($page_type){ if(empty($_POST['bzc_invoice_action']))return ''; check_admin_referer('bzc_invoice_action','bzc_invoice_nonce'); global $wpdb; $action=sanitize_key($_POST['bzc_invoice_action']); $id=absint($_POST['id']??0); if($action==='convert'&&$id){$p=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.bzc_invoice_table('invoices').' WHERE id=%d AND type=\'proforma\'',$id),ARRAY_A);if(!$p)return 'پیش‌فاکتور پیدا نشد.';$now=current_time('mysql');$wpdb->insert(bzc_invoice_table('invoices'),array_merge($p,['id'=>null,'invoice_no'=>bzc_invoice_next_no('invoice'),'type'=>'invoice','order_id'=>0,'converted_from'=>$id,'created_at'=>$now,'updated_at'=>$now]));$new=$wpdb->insert_id;$its=$wpdb->get_results($wpdb->prepare('SELECT * FROM '.bzc_invoice_table('items').' WHERE invoice_id=%d',$id),ARRAY_A);foreach($its as $i){unset($i['id']);$i['invoice_id']=$new;$wpdb->insert(bzc_invoice_table('items'),$i);} bzc_invoice_apply_finance($new,$p['payment_type'],(int)$p['payment_account_id'],(float)$p['total'],(int)$p['party_id'],$p['issue_date'],''); return 'پیش‌فاکتور به فاکتور تبدیل شد.';}
 if($action==='delete'&&$id){
    $r=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.bzc_invoice_table('invoices').' WHERE id=%d',$id),ARRAY_A);
    if(!$r)return 'سند پیدا نشد.';
    if(function_exists('bzc_docs_delete_finance')) bzc_docs_delete_finance($id);
    else $wpdb->query($wpdb->prepare("DELETE FROM ".bzc_finance_table('transactions')." WHERE source_type='invoice' AND (source_id=%s OR source_id LIKE %s OR reference=%s)",'invoice:'.$id,'invoice:'.$id.':%','invoice:'.$id));
    $wpdb->delete(bzc_invoice_table('items'),['invoice_id'=>$id]);
    if(function_exists('bzc_invoice_payments_table'))$wpdb->delete(bzc_invoice_payments_table(),['invoice_id'=>$id]);
    $wpdb->delete(bzc_invoice_table('invoices'),['id'=>$id]);
    return 'سند حذف شد و تمام آثار مالی مرتبط با آن نیز حذف شد.';
}
if($action==='save'){ $type=sanitize_key($_POST['bzc_invoice_type']??$page_type);$party=absint($_POST['party_id']??0);$issue=bzc_invoice_date_in($_POST['issue_date']??'');$due=bzc_invoice_date_in($_POST['due_date']??'');$items=[];foreach((array)($_POST['items']??[]) as $i){$pid=absint($i['product_id']??0);$name=sanitize_text_field(wp_unslash($i['product_name']??''));$qty=max(0.0001,(float)($i['quantity']??1));$price=max(0,(float)($i['unit_price']??0));$disc=max(0,(float)($i['discount']??0));if(!$name&&$pid&&function_exists('wc_get_product')){$p=wc_get_product($pid);$name=$p?$p->get_name():'';}$line=max(0,$qty*$price-$disc);if($name)$items[]=['product_id'=>$pid,'product_name'=>$name,'sku'=>'','quantity'=>$qty,'unit_price'=>$price,'discount'=>$disc,'total'=>$line];}if(!$party||!$issue||!$items)return 'طرف حساب، تاریخ و حداقل یک ردیف کالا الزامی است.';$subtotal=bzc_invoice_items_total($items);$discount=max(0,(float)($_POST['discount']??0));$tax=max(0,(float)($_POST['tax']??0));$total=max(0,$subtotal-$discount+$tax);$payments=[];$pay_sum=0;foreach((array)($_POST['payments']??[]) as $pp){$pm=sanitize_key($pp['method']??'credit');if(!in_array($pm,['credit','bank','check'],true))continue;$pa=max(0,(float)($pp['amount']??0));if($pa<=0)continue;$pacc=absint($pp['account_id']??0);$pcn=sanitize_text_field(wp_unslash($pp['check_number']??''));if($pm==='bank'&&!$pacc)return 'برای پرداخت بانکی، حساب بانکی را انتخاب کنید.';if($pm==='check'&&!$pcn)return 'برای چک، شماره چک را وارد کنید.';$payments[]=['method'=>$pm,'amount'=>$pa,'account_id'=>$pacc,'check_number'=>$pcn];$pay_sum+=$pa;}if(!$payments)$payments=[['method'=>'credit','amount'=>$total,'account_id'=>0,'check_number'=>'']];if($pay_sum>$total+0.01)return 'مجموع پرداخت‌ها نمی‌تواند بیشتر از مبلغ فاکتور باشد.';$payment=count($payments)>1?'mixed':$payments[0]['method'];$acc=0;foreach($payments as $pp)if($pp['method']==='bank'){$acc=$pp['account_id'];break;}$now=current_time('mysql');$table=bzc_invoice_table('invoices');$data=['type'=>$type,'status'=>($pay_sum+0.001>=$total?'issued':'partial'),'party_id'=>$party,'issue_date'=>$issue,'due_date'=>$due?:null,'subtotal'=>$subtotal,'discount'=>$discount,'tax'=>$tax,'total'=>$total,'payment_type'=>$payment,'payment_account_id'=>$acc,'notes'=>sanitize_textarea_field(wp_unslash($_POST['notes']??'')),'updated_at'=>$now];if($id){$old=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d AND type=%s",$id,$type),ARRAY_A);if(!$old)return 'سند پیدا نشد.';$wpdb->update($table,$data,['id'=>$id]);$wpdb->delete(bzc_invoice_table('items'),['invoice_id'=>$id]);if(function_exists('bzc_docs_delete_finance')) { bzc_docs_delete_finance($id); if(!empty($old['check_id'])) $wpdb->delete(bzc_finance_table('checks'),['id'=>(int)$old['check_id']]); } else {$wpdb->query($wpdb->prepare("DELETE FROM ".bzc_finance_table('transactions')." WHERE source_type='invoice' AND source_id LIKE %s",'invoice:'.$id.':%'));if(!empty($old['check_id']))$wpdb->delete(bzc_finance_table('checks'),['id'=>(int)$old['check_id']]);}if(function_exists('bzc_invoice_payments_table'))$wpdb->delete(bzc_invoice_payments_table(),['invoice_id'=>$id]);$wpdb->update($table,['check_id'=>0],['id'=>$id]);}else{$data['invoice_no']=bzc_invoice_next_no($type);$data['created_by']=get_current_user_id();$data['created_at']=$now;$wpdb->insert($table,$data);$id=$wpdb->insert_id;}
 foreach($items as $i)$wpdb->insert(bzc_invoice_table('items'),array_merge($i,['invoice_id'=>$id]));
 if(function_exists('bzc_invoice_payments_table')){ $wpdb->delete(bzc_invoice_payments_table(),['invoice_id'=>$id]); foreach($payments as $pp)$wpdb->insert(bzc_invoice_payments_table(),['invoice_id'=>$id,'method'=>$pp['method'],'amount'=>$pp['amount'],'account_id'=>$pp['account_id'],'check_number'=>$pp['check_number'],'created_at'=>$now]); }
 if($type==='invoice' && function_exists('bzc_docs_apply_finance')) bzc_docs_apply_finance($id,'invoice',$payments,$total,$party,$issue);
 elseif($type==='invoice') bzc_invoice_apply_finance($id,$payment,$acc,$total,$party,$issue,'');
 return 'سند با موفقیت ذخیره شد.'; } return ''; }
function bzc_invoice_apply_finance($id,$payment,$account,$total,$party,$date,$check_number=''){
    global $wpdb;
    $tx=bzc_finance_table('transactions');
    $now=current_time('mysql');
    $id=(int)$id; $account=(int)$account; $total=(float)$total; $party=(int)$party;

    // Cash-basis: the invoice itself never creates income/expense.
    if($payment==='credit' || $total<=0) return;

    $source_id='invoice:'.$id.':conversion_payment';
    if($wpdb->get_var($wpdb->prepare("SELECT id FROM {$tx} WHERE source_type='invoice' AND source_id=%s LIMIT 1",$source_id))) return;

    if($payment==='bank' && $account){
        $wpdb->insert($tx,[
            'transaction_date'=>$date,
            'type'=>'income',
            'amount'=>$total,
            'account_id'=>$account,
            'party_id'=>$party,
            'party_effect'=>-$total,
            'description'=>'تسویه فاکتور فروش #'.$id,
            'reference'=>'invoice:'.$id,
            'source_type'=>'invoice',
            'source_id'=>$source_id,
            'status'=>'posted',
            'created_by'=>get_current_user_id(),
            'created_at'=>$now,
            'updated_at'=>$now
        ]);
    } elseif($payment==='check' && $check_number){
        $wpdb->insert(bzc_finance_table('checks'),[
            'check_type'=>'received','party_id'=>$party,'account_id'=>$account,
            'amount'=>$total,'check_number'=>sanitize_text_field($check_number),'status'=>'pending',
            'description'=>'چک بابت فاکتور فروش #'.$id,'created_at'=>$now,'updated_at'=>$now
        ]);
        $cid=(int)$wpdb->insert_id;
        $wpdb->update(bzc_invoice_table('invoices'),['check_id'=>$cid],['id'=>$id]);
        $wpdb->insert($tx,[
            'transaction_date'=>$date,'type'=>'income','amount'=>$total,'account_id'=>0,
            'party_id'=>$party,'party_effect'=>-$total,'description'=>'تسویه چک فاکتور فروش #'.$id,
            'reference'=>'invoice:'.$id,'source_type'=>'invoice','source_id'=>$source_id,
            'status'=>'posted','created_by'=>get_current_user_id(),'created_at'=>$now,'updated_at'=>$now
        ]);
    }
}

